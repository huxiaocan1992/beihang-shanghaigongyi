//var channel_url = "https://test.dakaqi.cn:8443/pab";
//var jd_url = "https://test.dakaqi.cn:7443/gov";
var channel_url = "https://pab.cvssp.cn";
var jd_url = "http://jd.cvssp.cn";
