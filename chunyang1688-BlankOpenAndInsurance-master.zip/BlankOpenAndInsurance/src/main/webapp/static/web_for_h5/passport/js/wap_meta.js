
<!--js实现viewport-->
    var User_Agent= navigator.userAgent, app = navigator.appVersion;
    var isAndroid = User_Agent.indexOf('Android') > -1 || User_Agent.indexOf('Linux') > -1; //android终端或者uc浏览器
    var isiOS = !!User_Agent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    if(isiOS) {
        document.write('<meta name="viewport" content="width=750,user-scalable=0">');
    } else  if(User_Agent.indexOf("MicroMessenger") >-1 ){
        document.write("<meta name='viewport' content='width=750,user-scalable=0,minimum-scale=1.0,maximum-scale=1.0,target-densitydpi=device-dpi'>");
    }else if(User_Agent.indexOf("MQQBrowser") >-1){
        document.write("<meta name='viewport' content='width=750,user-scalable=0,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,target-densitydpi=device-dpi'> ");
    }else if(User_Agent.indexOf("360browser")>-1) {
        document.write("<meta name='viewport' content='width=750,user-scalable=0,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,target-densitydpi=device-dpi'>");
    }else{
        document.write("<meta name='viewport' content='width=750,user-scalable=0'>");
    }
    
	function serializeObject(form) {
		var o = {};
		$.each(form.serializeArray(), function(index) {
			if (this['value'] != undefined && this['value'].length > 0) {// 如果表单项的值非空，才进行序列化操作
				if (o[this['name']]) {
					o[this['name']] = o[this['name']] + "," + this['value'];
				} else {
					o[this['name']] = this['value'];
				}
			}
		});
		return o;
	};