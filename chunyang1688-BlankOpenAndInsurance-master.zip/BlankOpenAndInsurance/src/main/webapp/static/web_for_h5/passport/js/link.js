var linkObj = new Object();

//var rootPath = "https://test.dakaqi.cn:7443/gov";
//var activatePath="https://test.dakaqi.cn:2443";

//Product
var rootPath = "http://jd.cvssp.cn";
var activatePath="https://pab.cvssp.cn";
//index
linkObj.activate = rootPath+"/static/web_for_h5/passport/activate/activate.html";
linkObj.indexInfo = rootPath+"/v1/index";

//activate
linkObj.pplogin = rootPath+"/v1/passport/pplogin";
linkObj.infoUrl = activatePath+"/static/web_for_h5/passport/activate/activateInfo.html";
linkObj.jssdk = "http://wxtest.cvssp.cn/api/shareInfo.php";
linkObj.info = activatePath+"/pingan/explain";
linkObj.openAccont = activatePath+"/pingan/toOpenAccount";
linkObj.callBack = activatePath+"/pingan/openFinshedCallBack";
linkObj.getInsurance = activatePath+"/pingan/findInsurance";


//apply
linkObj.checkCode = rootPath+"/v1/common/verfiMobileCode";
linkObj.sendCode = rootPath+"/v1/common/sendMobileCode";
linkObj.apply = rootPath+"/v1/passport/apply";
linkObj.cardType = rootPath+"/v1/common/cardType";
linkObj.applyType = rootPath+"/v1/common/applyType";
linkObj.relationType = rootPath+"/v1/common/personRelation";

linkObj.getCity = rootPath+"/v1/common/provicecitydistrict";
linkObj.getBase = rootPath+"/v1/address4base/findByAddress";
linkObj.getTime = rootPath+"/v1/address4base/findAddressAppointTime";
linkObj.orderDetail = rootPath+"/v1/passport/orderDetail";


//search
linkObj.search = rootPath+"/v1/passport/orderDetail";
