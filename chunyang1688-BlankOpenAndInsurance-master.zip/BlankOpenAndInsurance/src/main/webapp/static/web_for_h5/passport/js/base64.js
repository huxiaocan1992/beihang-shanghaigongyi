(function(){
	var Base64 = {
		encode : function(str){
			return window.btoa(unescape(encodeURIComponent(str)));
		},
		decode : function(str){
			return decodeURIComponent(escape(window.atob(str)));
		}
	};
	window.BASE64 = Base64;
})();