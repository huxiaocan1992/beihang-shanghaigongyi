package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.beanvalidator.BeanValidators;
import cn.dakaqi.blank.controller.BaseController;
import cn.dakaqi.blank.controller.input.OpenAccountVO;
import cn.dakaqi.blank.controller.response.VolunteerInsuraceVO;
import cn.dakaqi.blank.entity.*;
import cn.dakaqi.blank.rsa.AesTest;
import cn.dakaqi.blank.service.*;
import cn.dakaqi.blank.service.pingan.IPingAnService;
import cn.dakaqi.blank.util.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 类名称：OpenAccountController <br>
 * 类描述：平安银行开户
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016 /11/30 16:38
 */
@RestController
@RequestMapping(value = "/pingan")
@Slf4j
@Api(value = "平安激活账户", description = "平安激活账户", hidden = false)
public class OpenAccountController extends BaseController {
    /**
     * The Channel service.
     */
    @Autowired
    IChannelService channelService;
    /**
     * The Channel explain service.
     */
    @Autowired
    IChannelExplainService channelExplainService;
    /**
     * The Ping an service.
     */
    @Autowired
    IPingAnService pingAnService;
    /**
     * The Bank account service.
     */
    @Autowired
    IBankAccountService bankAccountService;
    /**
     * The Insurance service.
     */
    @Autowired
    IInsuranceService insuranceService;
    /**
     * The Trade list service.
     */
    @Autowired
    ITradeListService tradeListService;

    @Autowired
    IActivateRecordService activateRecordService;

    Insurance insurance = null;
    BankAccount bankAccount = null;
    //微信二维码
//            https://pab.cvssp.cn/pingan/activateInfo
//            <option value="A">保险业务</option>   buyInsurance
//            <option value="B">平安银行</option>   onlyPinganOpen
//            <option value="C">护照申请</option>   applyPassport
//            <option value="D">护照激活</option>   activatePassport
//            <option value="E">捐赠</option>   donate
//            <option value="F">团体护照</option>   applyAndActivatePassport
//            <option value="G">未成年人团体护照</option>   applyActivate418Passport


    /**
     * Donate.
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/donate/{channelCode}/{businessCode}", method = RequestMethod.GET)
    @ApiOperation(value = "捐赠", notes = "捐赠")
    public void donate(HttpServletResponse response,
                                 @PathVariable("channelCode") String channelCode,
                                 @PathVariable("businessCode") String businessCode)
    {
        try
        {
            String redirectUrl = Constant.getPABUrl() + "/static/web_for_h5/passport/activate/activate.html?channelCode="+channelCode+"&businessCode=" + businessCode+"&orderCode="+Identities.randomBase62(10)+"&realName=";
            log.info("捐赠:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Activate passport.
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/activatePassport/{channelCode}/{businessCode}", method = RequestMethod.GET)
    @ApiOperation(value = "护照激活", notes = "护照激活")
    public void activatePassport(HttpServletResponse response,
                              @PathVariable("channelCode") String channelCode,
                              @PathVariable("businessCode") String businessCode)
    {
        try
        {
            String redirectUrl = Constant.getJDUrl() + "/static/web_for_h5/passport/activate/activate.html?channelCode="+channelCode+"&businessCode=" + businessCode+"&orderCode="+Identities.randomBase62(10)+"&realName=";
            log.info("护照激活:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Apply passport.
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/applyPassport/{channelCode}/{businessCode}", method = RequestMethod.GET)
    @ApiOperation(value = "护照申请", notes = "护照申请")
    public void applyPassport(HttpServletResponse response,
                               @PathVariable("channelCode") String channelCode,
                               @PathVariable("businessCode") String businessCode)
    {
        try
        {
            String redirectUrl = Constant.getJDUrl() + "/static/web_for_h5/passport/apply/tel.html?channelCode="+channelCode+"&businessCode=" + businessCode+"&orderCode="+Identities.randomBase62(10)+"&realName=";
            log.info("护照申请:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Apply passport.
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/applyAndActivatePassport/{channelCode}/{businessCode}/{baseAddress}", method = RequestMethod.GET)
    @ApiOperation(value = "护照申请并且激活", notes = "护照申请并且激活")
    public void applyAndActivatePassport(HttpServletResponse response,
                              @PathVariable("channelCode") String channelCode,
                              @PathVariable("businessCode") String businessCode,
                              @PathVariable("baseAddress") String baseAddress)
    {
        try
        {
            String redirectUrl = Constant.getJDUrl() + "/static/web_for_h5/passport/applyandactivate/index.html?channelCode="+channelCode+"&businessCode=" + businessCode+"&orderCode="+Identities.randomBase62(10)+"&baseAddress="+baseAddress+"&realName=";
            log.info("护照申请并且激活:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Apply passport.
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/applyActivate418Passport/{channelCode}/{businessCode}/{baseAddress}", method = RequestMethod.GET)
    @ApiOperation(value = "未成年护照申请并且激活", notes = "未成年护照申请并且激活")
    public void applyActivate418Passport(HttpServletResponse response,
                                         @PathVariable("channelCode") String channelCode,
                                         @PathVariable("businessCode") String businessCode,
                                         @PathVariable("baseAddress") String baseAddress)
    {
        try
        {
            String redirectUrl = Constant.getJDUrl() + "/static/web_for_h5/passport/juvenileapplyandactivate/index.html?channelCode="
                    +channelCode+"&businessCode="
                    + businessCode+"&orderCode="
                    +Identities.randomBase62(10)
                    +"&baseAddress="+baseAddress+"&realName=";
            log.info("applyActivate418Passport 护照申请并且激活:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Only pingan open.
     * 平安业务，仅仅平安开户
     *
     * @param response     the response
     * @param channelCode  the channel code
     * @param businessCode the business code
     */
    @RequestMapping(value = "/onlyPinganOpen/{channelCode}/{businessCode}", method = RequestMethod.GET)
    @ApiOperation(value = "平安业务，仅仅平安开户", notes = "平安业务，仅仅平安开户")
    public void onlyPinganOpen(HttpServletResponse response,
                               @PathVariable("channelCode") String channelCode,
                               @PathVariable("businessCode") String businessCode)
    {
        try
        {
            String redirectUrl = Constant.getPABUrl() + "/static/web_for_h5/passport/activate/activateInfo.html?" +
                    "channelCode="+channelCode+"&businessCode=" +
                    businessCode+"&orderCode="+Identities.randomBase62(10)+"&realName=";
            log.info("平安业务，仅仅平安开户:"+redirectUrl);
            response.sendRedirect(redirectUrl);
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Index object.
     * 打卡器购买保险
     *
     * @param response      the response
     * @param channelCode   the channel code
     * @param businessCode  the business code
     * @param volunteerCode the volunteer code
     * @param mobile        the mobile
     * @param idNo          the id no
     * @param realName      the real name
     * @return the object
     */
    @RequestMapping(value = "/buyInsurance", method = RequestMethod.GET)
    @ApiOperation(value = "保险业务", notes = "保险业务")
    public void buyInsurance(
                             HttpServletResponse response,
                             @RequestParam("channelCode") String channelCode,
                             @RequestParam("businessCode") String businessCode,
                             @RequestParam("volunteerCode") String volunteerCode,
                             @RequestParam("mobile") String mobile,
                             @RequestParam("idNo") String idNo,
                             @RequestParam("orderCode") String orderCode,
                             @RequestParam("realName") String realName) {
        try {

//            <option value="A">保险业务</option>
//            <option value="B">平安银行</option>
//            <option value="C">护照申请</option>
//            <option value="D">护照激活</option>
//            <option value="E">其他捐赠</option>

            String redirectUrl = Constant.getJDUrl();
            String message = "";
            //检查年龄是否在18-35岁
            IdcardInfoExtractor idcardInfo=new IdcardInfoExtractor(idNo);

            int age = idcardInfo.getAge();
            if(age<18 ||age>45)
            {
                message = "本次只开放18至45岁";
                redirectUrl = Constant.getPABUrl() + "/static/web_for_h5/404.html?&message="+ Base64Utils.encode(message.getBytes());
            }

            if(businessCode.contains("A"))
            {
                redirectUrl = Constant.getPABUrl() + "/static/web_for_h5/passport/activate/activateInfo.html?orderCode="+orderCode+"&volunteerCode="+volunteerCode+"&mobile="+mobile+"&idNo="+idNo+"&channelCode="+channelCode+"&businessCode="+businessCode+"&realName="+ Base64Utils.encode(realName.getBytes());
            }
            response.sendRedirect(redirectUrl);
        }
        catch (ConstraintViolationException cve)
        {
            Map<String, String> errors = BeanValidators.extractPropertyAndMessage(cve.getConstraintViolations());
            for (Map.Entry<String, String> entry : errors.entrySet())
            {
                log.info(cve.getMessage());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    /**
     * Index object.
     * 阅读说明
     *
     * @param openAccountVO the open account vo
     * @return the object
     */
    @RequestMapping(value = "/explain", method = RequestMethod.POST)
    @ApiOperation(value = "激活说明", notes = "激活说明")
    public JsonResult explain(@RequestBody OpenAccountVO openAccountVO) {
        try {
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            BeanValidators.validateWithException(validator, openAccountVO);
            Channel channel = this.channelService.selectByCode(openAccountVO.getChannelCode());
            if (null == channel) {
                return renderError("渠道不存在");
            }

            ChannelExplain channelExplain = this.channelExplainService.selectByChanel(channel.getId());
            Map<String, Object> resultMap = new HashMap<>();
            resultMap.put("openAccountVO", openAccountVO);
            resultMap.put("channelExplain", channelExplain);
            return renderSuccess(resultMap);

        } catch (ConstraintViolationException cve) {
            Map<String, String> errors = BeanValidators.extractPropertyAndMessage(cve.getConstraintViolations());
            for (Map.Entry<String, String> entry : errors.entrySet()) {
                return renderError(entry.getValue());
            }
        }
        return renderError();
    }

    /**
     * Explain object.
     * 去平安开户
     *
     * @param request       the request
     * @param response      the response
     * @param openAccountVO the open account vo
     * @return the object
     */
    @RequestMapping(value = "/toOpenAccount", method = RequestMethod.POST)
    @ApiOperation(value = "激活", notes = "激活")
    public JsonResult toOpenAccount(
            HttpServletRequest request,
            HttpServletResponse response,
            @RequestBody OpenAccountVO openAccountVO) {
        String openUrl;
        Map<String, Object> resultMap = new HashMap<>();
        log.info("toOpenAccount-------------->"+openAccountVO.toString());
        try {
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            BeanValidators.validateWithException(validator, openAccountVO);

            if (StringUtil.isEmpty(openAccountVO.getRealName())) {
                return renderError("姓名不能为空");
            }
            if (StringUtil.isEmpty(openAccountVO.getIdNo())) {
                return renderError("身份证不能为空");
            }
            //检查身份证是否合法
            boolean F = IdCardUtil.IDCardValidate(openAccountVO.getIdNo());
            if (!F) {
                return renderError("身份证不正确!");
            }
            //如果商户不是公益护照,则检查年龄段是否在18-35
            if(!openAccountVO.getBusinessCode().contains("D") && !openAccountVO.getBusinessCode().contains("F") && !openAccountVO.getBusinessCode().contains("G"))
            {
                IdcardInfoExtractor idcardInfoExtractor = new IdcardInfoExtractor(openAccountVO.getIdNo());
                int age = idcardInfoExtractor.getAge();
                if(age <18 | age >45)
                {
                    String message = "目前只开放18至45岁业务";
                    return renderError(message, resultMap);
                }
            }
            PingAnRequestParam pingAnRequestParam = PingAnRequestParam.buildPingAnRequestParam();
            log.info(pingAnRequestParam.toString());
            //检查当前渠道是否有效
            Channel channel = this.channelService.selectByCode(openAccountVO.getChannelCode());
            if (null == channel)
            {
                String message = "渠道无效";
                return renderError(message);
            }

            //检查当前用户是否已开过平安银行账号
//            BankAccount bankAccount = this.bankAccountService.selectByIdNo(openAccountVO.getIdNo());
//            if (null != bankAccount)
//            {
//                resultMap.put("bankAccount", bankAccount);
//                String message = "您已激活过平安账号";
//                return renderError(message, resultMap);
//            }
            openUrl = pingAnService.saveOpenAccount(request, response, pingAnRequestParam, openAccountVO);
            resultMap.put("openUrl", openUrl);

        } catch (ConstraintViolationException cve) {
            Map<String, String> errors = BeanValidators.extractPropertyAndMessage(cve.getConstraintViolations());
            for (Map.Entry<String, String> entry : errors.entrySet()) {
                return renderError(entry.getValue());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }
        return renderSuccess(resultMap);
    }

    /**
     * Open success call back object.
     * 开户成功时，平安回调将开户信息回传
     *
     * @param ciphertext the ciphertext
     * @return the object
     */
    @RequestMapping(value = "/openSuccessCallBack", method = RequestMethod.POST)
    @ApiOperation(value = "平安账号激活后,平安银行信息回调", notes = "平安账号激活后,平安银行信息回调")
    public JsonResult openSuccessCallBack(@RequestParam("ciphertext") String ciphertext)
    {
        try {
            log.info("openSuccessCallBack   ciphertext   " + ciphertext);
            PingAnRequestParam pingAnRequestParam = PingAnRequestParam.buildPingAnRequestParam();
            String decryptData = AesTest.decrypt(ciphertext, pingAnRequestParam.getAesKey());
            log.error("解密原文: " + decryptData);
            JSONObject jsonObject = JSON.parseObject(decryptData);
            String idNo = jsonObject.getString("idNo");
            String systemId = jsonObject.getString("systemId");
            String bankAcnt = jsonObject.getString("bankAcnt");
            String bankAcctStatus = jsonObject.getString("bankAcctStatus");
            String isNewCus = jsonObject.getString("isNewCus");
            String Mobile = jsonObject.getString("Mobile");
            String tradeTime = jsonObject.getString("tradeTime");
            String realName = jsonObject.getString("realName");
            //检查当前银行卡是否已存在
            BankAccount bankAccount = this.bankAccountService.selectByBankAct(bankAcnt);
            if (null != bankAccount)
            {
                return renderSuccess();
            }
            else
            {
                bankAccount = new BankAccount();
                bankAccount.setIdNo(idNo);
                bankAccount.setSystemId(systemId);
                bankAccount.setBankAcctStatus(bankAcctStatus);
                bankAccount.setBankAcnt(bankAcnt);
                bankAccount.setIsNewCus(isNewCus);
                bankAccount.setMobile(Mobile);
                bankAccount.setTradeTime(tradeTime);
                bankAccount.setRealName(realName);
                this.bankAccountService.insert(bankAccount);
            }
        } catch (Exception e) {
            e.printStackTrace();
            renderError(e.getMessage());
        }

        return renderSuccess();
    }

    /**
     * Open finshed call back json result.
     *
     * @param openAccountVO the open account vo
     * @return the json result
     */
    @RequestMapping(value = "/openFinshedCallBack", method = RequestMethod.POST)
    @ApiOperation(value = "平安账号激活完成后,银行回调返回H5页面，H5调用", notes = "平安账号激活完成后,银行回调返回H5页面，H5调用")
    public JsonResult openFinshedCallBack(@RequestBody OpenAccountVO openAccountVO)
    {
        log.error("PingAn openFinshedCallBack :" + openAccountVO.toString());
        Map<String, Object> resultMap = new HashMap<>();
        String channelCode = openAccountVO.getChannelCode();
        String businessCode = "";
        try {
            Channel channel = this.channelService.selectByCode(channelCode);
            log.info("openFinshedCallBack--------------------->"+channel.toString());
            if (null == channel)
            {
                resultMap.put("page", "thanks");
                return renderSuccess(resultMap);
            }
            businessCode = channel.getBusinessCode();
            openAccountVO.setBusinessCode(businessCode);
            resultMap.put("channelCode", channel.getCode());
            resultMap.put("businessCode",businessCode);
            resultMap.put("idNo", openAccountVO.getIdNo());
            resultMap.put("orderCode", openAccountVO.getOrderCode());
            //未成年需要单独处理
            if(!channel.getBusiness().contains("G"))
            {
                //更新银行账户信息
                bankAccount = this.bankAccountService.selectByIdNo(openAccountVO.getIdNo());
                if (null != bankAccount)
                {
                    bankAccount.setChannel(channel.getCode());
                    this.bankAccountService.insertOrUpdate(bankAccount);
                }
            }


            //微信二维码
//            https://pab.cvssp.cn/pingan/activateInfo
//            <option value="A">保险业务</option>   buyInsurance
//            <option value="B">平安银行</option>   onlyPinganOpen
//            <option value="C">护照申请</option>   applyPassport
//            <option value="D">护照激活</option>   activatePassport
//            <option value="E">其他捐赠</option>   donate
//            <option value="F">申请激活</option>   applyAndActivatePassport
//            <option value="G">未成年申请激活</option>   applyActivate418Passport

            log.info("openFinshedCallBack channel.getBusiness()-------->" + channel.getBusiness());

            if(channel.getBusiness().equals("A"))
            {
                //<option value="A">保险业务</option>
                resultMap = buyInsurance(openAccountVO,bankAccount);
                this.tradeListService.insertBuyInsuranceTrade(channelCode, businessCode, openAccountVO.getOrderCode(),bankAccount,insurance);
                this.channelService.sendBankActAndInsurance2Channel(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),openAccountVO.getOrderCode(), bankAccount, insurance);
                resultMap.put("page", "insurance");
                resultMap.put("mobile", bankAccount.getMobile());
                resultMap.put("bankAct", bankAccount.getBankAcnt());
                resultMap.put("insuranceNo", insurance.getInsuranceNo());
                return renderSuccess(resultMap);
            }
            else if(channel.getBusiness().equals("B"))
            {
                //<option value="B">平安银行</option>
                this.tradeListService.insertPingAnOpenTrade(channelCode, businessCode, openAccountVO.getOrderCode(),bankAccount);
                resultMap.put("page", "thanks");
                this.channelService.sendBankActAndInsurance2Channel(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),openAccountVO.getOrderCode(), bankAccount, insurance);
                return renderSuccess(resultMap);
            }
            else if(channel.getBusiness().equals("C"))
            {
                this.tradeListService.insertApplyPassportTrade(
                        openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                        openAccountVO.getOrderCode(),openAccountVO.getRealName(),
                        openAccountVO.getIdNo(),openAccountVO.getMobile(),
                        openAccountVO.getPassportNo());
                //<option value="C">护照申请</option>
                resultMap.put("page", "thanks");
                return renderSuccess(resultMap);
            }
            else if(channel.getBusiness().equals("D"))
            {
                //<option value="D">护照激活</option>
                log.info("openFinshedCallBack bankAccount-------->" + bankAccount.toString());
                //购买保险
                resultMap = buyInsurance(openAccountVO,bankAccount);
                //新增交易记录
                this.tradeListService.insertActivatePassportTrade(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                        openAccountVO.getOrderCode(),bankAccount.getRealName(),
                        bankAccount.getIdNo(),bankAccount.getMobile(),
                        openAccountVO.getPassportNo(),bankAccount);
            }
            else if(channel.getBusiness().equals("E"))
            {
                //<option value="E">其他捐赠</option>
                this.tradeListService.insertDonteTrad(null);
            }
            else if(channel.getBusiness().equals("F"))
            {
                //<option value="F">申请激活</option>
                //购买保险
                resultMap = buyInsurance(openAccountVO,bankAccount);
                //新增交易记录
                this.tradeListService.insertActivatePassportTrade(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                        openAccountVO.getOrderCode(),bankAccount.getRealName(),
                        bankAccount.getIdNo(),bankAccount.getMobile(),
                        openAccountVO.getPassportNo(),bankAccount);

                resultMap.put("page", "applyAndActivatePassport");
                resultMap.put("mobile", bankAccount.getMobile());
                resultMap.put("bankAct", bankAccount.getBankAcnt());
                resultMap.put("insuraceNo", insurance.getInsuranceNo());
            }
            else if(channel.getBusiness().equals("G"))
            {
                //更新银行账户信息
                bankAccount = this.bankAccountService.selectByIdNo(openAccountVO.getGuardianCardNo());
                if (null != bankAccount)
                {
                    bankAccount.setChannel(channel.getCode());
                    this.bankAccountService.insertOrUpdate(bankAccount);
                }

                //检查当前用户年龄是否小于7或大于 70
                IdcardInfoExtractor idcardInfoExtractor = new IdcardInfoExtractor(openAccountVO.getIdNo());
                int age = idcardInfoExtractor.getAge();
                if(age<7 || age >70)
                {
                    //新增交易记录
                    this.tradeListService.insertActivatePassportTrade(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                            openAccountVO.getOrderCode(),bankAccount.getRealName(),
                            bankAccount.getIdNo(),bankAccount.getMobile(),
                            openAccountVO.getPassportNo(),bankAccount);
                    resultMap.put("page", "juvenileapplyandactivate");
                    resultMap.put("mobile", bankAccount.getMobile());
                    resultMap.put("bankAct", bankAccount.getBankAcnt());
                    resultMap.put("insuraceNo", "");
                }
                else
                {
                    //<option value="G">未成年申请激活</option>
                    //购买保险
                    resultMap = buyInsurance(openAccountVO,bankAccount);
                    //新增交易记录
                    this.tradeListService.insertActivatePassportTrade(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                            openAccountVO.getOrderCode(),openAccountVO.getRealName(),
                            openAccountVO.getIdNo(),bankAccount.getMobile(),
                            openAccountVO.getPassportNo(),bankAccount);
                    resultMap.put("page", "juvenileapplyandactivate");
                    resultMap.put("mobile", bankAccount.getMobile());
                    resultMap.put("bankAct", bankAccount.getBankAcnt());
                    resultMap.put("insuraceNo", insurance.getInsuranceNo());
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return renderSuccess(resultMap);
    }
    private Map<String, Object> buyInsurance(OpenAccountVO openAccountVO,BankAccount bankAccount)
    {
        log.info("buyInsurance--------1------------->" + openAccountVO);
        log.info("buyInsurance--------1------------->" + bankAccount);
        Map<String, Object> resultMap = new HashMap<>();
        try
        {
            if (null != openAccountVO.getVolunteerCode() && !openAccountVO.getVolunteerCode().toLowerCase().equals("null") && StringUtil.isNotEmpty(openAccountVO.getVolunteerCode()))
            {
                log.info("buyInsurance-------2-------------->");
                insurance = this.insuranceService.selectByVolunteerCode(openAccountVO.getVolunteerCode());
                if (null != insurance)
                {
                    resultMap.put("page", "insurance");
                    resultMap.put("insuranceNo", insurance.getInsuranceNo());
                    this.channelService.sendBankActAndInsurance2Channel(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),openAccountVO.getOrderCode(), bankAccount, insurance);
                    return resultMap;
                }
            }
            log.info("buyInsurance----------3----------->");
            String realName = bankAccount.getRealName();
            if(null !=openAccountVO.getGuardianCardNo() && !"null".equals(openAccountVO.getGuardianCardNo()) && StringUtil.isNotEmpty(openAccountVO.getGuardianCardNo()))
                realName = openAccountVO.getRealName();

            insurance = insuranceService.saveInsurance(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),
                    openAccountVO.getIdNo(), openAccountVO.getGroupCode(),openAccountVO.getVolunteerCode(),
                    realName, bankAccount.getMobile());
            if (null != insurance)
            {
                log.info("buyInsurance-------4-------------->");
                resultMap.put("page", "insurance");
                resultMap.put("insuranceNo", insurance.getInsuranceNo());
                this.channelService.sendBankActAndInsurance2Channel(openAccountVO.getChannelCode(), openAccountVO.getBusinessCode(),openAccountVO.getOrderCode(), bankAccount, insurance);
                return resultMap;
            }
            else
            {
                log.info("buyInsurance-----5---------------->");
                resultMap.put("page", "thanks");
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return resultMap;
    }
    /**
     * Find insurance json result.
     *
     * @param channelCode the channel code
     * @param insuranceNo the insurance no
     * @param idNo        the id no
     * @return the json result
     */
    @RequestMapping(value = "/findInsurance", method = RequestMethod.GET)
    @ApiOperation(value = "查看保单信息", notes = "查看保单信息")
    public JsonResult findInsurance(@RequestParam("channelCode") String channelCode,
                                    @RequestParam("insuranceNo") String insuranceNo,
                                    @RequestParam("idNo") String idNo) {
        Map<String, Object> resultMap = new HashMap<>();
        VolunteerInsuraceVO volunteerInsuraceVO = new VolunteerInsuraceVO();
        Channel channel = this.channelService.selectByCode(channelCode);
        if (null != channel) {
            ChannelExplain channelExplain = this.channelExplainService.selectByChanel(channel.getId());
            if (null != channelExplain) {
                volunteerInsuraceVO.setChannelAdsImg(channelExplain.getAdsImg());
            }

            BankAccount bankAccount = this.bankAccountService.selectByIdNo(idNo);
            if (null != bankAccount)
                volunteerInsuraceVO.setBankNum(bankAccount.getBankAcnt());
        }
        //检查本地保险表中是否已存在
        Insurance insurance = this.insuranceService.selectByInsuranceNo(insuranceNo);
        if (null != insurance) {
            volunteerInsuraceVO.setInsuranceNo(insurance.getInsuranceNo());
            volunteerInsuraceVO.setPeriodEnd(insurance.getPeriodEnd());
            volunteerInsuraceVO.setPeriodStart(insurance.getPeriodStart());
        }
        resultMap.put("volunteerInsurace", volunteerInsuraceVO);
        return renderSuccess(resultMap);
    }

    /**
     * Find activate record json result.
     *
     * @param idNo the id no
     * @return the json result
     */
    @RequestMapping(value = "/findActivateRecord", method = RequestMethod.POST)
    @ApiOperation(value = "查询是否激活", notes = "查询是否激活")
    public JsonResult findActivateRecord(@RequestParam("idNo") String  idNo)
    {
        Map<String, Object> resultMap = new HashMap<>();
        if(StringUtil.isEmpty(idNo))
        {
            resultMap.put("code",Constant.ACTIVATE_STATUS_NO);
            return renderError(resultMap);
        }
        ActivateRecord activateRecord = this.activateRecordService.selectByIdNO(idNo);
        if(null != activateRecord)
            resultMap.put("code",activateRecord.getStatus());
        else
            resultMap.put("code",Constant.ACTIVATE_STATUS_NO);
        return renderSuccess(resultMap);
    }
    @RequestMapping(value = "/updateActivateRecord", method = RequestMethod.POST)
    @ApiOperation(value = "更新激活记录", notes = "更新激活记录")
    public JsonResult updateActivateRecord(@RequestParam("idNo") String  idNo, @RequestParam("passportNo") String passportNo)
    {
        log.info(idNo+ "<------------------>" + passportNo);
        Map<String, Object> resultMap = new HashMap<>();
        this.activateRecordService.insertRecord(idNo,passportNo);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/updateActivateRecord18", method = RequestMethod.POST)
    @ApiOperation(value = "更新激活记录,小于18，没有银行卡，有保险", notes = "更新激活记录,小于18，没有银行卡，有保险")
    public JsonResult updateActivateRecord18(@RequestParam("realName") String  realName,
                                              @RequestParam("idNo") String  idNo,
                                              @RequestParam("guardianCardNo") String  guardianCardNo,
                                              @RequestParam("passportNo") String passportNo)
    {
        Map<String, Object> resultMap = new HashMap<>();
        this.activateRecordService.updateActivateRecord18(realName,idNo,guardianCardNo,passportNo);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/updateActivateRecord7", method = RequestMethod.POST)
    @ApiOperation(value = "更新激活记录,小于7，没有银行卡,没有保险", notes = "更新激活记录,小于7，没有银行卡,没有保险")
    public JsonResult updateActivateRecord7(@RequestParam("realName") String  realName,
                                              @RequestParam("mobile") String  mobile,
                                              @RequestParam("idNo") String  idNo,
                                              @RequestParam("passportNo") String passportNo)
    {
        Map<String, Object> resultMap = new HashMap<>();
        this.activateRecordService.updateActivateRecord7(realName,mobile,idNo,passportNo);
        return renderSuccess(resultMap);
    }

    /**
     * Pab call json result.
     *
     * @param channelCode  the channel code
     * @param businessCode the business code
     * @return the json result
     */
    @RequestMapping(value = "/pabCall", method = RequestMethod.GET)
    @ApiOperation(value = "返回信息给渠道方", notes = "返回信息给渠道方")
    public JsonResult pabCall(@RequestParam("channelCode") String channelCode,@RequestParam("businessCode") String businessCode) {
        BankAccount bankAccount = this.bankAccountService.selectByBankAct("6222981312219041");
        Insurance insurance = this.insuranceService.selectByInsuranceNo("PC0200A106477439");
        this.channelService.sendBankActAndInsurance2Channel(channelCode,businessCode,"", bankAccount, insurance);
        return renderSuccess();
    }
}
 
 