package cn.dakaqi.blank.controller.response;

import java.util.List;

@SuppressWarnings("unused")
public class ListDataResponseVo<T> extends BaseResponseVo {

    private List<T> data;

    public ListDataResponseVo(Integer statusCode, String statusMessage, List<T> data) {
        super(statusCode, statusMessage);
        this.data = data;
    }

    public ListDataResponseVo(Integer statusCode, String statusMessage) {
        super(statusCode, statusMessage);
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }
}