package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.AdminUser;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
public interface IAdminUserService extends IService<AdminUser>
{
     AdminUser selectByMobile(String mobile);
}
