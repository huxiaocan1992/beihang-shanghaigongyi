package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;

/**
 * Created by chunyang on 2015/8/18.
 */
public class BHNotice implements Serializable
{
    Long noticeId;
    String noticeTitle;
    String createDate;
    String senderName;
    String link;
    String msgType;//1 系统通知 2快讯播报 3紧急通知

    public BHNotice(Long noticeId, String noticeTitle, String createDate, String senderName, String link, String msgType)
    {
        this.noticeId = noticeId;
        this.noticeTitle = noticeTitle;
        this.createDate = createDate;
        this.senderName = senderName;
        this.link = link;
        if("1".equals(msgType))
            this.msgType = "系统通知";
        else if("2".equals(msgType))
        {
            this.msgType = "快讯播报";
        }
        else if("3".equals(msgType))
        {
            this.msgType = "紧急通知";
        }
    }

    public BHNotice()
    {
    }

    public Long getNoticeId()
    {
        return noticeId;
    }

    public void setNoticeId(Long noticeId)
    {
        this.noticeId = noticeId;
    }

    public String getNoticeTitle()
    {
        return noticeTitle;
    }

    public void setNoticeTitle(String noticeTitle)
    {
        this.noticeTitle = noticeTitle;
    }

    public String getCreateDate()
    {
        return createDate;
    }

    public void setCreateDate(String createDate)
    {
        this.createDate = createDate;
    }

    public String getSenderName()
    {
        return senderName;
    }

    public void setSenderName(String senderName)
    {
        this.senderName = senderName;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String link)
    {
        this.link = link;
    }

    public String getMsgType()
    {
        return msgType;
    }

    public void setMsgType(String msgType)
    {
        this.msgType = msgType;
    }

    @Override
    public String toString()
    {
        return "BHNotice{" +
                "noticeId=" + noticeId +
                ", noticeTitle='" + noticeTitle + '\'' +
                ", createDate='" + createDate + '\'' +
                ", senderName='" + senderName + '\'' +
                ", link='" + link + '\'' +
                ", msgType='" + msgType + '\'' +
                '}';
    }
}
