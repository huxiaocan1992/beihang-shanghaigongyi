package cn.dakaqi.blank.controller.response;

@SuppressWarnings("unused")
public class DataResponseVo<T> extends BaseResponseVo {

    private T data;

    public DataResponseVo() {}

    public DataResponseVo(Integer code, String message, T data) {
        super(code, message);
        this.data = data;
    }

    public DataResponseVo(Integer code, String message) {
        super(code, message);
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}