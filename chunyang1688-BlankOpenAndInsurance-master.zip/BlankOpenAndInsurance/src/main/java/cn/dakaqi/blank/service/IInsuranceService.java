package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.Insurance;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-02
 */
public interface IInsuranceService extends IService<Insurance>
{
    Insurance saveInsurance(String channelCode,String bussionCode,String idNo,String groupCode,String volunteerCode,String realName,String mobile)throws Exception;
    Insurance selectByVolunteerCode(String volunteerCode);
    Insurance selectByInsuranceNo(String insuranceNo);
}
