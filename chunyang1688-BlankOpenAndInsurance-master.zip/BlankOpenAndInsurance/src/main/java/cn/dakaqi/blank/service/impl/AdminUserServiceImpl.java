package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.AdminUser;
import cn.dakaqi.blank.mapper.AdminUserMapper;
import cn.dakaqi.blank.service.IAdminUserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *   服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
@Service
public class AdminUserServiceImpl extends ServiceImpl<AdminUserMapper, AdminUser> implements IAdminUserService {

    @Autowired
    private AdminUserMapper adminUserMapper;

    @Override
    public AdminUser selectByMobile(String mobile) {
        return adminUserMapper.selectByMobile(mobile);
    }
}
