package cn.dakaqi.blank.service;

import cn.dakaqi.blank.controller.response.SubmitSuccessResponseItem;
import cn.dakaqi.blank.entity.OrderInfo;
import com.baomidou.mybatisplus.service.IService;

import java.io.InputStream;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
public interface OrderInfoService extends IService<OrderInfo>
{
    String wxCallback(InputStream inputStream);

    SubmitSuccessResponseItem unifiedOrder(String ipStr, String orderCode, String openId);
}
