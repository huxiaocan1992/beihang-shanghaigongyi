package cn.dakaqi.blank.entity.vo;

import cn.dakaqi.blank.entity.Channel;

import java.util.Date;

/**
 * Created by yangx
 * CreateTime: 2016/12/8 13:58
 */
public class ChannelResponseVo {

    private Long id;

    /**
     *
     */
    private String code;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 渠道名称
     */
    private String name;

    /**
     * 业务：A保险业务,B平安银行,C护照申请,D护照激活,E其他捐赠
     */
    private String business;

    /**
     * 商户类型：10个人，20团体
     */
    private Integer shopType;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 是否被冻结 10 未冻结 -10 已冻结
     */
    private Integer frozen;

    /**
     * 渠道-业务的CODE,eg:A00001
     */
    private String businessCode;

    /**
     * 新增渠道是否被管理员批准 10 批准 -10 未批准
     * 注：未批准的记录处于删除状态。
     */
    private Integer approval;

    public String getBaseAddress()
    {
        return baseAddress;
    }

    public void setBaseAddress(String baseAddress)
    {
        this.baseAddress = baseAddress;
    }

    private String baseAddress;

    public static ChannelResponseVo build(Channel channel){
        ChannelResponseVo channelResponseVo = new ChannelResponseVo();
        channelResponseVo.setId(channel.getId());
        channelResponseVo.setCode(channel.getCode());
        channelResponseVo.setMobile(channel.getMobile());
        channelResponseVo.setName(channel.getName());
        channelResponseVo.setBusiness(channel.getBusiness());
        channelResponseVo.setShopType(channel.getShopType());
        channelResponseVo.setCreateTime(channel.getCreateTime());
        channelResponseVo.setBusinessCode(channel.getBusinessCode());
        channelResponseVo.setApproval(channel.getApproval());
        channelResponseVo.setFrozen(channel.getFrozen());
        channelResponseVo.setBaseAddress(channel.getBaseAddress());
        return channelResponseVo;
    }




    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public Integer getShopType() {
        return shopType;
    }

    public void setShopType(Integer shopType) {
        this.shopType = shopType;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public Integer getApproval() {
        return approval;
    }

    public void setApproval(Integer approval) {
        this.approval = approval;
    }

    public Integer getFrozen() {
        return frozen;
    }

    public void setFrozen(Integer frozen) {
        this.frozen = frozen;
    }


}
