package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.response.CallBackVO;
import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.OrderInfo;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.service.OrderInfoService;
import cn.dakaqi.blank.util.DateUtil;
import cn.dakaqi.blank.util.HttpInvoker;
import cn.dakaqi.blank.util.OrderStatus;
import cn.dakaqi.blank.util.wechatPay.XMLUtil;
import com.alibaba.fastjson.JSONObject;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/order")
@Slf4j
@ApiIgnore
public class OrderController {

    @Resource
    private OrderInfoService orderInfoService;

    @Resource
    private ITradeListService tradeListService;

    @Resource
    private IChannelService channelService;

    @ResponseBody
    @RequestMapping(value = "/paySuccessScan")
    public DataResponseVo<Object> paySuccessScan() {
//        return commodityOrderService.orderPaySuccessScan(request, memberInfo.getMemberInfoId());
        log.info("test");
        return null;
    }

    @RequestMapping(value = "/success", method = RequestMethod.POST)
    @ResponseBody
    public String success(HttpServletRequest request) throws IOException {
        log.info("/OrderController/success, requestUrl");
        //读取微信回调信息
        InputStream inStream = request.getInputStream();
        String result = "";
        try {
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;

            while ((len = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            result = new String(outStream.toByteArray(), "utf-8");
            outStream.close();
            inStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        //如果微信回调信息存在
        if (StringUtils.isNotEmpty(result.trim())) {
            Map map = XMLUtil.doXMLParse(result);

            //并且返回支付成功
            if (map != null && map.get("result_code").toString().equalsIgnoreCase("SUCCESS")) {
                //解析支付成功数据
                String orderCode = (map.get("out_trade_no") != null) ? map.get("out_trade_no").toString() : "1212321211201407033568112322";
                String timePayed = (map.get("time_end") != null) ? map.get("time_end").toString() : "20141030133525";
                Date payTime = DateUtil.str2Date(timePayed, "yyyyMMddHHmmss");
                String transactionId = (map.get("transaction_id") != null) ? map.get("transaction_id").toString() : "1217752501201407033233368018";
                String bankType = (map.get("bank_type") != null) ? map.get("bank_type").toString() : "CMC";
                String feeType = (map.get("fee_type") != null) ? map.get("fee_type").toString() : "CNY";
                String tradeType = (map.get("trade_type") != null) ? map.get("trade_type").toString() : "JSAPI";
                String totalFee = (map.get("total_fee") != null) ? map.get("total_fee").toString() : "1";
                String mchId = (map.get("mch_id") != null) ? map.get("mch_id").toString() : "1";
                String openid = (map.get("openid") != null) ? map.get("openid").toString() : "1";

                //获取订单编号   五位渠道编号+六位业务编号+六位订单时间+8位经过偏移的UUID+六位提交订单时时间戳
//                String chanelCode = orderCode.substring(0, 4);
                orderCode = orderCode.substring(0, 25);

                Map<String, Object> mapParam = new HashMap<>();
                mapParam.put("orderCode", orderCode);
                List<OrderInfo> orderInfoList = orderInfoService.selectByMap(mapParam);
                if (orderInfoList.size() == 1) {
                    OrderInfo orderInfo = orderInfoList.get(0);

                    orderInfo.setUpdateTime(new Date());
                    orderInfo.setOpenId(openid);
                    orderInfo.setOrderStatus(OrderStatus.FINISHED.getSequenceId());
                    orderInfo.setPayState(2); //1 待支付 2 支付成功
                    orderInfo.setPayPattern(1);//默认1网页支付

                    orderInfo.setPayTime(payTime);
                    orderInfo.setTransactionId(transactionId);
                    orderInfo.setBankType(bankType);
                    orderInfo.setFeeType(feeType);
                    orderInfo.setTradeType(tradeType);
                    orderInfo.setMchId(mchId);
                    orderInfo.setTotalFee(totalFee);
                    orderInfo.setTimeEnd(timePayed);

                    boolean resultBoolean = orderInfoService.updateById(orderInfo);

                    if (resultBoolean) {
                        TradeList tradeList = new TradeList();
                        tradeList.setOpenId(orderInfo.getOpenId());
                        tradeList.setBusiness(orderInfo.getOrderBusiness());
                        tradeList.setChannel(orderInfo.getOrderChannel());
                        tradeList.setFinishDate(orderInfo.getPayTime());
                        tradeList.setMoney(orderInfo.getTotal());
                        tradeList.setOrderCode(orderInfo.getOrderCode());
                        tradeListService.insert(tradeList);

                        Channel channel = channelService.selectByCode(orderInfo.getOrderChannel());

                        log.info("/OrderController/success, channel ============== > " + channel.toString());
                        if (StringUtils.isNotEmpty(channel.getOrderRetUrl())) {
                            CallBackVO callBackVO = CallBackVO.build(orderInfo);
                            String json = JSONObject.toJSONString(callBackVO);
                            HttpInvoker.httpPost(channel.getOrderRetUrl(), new HashMap<>(), json);
                        }

                        return "SUCCESS";
                    } else {
                        log.error("update OrderInfo Error , Id ： " + orderInfo.getId());
                    }

                } else {
                    log.error("orderInfo exists error Number by : " + orderCode);
                }

            }
        }
        return "FAIL";
    }

    public static void main(String[] args) {

        String json = "{\"id\":\"20\",\"name\":\"李博\"}";
        try {
            HttpInvoker.httpPost("http://127.0.0.1:8080/team/findById", new HashMap<>(), json);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
