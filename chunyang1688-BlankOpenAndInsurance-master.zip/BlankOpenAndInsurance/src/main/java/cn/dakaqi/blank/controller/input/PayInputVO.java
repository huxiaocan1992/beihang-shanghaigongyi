/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.input;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 类名称：PayInputVO <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016/12/8 15:47
 */
@ToString
@Data
@Slf4j
@ApiModel
public class PayInputVO implements Serializable {
    @ApiModelProperty(value = "渠道编号", required = true, dataType = "String")
    @NotNull(message = "渠道编号不能为空")
    private String channelCode;
    @ApiModelProperty(value = "业务代码", required = true, dataType = "String")
    @NotNull(message = "业务代码不能为空")
    private String businessCode;
    @ApiModelProperty(value = "捐款项目", required = true, dataType = "String")
    @NotNull(message = "捐款项目不能为空")
    private String projectName;
    @ApiModelProperty(value = "捐款金额", required = true, dataType = "Float")
    @NotNull(message = "捐款金额不能为空")
    private float money;
    @ApiModelProperty(value = "第三方支付用户ID", required = true, dataType = "String")
    private String userId;
    @ApiModelProperty(value = "第三方订单编号", required = true, dataType = "String")
    private String orderCode;
}