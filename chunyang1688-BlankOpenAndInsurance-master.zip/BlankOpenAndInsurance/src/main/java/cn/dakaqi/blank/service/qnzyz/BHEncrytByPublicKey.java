package cn.dakaqi.blank.service.qnzyz;

import cn.dakaqi.blank.util.RSAUtils;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/16.
 * Description:
 */
@Service
public class BHEncrytByPublicKey
{
    @Autowired
    BHConstant bhConstant;
    /**
     * 公钥加密码
     * @param clientID
     * @param message
     * @return
     */
    public String encryptByPublicKey(String clientID,String message)
    {
        try
        {
            byte[] data = message.getBytes();
            byte[] encodedData = RSAUtils.encryptByPublicKey(data, BHConstant.PUBLICKEY);
            //message = new String(Base64.encodeBase64(encodedData, false, true),"UTF-8");
            message = new String(Base64.encodeBase64URLSafe(encodedData),"UTF-8");
            //System.out.println(temp+"---加密后--->" + message);

        } catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            return message;
        }
    }

    /**
     *  公钥解密
     * @param clientID
     * @param message
     * @return
     */
    public String decryptByPublicKey(String clientID,String message)
    {
        try
        {
            String publicKey = BHConstant.PUBLICKEY;
            byte[] data = message.getBytes();
            byte[] encodedData = RSAUtils.decryptByPublicKey(Base64.decodeBase64(data), publicKey);
            message = new String(encodedData,"UTF-8");
            //System.out.println(temp+"---解密后--->" + message);

        } catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            return message;
        }
    }
}
