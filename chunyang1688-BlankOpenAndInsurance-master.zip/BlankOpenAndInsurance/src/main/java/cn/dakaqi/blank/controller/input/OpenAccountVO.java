package cn.dakaqi.blank.controller.input;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 类名称：OpenAccountVO <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016 /11/30 16:36
 */
@Data
@Slf4j
@ToString
@ApiModel
public class OpenAccountVO implements Serializable {
    private static final long serialVersionUID = 7579016469580008663L;
    /**
     * 渠道编号
     */
    @ApiModelProperty(value = "渠道号不能为空", required = true, dataType = "String")
    @NotNull(message = "渠道号不能为空")
    private String channelCode;

    /**
     * 业务代码
     */
    @ApiModelProperty(value = "业务代码不能为空", required = true, dataType = "String")
    @NotNull(message = "业务代码不能为空")
    private String businessCode;
    /**
     * 订单编号
     */
    @ApiModelProperty(value = "订单号不能为空", required = true, dataType = "String")
    @NotNull(message = "订单号不能为空")
    private String orderCode;
    /**
     * 社团一号通，只适用公益执照
     */
    @ApiModelProperty(value = "社团一号通", required = false, dataType = "String")
    private String groupCode;
    /**
     * 公益护照编号，只适用公益执照
     */
    @ApiModelProperty(value = "社团一号通", required = false, dataType = "String")
    private String passportNo;

    String baseAddress;

    /**
     * 当前用户手机号
     */
    @ApiModelProperty(value = "当前用户手机号", required = false, dataType = "String")
    private String mobile;
    /**
     * 志愿者一号通
     */
    @ApiModelProperty(value = "志愿者一号通", required = false, dataType = "String")
    private String volunteerCode;
    /**
     * 姓名
     */
    @ApiModelProperty(value = "姓名", required = false, dataType = "String")
    private String realName;
    /**
     * 证件号
     */
    @ApiModelProperty(value = "证件号", required = false, dataType = "String")
    private String idNo;

    //监护人
    @ApiModelProperty(value = "监护人姓名", required = false, dataType = "String")
    private String guardianName;//监护人姓名
    @ApiModelProperty(value = "监护人证件号", required = false, dataType = "String")
    private String guardianCardNo;//监护人证件号
    @ApiModelProperty(value = "监护人关系", required = false, dataType = "String")
    private String guardianRelation;//监护人关系
    @ApiModelProperty(value = "监护人性别", required = false, dataType = "String")
    private String guardianSex;//监护人性别
    @ApiModelProperty(value = "监护人证件类型", required = false, dataType = "String")
    private String guardianCardType;//监护人证件类型
}
 
 