package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.ChannelExplain;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-01
 */
public interface IChannelExplainService extends IService<ChannelExplain>
{
    ChannelExplain selectByChanel(Long channel);
}
