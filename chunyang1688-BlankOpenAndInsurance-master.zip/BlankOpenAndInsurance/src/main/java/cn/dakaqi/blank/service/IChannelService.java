package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.Insurance;
import cn.dakaqi.blank.entity.vo.ChannelRequestVo;
import cn.dakaqi.blank.util.PageData;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-01
 */
public interface IChannelService extends IService<Channel>
{
    Channel selectByCode(String channelCode);

    void sendBankActAndInsurance2Channel(String channelCode,String businessCode, String orderCode,BankAccount bankAccount, Insurance insurance);

    PageData<Channel> queryPage(ChannelRequestVo vo);

    List<Channel> selectByCodeDesc();

    List<Channel> selectByBusiness(String business);

    Channel selectByMobile(String mobile);
    Page<Channel> testQueryByPage(int pageNumber, int size);

}
