package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;
import java.util.LinkedHashMap;

/**
 * Created by chunyang on 2015/9/17.
 */
public class BHUserTag implements Serializable
{
    public static final  String ORGADMIN = "ORGADMIN";
    public static final  String GROUPADMIN = "GROUPADMIN";
    public static final  String VOLUNTEERADMIN = "VOLUNTEERADMIN";
    static
    {
        LinkedHashMap<String, String> USER_TAG = new LinkedHashMap<String, String>();
        USER_TAG.put("CAIWU", "财务");
        USER_TAG.put("COMPETITION", "已建大赛管理员统计表");
        USER_TAG.put("GROUPADMIN", "团体管理员");
        USER_TAG.put("GROUPBYINSURANCE", "赞助商购买团体保险");
        USER_TAG.put("IS_COMPETITION", "2015项目大赛管理员");
        USER_TAG.put("LOGS", "查看所有登录日志");
        USER_TAG.put("NEWS", "发全网新闻");
        USER_TAG.put("NOTICE", "发全网通知");
        USER_TAG.put("ORGADMIN", "团组织管理员");
        USER_TAG.put("PINAN", "保险公司管理");
        USER_TAG.put("VOLUNTEER", "志愿者角色");
        USER_TAG.put("VOLUNTEERADMIN", "志愿者管理员");
        USER_TAG.put("ZGGQTY", "团员角色");
        USER_TAG.put("ZGGQTYGB", "团干角色");
    }
    public static boolean haveTag(String tags,String tag)
    {
        boolean F = false;
        String values[] = tags.split(",");
        for(String str:values)
        {
            if(str.equals(tag))
                return true;
        }
        return F;
    }
}
