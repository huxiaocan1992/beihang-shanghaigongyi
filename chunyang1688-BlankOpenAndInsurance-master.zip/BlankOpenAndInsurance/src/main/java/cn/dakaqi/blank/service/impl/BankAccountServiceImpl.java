package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.mapper.BankAccountMapper;
import cn.dakaqi.blank.service.IBankAccountService;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-02
 */
@Service
public class BankAccountServiceImpl extends ServiceImpl<BankAccountMapper, BankAccount> implements IBankAccountService {
    @Override
    public BankAccount selectByIdNo(String idNo) {
        try {
            Wrapper<BankAccount> bankAccountWrapper = new Wrapper<BankAccount>() {
                @Override
                public String getSqlSegment() {
                    return " where  idNo = '" + idNo + "'";
                }
            };
            return super.selectOne(bankAccountWrapper);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public BankAccount selectByBankAct(String bankAcnt) {
        try {
            Wrapper<BankAccount> bankAccountWrapper = new Wrapper<BankAccount>() {
                @Override
                public String getSqlSegment() {
                    return " where  bankAcnt = '" + bankAcnt + "' limit 1";
                }
            };
            return super.selectOne(bankAccountWrapper);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
