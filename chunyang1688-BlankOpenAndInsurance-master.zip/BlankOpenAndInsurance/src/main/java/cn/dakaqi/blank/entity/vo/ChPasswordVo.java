package cn.dakaqi.blank.entity.vo;

/**
 * Created by yangx
 * CreateTime: 2016/12/13 16:01
 */

public class ChPasswordVo {

    private String mobile;
    private String passwordOld;
    private String passwordNew;

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPasswordOld() {
        return passwordOld;
    }

    public void setPasswordOld(String passwordOld) {
        this.passwordOld = passwordOld;
    }

    public String getPasswordNew() {
        return passwordNew;
    }

    public void setPasswordNew(String passwordNew) {
        this.passwordNew = passwordNew;
    }
}
