package cn.dakaqi.blank.service.qnzyz;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 *志愿记录
 * Created by chunyang on 2015/8/20.
 */
public class BHRecord implements Serializable
{
//    @property (nonatomic,copy) NSString *activityEndPeriod;//活动结束时间
//    @property (nonatomic,copy) NSString *activityLocation;//活动地址
//    @property (nonatomic,copy) NSString *activityName;//活动名称
//    @property (nonatomic,copy) NSString *activityStartPeriod;//活动开始时间
//    @property (nonatomic,copy) NSString *groupCode;//活动组织方—组织代号
//    @property (nonatomic,copy) NSString *groupName;//活动组织方 名称
//    @property (nonatomic,copy) NSString *recordId;//记录ID
//    @property (nonatomic,copy) NSString *recordStatus;//记录状态，分别有，申请通过和未通过
//    @property (nonatomic,copy) NSString *recordType;//记录类型（暂时未涉及）
//    @property (nonatomic,copy) NSString *serviceHours;//活动时间
//    @property (nonatomic,copy) NSString *serviceScore;//活动积分
//    @property (nonatomic,copy) NSString *claimStatus;//理赔状态
//    @property (nonatomic,copy) NSString *claimId;//理赔记录ID

    private String recordId;//245,
    private String serviceScore;//10,
    private String groupName;//oni测试测试测试测试测试测试测试测试测试测试侧四,
    private String claimId;//98,
    private String claimStatus;//1,
    private String groupCode;//654822654003,
    private String recordStatus;//0,
    private String activityEndPeriod;//20150731 035000,
    private String activityLocation;//佛山10,
    private String recordType;//2,
    private String serviceHours;//12.00,
    private String activityName;//活动10,
    private String activityStartPeriod;//20150728 035000,
    private String activityCode;//4320150729011,
    private String claimStatusName;//已确

    public BHRecord(String recordId, String serviceScore, String groupName, String claimId, String claimStatus, String groupCode, String recordStatus, String activityEndPeriod, String activityLocation, String recordType, String serviceHours, String activityName, String activityStartPeriod, String activityCode, String claimStatusName) {
        this.recordId = recordId;
        this.serviceScore = serviceScore;
        this.groupName = groupName;
        this.claimId = claimId;
        this.claimStatus = claimStatus;
        this.groupCode = groupCode;
        if(StringUtils.isNotEmpty(recordStatus) && !"".equals("null"))
        {
            this.recordStatus = recordStatus;
        }
        else
        {
            this.recordStatus = "2";
        }
        this.recordStatus = recordStatus;
        this.activityEndPeriod = activityEndPeriod;
        this.activityLocation = activityLocation;
        this.recordType = recordType;
        this.serviceHours = serviceHours;
        this.activityName = activityName;
        this.activityStartPeriod = activityStartPeriod;
        this.activityCode = activityCode;
        this.claimStatusName = claimStatusName;
    }

    public BHRecord() {
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getServiceScore() {
        return serviceScore;
    }

    public void setServiceScore(String serviceScore) {
        this.serviceScore = serviceScore;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getClaimId() {
        return claimId;
    }

    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

    public String getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(String claimStatus) {
        this.claimStatus = claimStatus;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getActivityEndPeriod() {
        return activityEndPeriod;
    }

    public void setActivityEndPeriod(String activityEndPeriod) {
        this.activityEndPeriod = activityEndPeriod;
    }

    public String getActivityLocation() {
        return activityLocation;
    }

    public void setActivityLocation(String activityLocation) {
        this.activityLocation = activityLocation;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getServiceHours() {
        return serviceHours;
    }

    public void setServiceHours(String serviceHours) {
        this.serviceHours = serviceHours;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityStartPeriod() {
        return activityStartPeriod;
    }

    public void setActivityStartPeriod(String activityStartPeriod) {
        this.activityStartPeriod = activityStartPeriod;
    }

    public String getActivityCode() {
        return activityCode;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public String getClaimStatusName() {
        return claimStatusName;
    }

    public void setClaimStatusName(String claimStatusName) {
        this.claimStatusName = claimStatusName;
    }

    @Override
    public String toString() {
        return "BHRecord{" +
                "recordId='" + recordId + '\'' +
                ", serviceScore='" + serviceScore + '\'' +
                ", groupName='" + groupName + '\'' +
                ", claimId='" + claimId + '\'' +
                ", claimStatus='" + claimStatus + '\'' +
                ", groupCode='" + groupCode + '\'' +
                ", recordStatus='" + recordStatus + '\'' +
                ", activityEndPeriod='" + activityEndPeriod + '\'' +
                ", activityLocation='" + activityLocation + '\'' +
                ", recordType='" + recordType + '\'' +
                ", serviceHours='" + serviceHours + '\'' +
                ", activityName='" + activityName + '\'' +
                ", activityStartPeriod='" + activityStartPeriod + '\'' +
                ", activityCode='" + activityCode + '\'' +
                ", claimStatusName='" + claimStatusName + '\'' +
                '}';
    }
}
