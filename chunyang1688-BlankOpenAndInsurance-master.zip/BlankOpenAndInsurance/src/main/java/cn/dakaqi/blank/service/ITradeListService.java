package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.entity.Insurance;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.TradeListVo;
import cn.dakaqi.blank.util.PageData;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-07
 */
public interface ITradeListService extends IService<TradeList>
{
    PageData<TradeList> queryPage(TradeListVo vo);
    TradeList selectByCardNoAndBussion(String cardNo,String businessCode);
    boolean insertPingAnOpenTrade(String channelCode, String businessCode, String orderCode,BankAccount bankAccount);
    boolean insertApplyPassportTrade(String channelCode, String businessCode, String orderCode,String realName,String idNo,String mobile,String passportNo);
    boolean insertActivatePassportTrade(String channelCode, String businessCode, String orderCode,String realName,String idNo,String mobile,String passportNo,BankAccount bankAccount);
    boolean insertActivatePassport18Trade(String channelCode, String businessCode, String orderCode,String realName,String idNo,String mobile,String passportNo,BankAccount bankAccount);
    boolean insertBuyInsuranceTrade(String channelCode, String businessCode, String orderCode, BankAccount entity, Insurance insurance);
    boolean insertDonteTrad(TradeList vo);
}
