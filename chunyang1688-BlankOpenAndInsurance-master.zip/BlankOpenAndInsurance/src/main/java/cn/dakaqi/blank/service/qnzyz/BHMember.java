package cn.dakaqi.blank.service.qnzyz;

import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.text.SimpleDateFormat;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/3.
 * Description:
 */
@Component
@ToString
@Slf4j
public class BHMember implements Serializable
{

    private static final long serialVersionUID = -538312259591961744L;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd");
    /**
     * birthday : 20150621
     * volunteerIssuse :
     * volunteerNo : 0
     * userStatus : 0//0审核通过 1待审核  2 审核不通过 3本平台用户 4非本平台用户
     * gender : 2
     * partyUnit :
     * birthPlace : 110102
     * guardianName :
     * orgCode : null
     * joinClycDate : null
     * severiceTerritory : 4
     * cylcUnit :
     * groupCode : 014000706001
     * serviceLocation : null
     * orgName : 中国共产主义青年团江苏省委员会
     * eduLevel : 05
     * guardianMobile :
     * politicalStatus : 3
     * volunteerCode : 32-00000022-0
     * regPlace : null
     * userName : 刘哈
     * partyPost :
     * certificateNo : IS3z7X4SoRQXP9g25NQQ5MbSG3mfNl3+ct2zqdbOz5gLGwHpbDDqTYfa9jhJXAA4FS/Bg6mfU9yrTblGlCwvDtvdgNdS45AslS6e08+zf9Js3wwV004TZNsBVUgZgOHpWtZeNjR4YUzhfcDeoIr/Nk6hKBflaRjElKWokpXV4s4=
     * volunteerScore : 505
     * joinPartyDate : null
     * groupName : 测试组织
     * volunteerServiceHours : 112.32
     * joinVolunteerDate : null
     * nationality : 05
     * userType : 1
     * clycPost :
     * volunteerLevel : 0
     * loginMobile : PEYhI7yyUOvo+9fF6HQ1XHqIbUbomQjvkBISnhXgD7Ku23r14VBwsiKJBQLHveUk7NiFqxvIrQWfpLTsMkWDFyJzyrH26P7BlIwSRFD+waSKrOfkA1XVouBMwkcea+T+BFTeDbVExUCKDFF0LrMYqL7duLb7uEGyKckoEx3ksMg=
     * certificateType : CID
     */
    private String birthday;
    private String volunteerIssuse;
    private String volunteerNo;
    private String userStatus;
    private String gender;
    private String partyUnit;
    private String birthPlace;
    private String guardianName;
    private String orgCode;
    private String joinClycDate;
    private String severiceTerritory;
    private String cylcUnit;
    private String groupCode;
    private String serviceLocation;
    private String orgName;
    private String eduLevel;
    private String guardianMobile;
    private String politicalStatus;
    private String volunteerCode;
    private String regPlace;
    private String userName;
    private String partyPost;
    private String certificateNo;
    private String volunteerScore;
    private String joinPartyDate;
    private String groupName;
    private String volunteerServiceHours;
    private String joinVolunteerDate;
    private String nationality;
    private String userType;
    private String clycPost;
    private String volunteerLevel;
    private String loginMobile;
    private String certificateType;
    private String loginPasswd;
    private String volunteerFlag;



    public BHMember()
    {
    }

    public BHMember(String gender,String birthday, String certificateNo, String certificateType, String clycPost, String cylcUnit, String eduLevel,String volunteerCode,
                    String groupCode, String groupName,String orgCode, String orgName,String guardianMobile, String guardianName, String joinClycDate, String
            joinPartyDate, String joinVolunteerDate, String loginMobile, String loginPasswd, String nationality,
                    String birthPlace, String partyPost, String partyUnit, String volunteerFlag,String politicalStatus, String regPlace,
                    String serviceLocation, String severiceTerritory, String userName, String userType, String
                            voluteerIssuse, String voluteerLevel, String voluteerNo, String voluteerServiceHours,String volunteerScore,String userStatus)
    {
        this.gender = gender;
        this.birthday = birthday;
        this.certificateNo = certificateNo;
        this.certificateType = certificateType;
        this.clycPost = clycPost;
        this.cylcUnit = cylcUnit;
        this.eduLevel = eduLevel;
        this.volunteerCode = volunteerCode;
        this.groupCode = groupCode;
        this.groupName = groupName;
        this.orgCode = orgCode;
        this.orgName = orgName;
        this.guardianMobile = guardianMobile;
        this.guardianName = guardianName;
        this.joinClycDate = joinClycDate;
        this.joinPartyDate = joinPartyDate;
        this.joinVolunteerDate = joinVolunteerDate;
        this.loginMobile = loginMobile;
        this.loginPasswd = loginPasswd;
        this.nationality = nationality;
        this.birthPlace = birthPlace;
        this.partyPost = partyPost;
        this.partyUnit = partyUnit;
        this.volunteerFlag = volunteerFlag;
        this.politicalStatus = politicalStatus;
        this.regPlace = regPlace;
        this.serviceLocation = serviceLocation;
        this.severiceTerritory = severiceTerritory;
        this.userName = userName;
        this.userType = userType;
        this.volunteerIssuse = voluteerIssuse;
        this.volunteerLevel = voluteerLevel;
        this.volunteerNo = voluteerNo;
        this.volunteerServiceHours = voluteerServiceHours;
        this.volunteerScore = volunteerScore;
        this.userStatus = userStatus;
    }

//    public static BHMember toBHMember(Volunteer volunteer,String groupCode)
//    {
//        log.info(volunteer.toString());
//        String clycPost = "", cylcUnit = "",joinClycDate = "";
//        String partyPost = "", partyUnit = "",joinPrtyDate = "";
//        String joinVoluteerDate = "";
//        String volunteerIssuse = "";
//        String nativePlace = volunteer.getNativePlace();
//        if(StringUtils.isNotEmpty(nativePlace))
//        {
//            String[] NativePlace = volunteer.getNativePlace().split("-");
//            nativePlace = CodeMap.area2code(NativePlace[NativePlace.length-1]);
//        }
//
//        String censusRegister = volunteer.getResidenceAddress();
//        if(StringUtils.isNotEmpty(censusRegister))
//        {
//            String[] CensusRegister = volunteer.getResidenceAddress().split("-");
//            censusRegister =  CodeMap.area2code(CensusRegister[CensusRegister.length-1]);
//        }
//
//        String specialty = "";
//        String specialtyAddress = volunteer.getResidenceAddress();
//        if(StringUtils.isNotEmpty(specialtyAddress))
//        {
//            String[] SpecialtyAddress = volunteer.getResidenceAddress().split("-");
//            specialtyAddress = CodeMap.area2code(SpecialtyAddress[SpecialtyAddress.length-1]);
//        }
//
//        String mobile = volunteer.getMobile();
//        String password = MD5Util.MD5("123456");
//        String cardNo = volunteer.getCardNO();
//        String sex = "";
//        if(volunteer.getSex() == null)
//            sex = "1";
//        else
//            sex = volunteer.getSex().equals("男")?"1":"2";
//
//        String birthday = "";
//        String volunteerLevel = "";
//
//        try
//        {
//           specialty = "助老助残";
//
//            volunteerIssuse = "";
//
//            volunteerLevel = "0";
//
//            if(null == volunteer.getBirthDay() || StringUtils.isBlank(volunteer.getBirthDay()) || "null".equals(volunteer.getBirthDay()))
//                birthday = "1990-01-01";
//            else
//                birthday = sdf2.format(sdf.parse(volunteer.getBirthDay()));
//
//        } catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//
//        BHMember bhMember =  new BHMember(sex,birthday,cardNo,cardTypeTransform(volunteer.getCardType()), clycPost, cylcUnit,"10",volunteer.getVolunteerCode(),
//                groupCode,"","","", "", "", joinClycDate, joinPrtyDate,joinVoluteerDate ,
//                mobile, password, "01",nativePlace,partyPost, partyUnit,"","0",censusRegister,specialtyAddress,
//                specialty, volunteer.getRealName(), "6", volunteerIssuse,volunteerLevel, "",  "0","0","0");
//        bhMember.setVolunteerCode(volunteer.getVolunteerCode());
//        bhMember.setGroupCode(groupCode);
//        System.out.println("BHMember toBHMember---------->"+bhMember);
//        return bhMember;
//    }

    private static String cardTypeTransform(String cardType)
    {
        //证件类别
        // GAB 公安现役警官证件或士兵证（边防系统）
        // GAJ 公安现役警官证件或士兵证（警卫系统）
        // GAX 公安现役警官证件或士兵证（消防系统）
        // GAT 港澳居民往来内地通行证
        // TWT 台湾居民往来大陆通行证
        // WJZ 中国武警证件
        // PAS 国际护照
        //member.cardType=06,台湾居民身份证;
        if(StringUtils.isEmpty(cardType))
            cardType = "CID";
        if(cardType.equals("01"))
             cardType = "CID";
        else if(cardType.equals("02"))
            cardType = "JGZ";
        else if(cardType.equals("03") || cardType.equals("07"))
            cardType = "PAS";
        else if(cardType.equals("04") || cardType.equals("05"))
            cardType = "GAT";
        else if(cardType.equals("06"))
            cardType = "TWT";

        return cardType;

    }

    public String getBirthday()
    {
        return birthday;
    }

    public void setBirthday(String birthday)
    {
        this.birthday = birthday;
    }

    public String getVolunteerIssuse()
    {
        return volunteerIssuse;
    }

    public void setVolunteerIssuse(String volunteerIssuse)
    {
        this.volunteerIssuse = volunteerIssuse;
    }

    public String getVolunteerNo()
    {
        return volunteerNo;
    }

    public void setVolunteerNo(String volunteerNo)
    {
        this.volunteerNo = volunteerNo;
    }

    public String getUserStatus()
    {
        return userStatus;
    }

    public void setUserStatus(String userStatus)
    {
        this.userStatus = userStatus;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getPartyUnit()
    {
        return partyUnit;
    }

    public void setPartyUnit(String partyUnit)
    {
        this.partyUnit = partyUnit;
    }

    public String getBirthPlace()
    {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace)
    {
        this.birthPlace = birthPlace;
    }

    public String getGuardianName()
    {
        return guardianName;
    }

    public void setGuardianName(String guardianName)
    {
        this.guardianName = guardianName;
    }

    public String getOrgCode()
    {
        return orgCode;
    }

    public void setOrgCode(String orgCode)
    {
        this.orgCode = orgCode;
    }

    public String getJoinClycDate()
    {
        return joinClycDate;
    }

    public void setJoinClycDate(String joinClycDate)
    {
        this.joinClycDate = joinClycDate;
    }

    public String getSevericeTerritory()
    {
        return severiceTerritory;
    }

    public void setSevericeTerritory(String severiceTerritory)
    {
        this.severiceTerritory = severiceTerritory;
    }

    public String getCylcUnit()
    {
        return cylcUnit;
    }

    public void setCylcUnit(String cylcUnit)
    {
        this.cylcUnit = cylcUnit;
    }

    public String getGroupCode()
    {
        return groupCode;
    }

    public void setGroupCode(String groupCode)
    {
        this.groupCode = groupCode;
    }

    public String getServiceLocation()
    {
        return serviceLocation;
    }

    public void setServiceLocation(String serviceLocation)
    {
        this.serviceLocation = serviceLocation;
    }

    public String getOrgName()
    {
        return orgName;
    }

    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }

    public String getEduLevel()
    {
        return eduLevel;
    }

    public void setEduLevel(String eduLevel)
    {
        this.eduLevel = eduLevel;
    }

    public String getGuardianMobile()
    {
        return guardianMobile;
    }

    public void setGuardianMobile(String guardianMobile)
    {
        this.guardianMobile = guardianMobile;
    }

    public String getPoliticalStatus()
    {
        return politicalStatus;
    }

    public void setPoliticalStatus(String politicalStatus)
    {
        this.politicalStatus = politicalStatus;
    }

    public String getVolunteerCode()
    {
        return volunteerCode;
    }

    public void setVolunteerCode(String volunteerCode)
    {
        this.volunteerCode = volunteerCode;
    }

    public String getRegPlace()
    {
        return regPlace;
    }

    public void setRegPlace(String regPlace)
    {
        this.regPlace = regPlace;
    }

    public String getUserName()
    {
        return userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getPartyPost()
    {
        return partyPost;
    }

    public void setPartyPost(String partyPost)
    {
        this.partyPost = partyPost;
    }

    public String getCertificateNo()
    {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo)
    {
        this.certificateNo = certificateNo;
    }

    public String getVolunteerScore()
    {
        return volunteerScore;
    }

    public void setVolunteerScore(String volunteerScore)
    {
        this.volunteerScore = volunteerScore;
    }

    public String getJoinPartyDate()
    {
        return joinPartyDate;
    }

    public void setJoinPartyDate(String joinPartyDate)
    {
        this.joinPartyDate = joinPartyDate;
    }

    public String getGroupName()
    {
        return groupName;
    }

    public void setGroupName(String groupName)
    {
        this.groupName = groupName;
    }

    public String getVolunteerServiceHours()
    {
        return volunteerServiceHours;
    }

    public void setVolunteerServiceHours(String volunteerServiceHours)
    {
        this.volunteerServiceHours = volunteerServiceHours;
    }

    public String getJoinVolunteerDate()
    {
        return joinVolunteerDate;
    }

    public void setJoinVolunteerDate(String joinVolunteerDate)
    {
        this.joinVolunteerDate = joinVolunteerDate;
    }

    public String getNationality()
    {
        return nationality;
    }

    public void setNationality(String nationality)
    {
        this.nationality = nationality;
    }

    public String getUserType()
    {
        return userType;
    }

    public void setUserType(String userType)
    {
        this.userType = userType;
    }

    public String getClycPost()
    {
        return clycPost;
    }

    public void setClycPost(String clycPost)
    {
        this.clycPost = clycPost;
    }

    public String getVolunteerLevel()
    {
        return volunteerLevel;
    }

    public void setVolunteerLevel(String volunteerLevel)
    {
        this.volunteerLevel = volunteerLevel;
    }

    public String getLoginMobile()
    {
        return loginMobile;
    }

    public void setLoginMobile(String loginMobile)
    {
        this.loginMobile = loginMobile;
    }

    public String getCertificateType()
    {
        return certificateType;
    }

    public void setCertificateType(String certificateType)
    {
        this.certificateType = certificateType;
    }

    public String getLoginPasswd()
    {
        return loginPasswd;
    }

    public void setLoginPasswd(String loginPasswd)
    {
        this.loginPasswd = loginPasswd;
    }

    public String getVolunteerFlag()
    {
        return volunteerFlag;
    }

    public void setVolunteerFlag(String volunteerFlag)
    {
        this.volunteerFlag = volunteerFlag;
    }
}
