package cn.dakaqi.blank.entity.web;

import java.io.Serializable;

/**
 * @author jay
 * <p>
 * Stored in memcached to represent a login user
 */
public class Visitor implements Serializable {
    
    private static final long serialVersionUID = 6699826214127473987L;
    
    private Long loginUserId;
    
    private Byte roleId;
    
    // A token generated for every session
    private String sessionToken;
    
    private int uquip;
    
    private String imei;
    
    private String uToken;
    
    private Long employeeId;
    
    public Long getLoginUserId() {
        return loginUserId;
    }
    
    public void setLoginUserId(Long loginUserId) {
        this.loginUserId = loginUserId;
    }
    
    public Byte getRoleId() {
        return roleId;
    }
    
    public void setRoleId(Byte roleId) {
        this.roleId = roleId;
    }
    
    public String getSessionToken() {
        return sessionToken;
    }
    
    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }
    
    public int getUquip() {
        return uquip;
    }
    
    public void setUquip(int uquip) {
        this.uquip = uquip;
    }
    
    public String getImei() {
        return imei;
    }
    
    public void setImei(String imei) {
        this.imei = imei;
    }
    
    public String getuToken() {
        return uToken;
    }
    
    public void setuToken(String uToken) {
        this.uToken = uToken;
    }
    
    public Long getEmployeeId() {
        return employeeId;
    }
    
    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }
}