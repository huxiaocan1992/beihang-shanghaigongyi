package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-14
 */
@Data
@ToString
@TableName(value = "insuranceUser")
public class InsuranceUser implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 
	 */
	private String name;

	/**
	 * 
	 */
	private String cardNo;

	/**
	 * 
	 */
	private String cardType;

	/**
	 * 
	 */
	private String phone;

	/**
	 * 
	 */
	private String openId;

	/**
	 * 
	 */
	private Date createTime;

}
