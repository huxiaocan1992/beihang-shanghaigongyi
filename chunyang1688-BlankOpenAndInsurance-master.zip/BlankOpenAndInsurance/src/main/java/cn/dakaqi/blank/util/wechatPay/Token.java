package cn.dakaqi.blank.util.wechatPay;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

@Data
@ToString
public class Token extends BaseResult {

    private String access_token;

    private int expires_In;

    private Date validTime;

    private static Token token;

    private Token() {
    }

    public static Token getInstance() {
        if (token == null)
            token = new Token();
        return token;
    }

    public static void clearToken() {
        token = null;
    }
}
