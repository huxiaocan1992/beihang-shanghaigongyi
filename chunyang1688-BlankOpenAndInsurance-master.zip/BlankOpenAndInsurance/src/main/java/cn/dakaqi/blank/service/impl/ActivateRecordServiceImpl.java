package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.ActivateRecord;
import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.mapper.ActivateRecordMapper;
import cn.dakaqi.blank.service.IActivateRecordService;
import cn.dakaqi.blank.service.IBankAccountService;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.util.Clock;
import cn.dakaqi.blank.util.Constant;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *   服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-20
 */
@Service
public class ActivateRecordServiceImpl extends ServiceImpl<ActivateRecordMapper, ActivateRecord> implements IActivateRecordService
{
    @Autowired
    IBankAccountService bankAccountService;
    @Autowired
    ITradeListService tradeListService;

    @Override
    public ActivateRecord selectByIdNO(String idNo)
    {
        Wrapper<ActivateRecord> wrapper = new EntityWrapper<ActivateRecord>();
        wrapper.eq("idNo",idNo);
        return super.selectOne(wrapper);
    }

    @Override
    public boolean insertRecord(String idNo, String passportNo)
    {
        updateTradeListPassportNO(idNo,passportNo,"F");
        BankAccount bankAccount = bankAccountService.selectByIdNo(idNo);
        if(null != bankAccount)
        {
            ActivateRecord activateRecord = new ActivateRecord();
            activateRecord.setBackAccount(bankAccount.getBankAcnt());
            activateRecord.setRealName(bankAccount.getRealName());
            activateRecord.setMobile(bankAccount.getMobile());
            activateRecord.setIdNo(bankAccount.getIdNo());
            activateRecord.setPassportNo(passportNo);
            activateRecord.setStatus(Constant.ACTIVATE_STATUS_YES);
            activateRecord.setCreateTime(Clock.DEFAULT.getCurrentDate() );
            return super.insert(activateRecord);
        }
        return false;
    }

    @Override
    public boolean updateActivateRecord7(String realName, String mobile, String idNo, String passportNo)
    {
        updateTradeListPassportNO(idNo,passportNo,"G");
        ActivateRecord activateRecord = new ActivateRecord();
        activateRecord.setBackAccount("");
        activateRecord.setRealName(realName);
        activateRecord.setMobile(mobile);
        activateRecord.setIdNo(idNo);
        activateRecord.setPassportNo(passportNo);
        activateRecord.setStatus(Constant.ACTIVATE_STATUS_YES);
        activateRecord.setCreateTime(Clock.DEFAULT.getCurrentDate() );
        return super.insert(activateRecord);

    }

    @Override
    public boolean updateActivateRecord18(String realName,  String idNo, String guardianCardNo,String passportNo) {
        updateTradeListPassportNO(idNo,passportNo,"G");
        BankAccount bankAccount = bankAccountService.selectByIdNo(guardianCardNo);
        if(null != bankAccount)
        {
            ActivateRecord activateRecord = new ActivateRecord();
            activateRecord.setBackAccount(bankAccount.getBankAcnt());
            activateRecord.setRealName(realName);
            activateRecord.setMobile(bankAccount.getMobile());
            activateRecord.setIdNo(idNo);
            activateRecord.setPassportNo(passportNo);
            activateRecord.setStatus(Constant.ACTIVATE_STATUS_YES);
            activateRecord.setCreateTime(Clock.DEFAULT.getCurrentDate() );
            return super.insert(activateRecord);
        }
        return false;
    }

    private void updateTradeListPassportNO(String idNo, String passportNo,String bussion)
    {
        TradeList tradeList = this.tradeListService.selectByCardNoAndBussion(idNo,bussion);
        if(null != tradeList)
        {
            tradeList.setPassportCode(passportNo);
            this.tradeListService.updateById(tradeList);
        }
    }
}
