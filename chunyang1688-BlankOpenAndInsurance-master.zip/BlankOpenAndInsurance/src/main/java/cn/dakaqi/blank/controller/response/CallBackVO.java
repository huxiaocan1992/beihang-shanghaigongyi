package cn.dakaqi.blank.controller.response;

import cn.dakaqi.blank.entity.OrderInfo;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 类名称：BankVO <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016/12/6 11:34
 */

@Data
@ToString
@Slf4j
public class CallBackVO implements Serializable {
    private String channelCode;
    private String businessCode;
    private String project;
    private BigDecimal money;
    private String userId;
    private String orderCode;
    private String payCenterUuid;//支付中心订单uuid
    private Integer payPattern;//支付方式
    private String transactionId;//微信交易ID
    private String totalFee;//实际支付金额
    private String timeEnd;//支付完成时间，格式为yyyyMMddHHmmss

    public static CallBackVO build(OrderInfo orderInfo) {
        CallBackVO callBackVO = new CallBackVO();
        callBackVO.setChannelCode(orderInfo.getOrderChannel());
        callBackVO.setBusinessCode(orderInfo.getOrderBusiness());
        callBackVO.setProject(orderInfo.getBeneficiary());
        callBackVO.setMoney(orderInfo.getTotal());
        if (StringUtils.isNotEmpty(orderInfo.getSourcePayUser())){
            callBackVO.setUserId(orderInfo.getSourcePayUser());
        }

        if (StringUtils.isNotEmpty(orderInfo.getSourceOrderCode())){
            callBackVO.setOrderCode(orderInfo.getSourceOrderCode());
        }

        callBackVO.setPayCenterUuid(orderInfo.getUuid());
        callBackVO.setPayPattern(orderInfo.getPayPattern());
        callBackVO.setTransactionId(orderInfo.getTransactionId());
        callBackVO.setTotalFee(orderInfo.getTotalFee());
        callBackVO.setTimeEnd(orderInfo.getTimeEnd());

        return callBackVO;
    }
}
 
 