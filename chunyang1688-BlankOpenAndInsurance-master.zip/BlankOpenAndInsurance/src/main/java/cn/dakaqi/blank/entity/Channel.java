package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
@TableName(value = "channel")
@Data
@ToString
public class Channel implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 渠道代码
	 */
	private String code;

	/**
	 * 渠道名称
	 */
	private String name;

	/**
	 * 是否需要购买保险 10不需要 20需要
	 */
	private Integer hasInsurance;

	/**
	 * 回调地址
	 */
	private String retUrl;

	/**
	 * 页面回调地址
	 */
	private String pageRetUrl;

	/**
	 * 支付结果回调地址
	 */
	private String orderRetUrl;

	/**
	 * 是否被删除 10 未删除 -10 已删除
	 */
	private Integer delStatus;

	/**
	 * 创建时间
	 */
	private Date createTime;

	/**
	 * 修改时间 //
	 */
	private Date updateTime;

	/**
	 * 手机号
	 */
	private String mobile;

	/**
	 * 密码
	 */
	private String passWord;

	/**
	 * 商户类型：10个人，20团体
	 */
	private Integer shopType;

	/**
	 * 是否被冻结 10 未冻结 -10 已冻结
	 */
	private Integer frozen;


	/**
	 * 新增渠道是否被管理员批准 10 批准 -10 未批准
	 * 注：未批准的记录处于删除状态。
	 */
	private Integer approval;


	/**
	 * 业务：A保险业务,B平安银行,C护照申请,D护照激活,E其他捐赠 F团体护照业务
	 */
	private String business;

	/**
	 * 渠道-业务的CODE,eg:A00001
	 */
	private String businessCode;

	/**
	 * 基地编号
	 */
	private String baseAddress;

	/**
	 * 渠道-业务的二维码
	 */
	private String ORCode;

	/**
	 * 机构名称
	 */
	private String orgName;

	/**
	 * 图片
	 */
	private String picture;

	/**
	 * 开户行
	 */
	private String bankName;

	/**
	 * 银行卡号
	 */
	private String cardNo;
}
