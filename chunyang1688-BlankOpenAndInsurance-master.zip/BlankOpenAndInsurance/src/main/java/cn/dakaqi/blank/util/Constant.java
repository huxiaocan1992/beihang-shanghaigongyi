/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.util;

import java.io.Serializable;
import java.util.ResourceBundle;

/**
 * 类名称：Constant <br>
 * 类描述：常量类
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/1 14:34
 * @version: 1.0.0
 */

public class Constant implements Serializable
{
    private static final long serialVersionUID = 866870983261388479L;
    /**
     * 是否被删除 10 未删除 -10 已删除
     */
    public static final Integer DEL_STATUS_NO = 10;
    public static final Integer DEL_STATUS_YES = -10;

    /**
     * 是否需要购买保险 -10不需要 10需要
     */
    public static final Integer HAS_INSURANCE_NO = -10;
    public static final Integer HAS_INSURANCE_YES = 10;

    /**
     * 是否激活 -10 未 10已
     */
    public static final Integer INSURANCE_STATUS_VALID = 10;
    public static final Integer INSURANCE_STATUS_UNVALID = -10;

    /**
     * 新增渠道是否被管理员批准 10 批准 -10 未批准
     * 注：未批准的记录处于删除状态。
     */
    public static final Integer APPROVAL_STATUS_YES = 10;
    public static final Integer APPROVAL_STATUS_NO = -10;


    /**
     * 是否被冻结 10 未冻结 -10 已冻结
     */
    public static final Integer FROZEN_STATUS_NO = 10;
    public static final Integer FROZEN_STATUS_YES = -10;


    /**
     * 业务代码(备份)
     */
    public static final String BUSINESS_INSURANCE_ = "A";
    public static final String BUSINESS_PINGAN_BANK = "B";
    public static final String BUSINESS_PASSPORT_ACTIVATION = "C";
    public static final String BUSINESS_PASSPORT_APPLY = "D";
    public static final String BUSINESS_OTHER = "E";


    /**
     * 激活状态 10未 20已
     */
    public static final Integer ACTIVATE_STATUS_YES = 20;
    public static final Integer ACTIVATE_STATUS_NO = 10;

    public static String getQRUrl()
    {
        ResourceBundle bundle = ResourceBundle.getBundle("config");
        return bundle.getString("QR_CODE_BASE_URL");
    }

    public static String getJDUrl()
    {
        ResourceBundle bundle = ResourceBundle.getBundle("config");
        return bundle.getString("JD_PATH");
    }
    public static String getPABUrl()
    {
        ResourceBundle bundle = ResourceBundle.getBundle("config");
        return bundle.getString("PAB_PATH");
    }

}
 
 