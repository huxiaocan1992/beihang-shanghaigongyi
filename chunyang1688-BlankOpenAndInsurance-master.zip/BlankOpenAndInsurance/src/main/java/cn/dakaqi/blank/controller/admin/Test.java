package cn.dakaqi.blank.controller.admin;

import cn.dakaqi.blank.util.Identities;

/**
 * Created by yangx
 * CreateTime: 2016/12/9 20:10
 */
public class Test {
    public static void main(String[] args){
        System.out.println(Identities.randomBase62(5));
    }
}
