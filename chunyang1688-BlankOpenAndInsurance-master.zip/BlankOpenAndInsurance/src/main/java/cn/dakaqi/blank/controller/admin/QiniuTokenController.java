package cn.dakaqi.blank.controller.admin;

import cn.dakaqi.blank.qiniu.JsonResult;
import cn.dakaqi.blank.qiniu.QNiuToken;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yangx
 * CreateTime: 2016/12/16 16:54
 */
@Controller
@RequestMapping("/qiniu")
public class QiniuTokenController {

    @RequestMapping(value = "/queryToken")
    public ResponseEntity<?> token() {
        JsonResult result = new JsonResult();
        try {
            String token = QNiuToken.token("dakaqi");
            result.setCode(JsonResult.CODE_SUCCESS);
            result.setMessage("获取成功");
            Map<String, Object> resultMap = new HashMap<String, Object>();
            resultMap.put("token", token);
            result.setData(resultMap);
        } catch (Exception e) {
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            result.setData("");
        }
        return new ResponseEntity<Object>(result, HttpStatus.OK);
    }

}
