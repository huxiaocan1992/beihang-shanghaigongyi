package cn.dakaqi.blank.util.wechatPay;

import cn.dakaqi.blank.util.ConfigUtil;
import org.apache.http.Header;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.security.KeyStoreException;
import java.util.Map;

public class PayMchAPI {

    private static Logger LOGGER = LoggerFactory.getLogger(PayMchAPI.class);

    protected static Header xmlHeader = new BasicHeader(HttpHeaders.CONTENT_TYPE,
            ContentType.APPLICATION_XML.toString());

    /**
     * Send order to wechat
     *
     * @param unifiedOrder
     * @param key
     * @return
     */
    public static UnifiedOrderResult payUnifiedorder(UnifiedOrder unifiedOrder, String key) {
        Map<String, String> map = MapUtil.objectToMap(unifiedOrder);
        if (key != null) {
            String sign = SignatureUtil.generateSign(map, key);
            unifiedOrder.setSign(sign);
        }

        String unifiedOrderXML = XMLConvertUtil.convertToXML(unifiedOrder);
        LOGGER.info("/PayMchAPI/payUnifiedorder, unifiedorderXML " + unifiedOrderXML);
        assert unifiedOrderXML != null;
        HttpUriRequest httpUriRequest = RequestBuilder.post().setHeader(xmlHeader)
                .setUri(ConfigUtil.getMchUri() + "/pay/unifiedorder")
                .setEntity(new StringEntity(unifiedOrderXML, Charset.forName("utf-8"))).build();
        UnifiedOrderResult result = LocalHttpClient.executeXmlResult(httpUriRequest, UnifiedOrderResult.class);
        LOGGER.info("/PayMchAPI/payUnifiedorder, result " + result);
        LOGGER.info("/PayMchAPI/payUnifiedorder, result return message : " + result.getReturn_msg());
        return result;
    }

    /**
     * Send pay refund to wechat
     *
     * @param refund
     * @param key
     * @return
     * @throws KeyStoreException
     * @throws Exception
     */
    public static RefundResult payRefund(Refund refund, String key, String cert, String mchId) {
        Map<String, String> map = MapUtil.objectToMap(refund);
        if (key != null) {
            String sign = SignatureUtil.generateSign(map, key);
            refund.setSign(sign);
        }
        String refundXML = XMLConvertUtil.convertToXML(refund);
        LOGGER.info("/PayMchAPI/payRefund, refundXML " + refundXML);
        HttpUriRequest httpUriRequest = RequestBuilder.post().setHeader(xmlHeader)
                .setUri("/secapi/pay/refund")
                .setEntity(new StringEntity(refundXML, Charset.forName("utf-8"))).build();
        RefundResult result = LocalHttpClient.executeSSLXmlResult(httpUriRequest, RefundResult.class, cert, mchId);
        LOGGER.info("/PayMchAPI/payRefund, result " + result);
        return result;
    }

    /**
     * Send pay refund query to wechat
     *
     * @param refund
     * @param key
     * @return
     */
    public static RefundQueryResult payRefundQuery(RefundQuery refund, String key) {
        Map<String, String> map = MapUtil.objectToMap(refund);
        if (key != null) {
            String sign = SignatureUtil.generateSign(map, key);
            refund.setSign(sign);
        }
        String refundXML = XMLConvertUtil.convertToXML(refund);
        LOGGER.info("/PayMchAPI/refundquery, refundXML " + refundXML);
        HttpUriRequest httpUriRequest = RequestBuilder.post().setHeader(xmlHeader)
                .setUri("/pay/refundquery")
                .setEntity(new StringEntity(refundXML, Charset.forName("utf-8"))).build();
        RefundQueryResult result = LocalHttpClient.executeXmlResult(httpUriRequest, RefundQueryResult.class);
        LOGGER.info("/PayMchAPI/refundquery, result " + result);
        return result;
    }

    public static PayQueryResult payOrderQueryResult(PayOrderQuery payOrderQuery, String key) {
        Map<String, String> map = MapUtil.objectToMap(payOrderQuery);
        if (key != null) {
            String sign = SignatureUtil.generateSign(map, key);
            payOrderQuery.setSign(sign);
        }
        String payOrderQueryXML = XMLConvertUtil.convertToXML(payOrderQuery);
        LOGGER.info(
                "/PayMchAPI/PayOrderQueryResult, payOrderQueryXML " + payOrderQueryXML);
        HttpUriRequest httpUriRequest = RequestBuilder.post().setHeader(xmlHeader)
                .setUri("/pay/orderquery")
                .setEntity(new StringEntity(payOrderQueryXML, Charset.forName("utf-8"))).build();
        PayQueryResult result = LocalHttpClient.executeXmlResult(httpUriRequest, PayQueryResult.class);
        LOGGER.info("/PayMchAPI/PayOrderQueryResult, payOrderQueryXML " + result);
        return result;
    }
}
