package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.controller.response.BankVO;
import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.Insurance;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.ChannelRequestVo;
import cn.dakaqi.blank.mapper.ChannelMapper;
import cn.dakaqi.blank.rsa.AesTest;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.util.*;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-01
 */
@Service
@Slf4j
public class ChannelServiceImpl extends ServiceImpl<ChannelMapper, Channel> implements IChannelService {

    @Resource
    private ITradeListService tradeListService;

    @Resource
    private ChannelMapper channelMapper;

    @Override
    public Channel selectByCode(String channelCode) {
        try {
            Wrapper<Channel> channelWrapper = new Wrapper<Channel>() {
                @Override
                public String getSqlSegment() {
                    return " where delStatus =  " + Constant.DEL_STATUS_NO + " and code = '" + channelCode + "'";
                }
            };
            return super.selectOne(channelWrapper);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void sendBankActAndInsurance2Channel(String channelCode, String businessCode, String orderCode, BankAccount bankAccount, Insurance insurance) {
        Channel channel = this.selectByCode(channelCode);
        if (null == channel)
            return;

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("orderCode",orderCode );
        if(null != bankAccount)
        resultMap.put("bankAccount", BankVO.buildBankVO(bankAccount));
        if(null != insurance)
        resultMap.put("insurance", insurance);
        try {
            JsonResult jsonResult = new JsonResult();
            jsonResult.setMsg("成功");
            jsonResult.setStatus("200");
            jsonResult.setSuccess(true);
            jsonResult.setObj(resultMap);
            PingAnRequestParam pingAnRequestParam = PingAnRequestParam.buildPingAnRequestParam();
            String value = AesTest.encrypt(JSON.toJSONString(jsonResult), pingAnRequestParam.getAesKey());

            String apiUrl = channel.getRetUrl();
            if (StringUtil.isBlank(apiUrl) || "#".equals(apiUrl))
                return;

            if (apiUrl.contains("?"))
                HttpsUtil.post(apiUrl.trim() + "&resultJson=" + value.trim(), "");
            else
                HttpsUtil.post(apiUrl.trim() + "?resultJson=" + value.trim(), "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private boolean insertInsuranceTrade(String channel, String realName,String idNo, String mobile) {
        TradeList trade = new TradeList();
        trade.setName(realName);
        trade.setCardNo(idNo);
        trade.setCardType("CID");
        trade.setChannel(channel);
        trade.setFinishDate(new Date());
        trade.setPhone(mobile);
        return tradeListService.insert(trade);
    }


    @Override
    public PageData<Channel> queryPage(ChannelRequestVo vo) {
        vo.setPageNo(vo.getPageSize() * (vo.getPageNo() - 1));
        List<Channel> list = channelMapper.queryPage(vo);
        int total = channelMapper.queryPageCount(vo);
        return new PageData<>(list, total);
    }

    @Override
    public List<Channel> selectByCodeDesc() {
        return channelMapper.selectByCodeDesc();
    }

    @Override
    public List<Channel> selectByBusiness(String business) {
        return channelMapper.selectByBusiness(business);
    }

    @Override
    public Channel selectByMobile(String mobile) {
        return channelMapper.selectByMobile(mobile);
    }

    @Override
    public Page<Channel> testQueryByPage(int pageNumber, int size)
    {
        return null;
    }
}
