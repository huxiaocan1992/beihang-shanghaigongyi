package cn.dakaqi.blank.util.wechatPay;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * @author jayLi
 *         <p>
 *         Returned result from wechat payment
 */
@Data
@XmlRootElement(name = "xml")
@XmlAccessorType(XmlAccessType.FIELD)
public class RefundQueryResult extends MchBaseResult {

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String transaction_id;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String out_trade_no;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String refund_id;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String refund_channel;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String refund_fee;

    private int total_fee;

    private int cash_fee;

    private int refund_count;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String out_refund_no_0;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String refund_id_0;

    private int refund_fee_0;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String refund_status_0;

    // @Override
    // public String toString() {
    // return "device_info: " + device_info + ", trade_type: " + trade_type + ", prepay_id: " + prepay_id
    // + ",code_url: " + code_url;
    // }
}
