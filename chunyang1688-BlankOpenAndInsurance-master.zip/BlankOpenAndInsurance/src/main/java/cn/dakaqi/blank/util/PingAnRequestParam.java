/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.util;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.ResourceBundle;

/**
 * 类名称：PingAnRequestParam <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/1 16:44
 * @version: 1.0.0
 */

@Data
@ToString
public class PingAnRequestParam implements Serializable
{
    private static final long serialVersionUID = 902022347742922007L;
    private static PingAnRequestParam pingAnRequestParam = null;

//        PINGAN_PRIVATE_KEY = 30820277020100300d06092a864886f70d0101010500048202613082025d02010002818100d1029ae8333951c030d3d7468868d86902ffeb5f95a2addd5d3aa05d4443b641bb2db050b20a9aafee454c929106e9ff5a22060a8bca9cff2c6e6d66c2dc68c28536c349875e4edbc5ad79d00d7bf3708f3052abd75ac333f642710699aa7e37243883ae14362015c0c6fb2aaac1b4e1791cdaa95bee353abc0b971e5fe34633020301000102818100810a88b53f9aedfc28a941ca0c421f0a868d96b646de4f55d24f75dedf5ca6d3e24a8d06e54562c7a7e62526805fb26cb32b3a6b9c6f158afdd597b9d028e08bc99354ada5d1a9175c822d50c41da1bdc1b9f17eefff3520d5073592733b5f3762b936103dec26a75b7c3c2d5c90ce99d4b65cb5a9fda3195ecf7eecb17d29d1024100fc963431bcffbe1543c403393e41c055ccbb94dfcb61b0efe4fa730d2a1731f5998698bb9f4cb0505a53f3bcb901653c15b7453b2aa37071602422f06cdb8e17024100d3d5a72446d6471fa18cac76956f488e81f9521836a7484c2d7946683a5440e9d35ffaa76b618b14ca20535ae88349710e698f8898c11cfd7b13e554398016450240215e6e92cb9735b3757a65baa040eb79ea4c35c4c307aaea6663b7e35b5629217b20cef8aa78e52a1864d2e471c47f6d4aa9259a456dc623144271e3355e640d024009b904b2e58d70364373f1767fe55baf2ec802bc99c593cbeb4a65b0e2fc7afe4075674bc7e1f2404206b9ccb25f543f9c29bc2cc8d6143e8e279b9f02049f01024100ec536031fa8c0e8b0c2f8859e987baa1d20f56e84e5db01ee299249264dc4391af530b7f0435493add02fc25ee74d4d91085856b2dba6231e614db0ff323e5c0
//        PINGAN_PUBLIC_KEY = 30819f300d06092a864886f70d010101050003818d0030818902818100d1029ae8333951c030d3d7468868d86902ffeb5f95a2addd5d3aa05d4443b641bb2db050b20a9aafee454c929106e9ff5a22060a8bca9cff2c6e6d66c2dc68c28536c349875e4edbc5ad79d00d7bf3708f3052abd75ac333f642710699aa7e37243883ae14362015c0c6fb2aaac1b4e1791cdaa95bee353abc0b971e5fe346330203010001
//        PINGAN_AES_KEY = 17e4f4e492f67bd3d845a0aecaf2089f
//        PINGAN_OPEN_URL = https://ibpu1.sdb.com.cn/ibd/page/web_for_h5/usual_h5/index.html?environment=u1&source=sys_jtz_yl_BBC_GQT&outerSource=BBC_GQT&showTitle=Chunyang1688/index/input/P0000301/
//        discontinueUrl = "https://www.dakaqi.cn";
//        completionNavigatingButtonName = "完成";
//        completionNavigatingUrl = "https://www.pad.cvssp.cn";

    private String priKey;
    private String pubKey;
    private String aesKey;
    private String openUrl;
    private String errorUrl;
    private String buttnName;
    private String finshedUrl;
    private String successCallBack;

    public static PingAnRequestParam buildPingAnRequestParam()
    {
        if(null == pingAnRequestParam)
        {
            pingAnRequestParam = new PingAnRequestParam();
            ResourceBundle bundle = ResourceBundle.getBundle("pingan");
            String    PINGAN_PRIVATE_KEY = bundle.getString("PINGAN_PRIVATE_KEY");
            String    PINGAN_PUBLIC_KEY = bundle.getString("PINGAN_PUBLIC_KEY");
            String    PINGAN_AES_KEY = bundle.getString("PINGAN_AES_KEY");
            String    PINGAN_OPEN_URL = bundle.getString("PINGAN_OPEN_URL");
            String    discontinueUrl = bundle.getString("discontinueUrl");
            String    completionNavigatingButtonName = bundle.getString("completionNavigatingButtonName");
            String    completionNavigatingUrl = bundle.getString("completionNavigatingUrl");
            String    openSuccessCallBack = bundle.getString("openSuccessCallBack");
            pingAnRequestParam.setAesKey(PINGAN_AES_KEY);
            pingAnRequestParam.setButtnName(completionNavigatingButtonName);
            pingAnRequestParam.setErrorUrl(discontinueUrl);
            pingAnRequestParam.setFinshedUrl(completionNavigatingUrl);
            pingAnRequestParam.setOpenUrl(PINGAN_OPEN_URL);
            pingAnRequestParam.setPriKey(PINGAN_PRIVATE_KEY);
            pingAnRequestParam.setPubKey(PINGAN_PUBLIC_KEY);
            pingAnRequestParam.setSuccessCallBack(openSuccessCallBack);

        }

        return pingAnRequestParam;
    }


}
 
 