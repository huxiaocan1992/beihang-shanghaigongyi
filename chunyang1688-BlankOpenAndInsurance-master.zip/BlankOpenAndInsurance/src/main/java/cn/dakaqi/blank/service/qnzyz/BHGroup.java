package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/6.
 * Description:
 */
public class BHGroup implements Serializable
{
    private static final long serialVersionUID = -8523509010869763717L;
    private String groupCode;//志愿者团体一号通编号,全网唯一不能修改
    private String orgCode;//团组织一号通编号,全网唯一
    private String orgName;//所属团组织名称
    private String groupName;//志愿者团体名称
    private String groupType;//志愿者团体类型 (1 非独立法人 2 为独立法人) 如果是2,志愿者团体机构代码必须给出
    private String groupAdmCode;//志愿者团体机构代码 ，如果groupType为2是必须的，groupType为1不需要填写 参考例子：01271075-5
    private String groupAddress;//志愿者团体地址
    private String groupProvince;//省份
    private String groupCity;//城市
    private String groupDistrict;//区县
    private String groupPostcode;//邮政编码
    private String groupAdmMobile;//志愿者团体管理员手机号码，用做登陆
    private String groupAdmPwd;//志愿者团体管理员密码 MD5后的
    private String groupAdmName;//志愿者团体管理员姓名
    private String groupAdmIdNo;//志愿者团体管理员身份证
    private String groupAdmTel;//志愿者团体管理员工作联系电话 (区号-号码)

    public BHGroup()
    {
    }


    public BHGroup(String groupCode, String groupName, String groupType, String groupAdmCode, String groupProvince,String groupCity,String groupDistrict,String groupAddress,String groupPostcode, String orgCode, String orgName)
    {
        this.groupCode = groupCode;
        this.groupName = groupName;
        this.groupType = groupType;
        this.groupAdmCode = groupAdmCode;
        this.groupProvince = groupProvince;
        this.groupCity = groupCity;
        this.groupDistrict = groupDistrict;
        this.groupAddress = groupAddress;
        this.groupPostcode = groupPostcode;
        this.orgCode = orgCode;
        this.orgName = orgName;
    }

    public BHGroup(String groupProvince,String groupCity,String groupDistrict,String groupAddress, String groupAdmCode, String groupAdmIdNo, String groupAdmMobile, String
            groupAdmName, String groupAdmPwd, String groupAdmTel, String groupCode, String groupName, String
            groupPostcode, String
                           groupType, String orgCode, String orgName)
    {
        this.groupProvince = groupProvince;
        this.groupCity = groupCity;
        this.groupDistrict = groupDistrict;
        this.groupAddress = groupAddress;
        this.groupAdmCode = groupAdmCode;
        this.groupAdmIdNo = groupAdmIdNo;
        this.groupAdmMobile = groupAdmMobile;
        this.groupAdmName = groupAdmName;
        this.groupAdmPwd = groupAdmPwd;
        this.groupAdmTel = groupAdmTel;
        this.groupCode = groupCode;
        this.groupName = groupName;
        this.groupPostcode = groupPostcode;
        this.groupType = groupType;
        this.orgCode = orgCode;
        this.orgName = orgName;
    }
//    public static BHGroup nativeGroup2BHGroup(Group group)
//    {
//        String address = group.getRegAddress();
//        address = address.replace(group.getProvince(),"");
//        address = address.replace(group.getCity(),"");
//        address = address.replace(group.getDistrict(),"");
//        BHGroup bhOrg = new BHGroup(group.getProvince(), group.getCity(),group.getDistrict() ,
//                group.getProvince() + group.getCity()+group.getDistrict() + address, "",
//                group.getCreateUser().getCardNO(), group.getCreateUser().getMobile(), group.getCreateUser().getRealName(), MD5Util.MD5("123456"),
//                group.getPhone(), "",group.getName(), "", "", "","");
//        return bhOrg;
//    }

    @Override
    public String toString()
    {
        return "BHGroup{" +
                "groupAddress='" + groupAddress + '\'' +
                ", groupCode='" + groupCode + '\'' +
                ", orgCode='" + orgCode + '\'' +
                ", orgName='" + orgName + '\'' +
                ", groupName='" + groupName + '\'' +
                ", groupType='" + groupType + '\'' +
                ", groupAdmCode='" + groupAdmCode + '\'' +
                ", groupPostcode='" + groupPostcode + '\'' +
                ", groupAdmMobile='" + groupAdmMobile + '\'' +
                ", groupAdmPwd='" + groupAdmPwd + '\'' +
                ", groupAdmName='" + groupAdmName + '\'' +
                ", groupAdmIdNo='" + groupAdmIdNo + '\'' +
                ", groupAdmTel='" + groupAdmTel + '\'' +
                '}';
    }

    public String getGroupAddress()
    {
        return groupAddress;
    }

    public void setGroupAddress(String groupAddress)
    {
        this.groupAddress = groupAddress;
    }

    public String getGroupAdmCode()
    {
        return groupAdmCode;
    }

    public void setGroupAdmCode(String groupAdmCode)
    {
        this.groupAdmCode = groupAdmCode;
    }

    public String getGroupAdmIdNo()
    {
        return groupAdmIdNo;
    }

    public void setGroupAdmIdNo(String groupAdmIdNo)
    {
        this.groupAdmIdNo = groupAdmIdNo;
    }

    public String getGroupAdmMobile()
    {
        return groupAdmMobile;
    }

    public void setGroupAdmMobile(String groupAdmMobile)
    {
        this.groupAdmMobile = groupAdmMobile;
    }

    public String getGroupAdmName()
    {
        return groupAdmName;
    }

    public void setGroupAdmName(String groupAdmName)
    {
        this.groupAdmName = groupAdmName;
    }

    public String getGroupAdmPwd()
    {
        return groupAdmPwd;
    }

    public void setGroupAdmPwd(String groupAdmPwd)
    {
        this.groupAdmPwd = groupAdmPwd;
    }

    public String getGroupAdmTel()
    {
        return groupAdmTel;
    }

    public void setGroupAdmTel(String groupAdmTel)
    {
        this.groupAdmTel = groupAdmTel;
    }

    public String getGroupName()
    {
        return groupName;
    }

    public void setGroupName(String groupName)
    {
        this.groupName = groupName;
    }

    public String getGroupPostcode()
    {
        return groupPostcode;
    }

    public void setGroupPostcode(String groupPostcode)
    {
        this.groupPostcode = groupPostcode;
    }

    public String getGroupType()
    {
        return groupType;
    }

    public void setGroupType(String groupType)
    {
        this.groupType = groupType;
    }

    public String getOrgCode()
    {
        return orgCode;
    }

    public void setOrgCode(String orgCode)
    {
        this.orgCode = orgCode;
    }

    public String getGroupCode()
    {
        return groupCode;
    }

    public void setGroupCode(String groupCode)
    {
        this.groupCode = groupCode;
    }

    public String getOrgName()
    {
        return orgName;
    }

    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }

    public String getGroupProvince()
    {
        return groupProvince;
    }

    public void setGroupProvince(String groupProvince)
    {
        this.groupProvince = groupProvince;
    }

    public String getGroupCity()
    {
        return groupCity;
    }

    public void setGroupCity(String groupCity)
    {
        this.groupCity = groupCity;
    }

    public String getGroupDistrict()
    {
        return groupDistrict;
    }

    public void setGroupDistrict(String groupDistrict)
    {
        this.groupDistrict = groupDistrict;
    }
}
