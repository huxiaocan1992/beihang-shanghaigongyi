package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.BankAccount;
import cn.dakaqi.blank.entity.Insurance;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.TradeListVo;
import cn.dakaqi.blank.mapper.TradeListMapper;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.util.PageData;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * <p>
 *   服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-07
 */
@Service
@Slf4j
public class TradeListServiceImpl extends ServiceImpl<TradeListMapper, TradeList> implements ITradeListService
{
    @Autowired
    private TradeListMapper tradeListMapper;

    @Override
    public PageData<TradeList> queryPage(TradeListVo vo) {
        vo.setPageNo(vo.getPageSize() * (vo.getPageNo() - 1));
        List<TradeList> list = tradeListMapper.queryPage(vo);
        int total = tradeListMapper.queryPageCount(vo);
        return new PageData<>(list, total);
    }

    @Override
    public boolean insertPingAnOpenTrade(String channelCode, String businessCode, String orderCode,BankAccount entity)
    {
        log.info("insertPingAnOpenTrade---1--->"+entity.toString());
        TradeList trade = new TradeList();
        trade.setChannel(channelCode);
        trade.setBusiness(businessCode);
        trade.setName(entity.getRealName());
        trade.setCardNo(entity.getIdNo());
        trade.setCardType("CID");
        trade.setOrderCode(orderCode);
        trade.setChannel(entity.getChannel());
        trade.setFinishDate(new Date());
        trade.setPhone(entity.getMobile());
        trade.setCreateTime(new Date());
        if (entity.getIsNewCus().equals("1"))
            trade.setPingAnNew(entity.getBankAcnt());
        else
            trade.setPingAnOld(entity.getBankAcnt());

        log.info("insertPingAnOpenTrade---2--->"+trade.toString());
        return super.insert(trade);
    }

    @Override
    public boolean insertApplyPassportTrade(String channelCode, String businessCode, String orderCode,String realName,String idNo,String mobile,String passportNo)
    {
        TradeList trade = new TradeList();
        trade.setChannel(channelCode);
        trade.setBusiness(businessCode);
        trade.setName(realName);
        trade.setCardNo(idNo);
        trade.setCardType("CID");
        trade.setOrderCode(orderCode);
        trade.setChannel(channelCode);
        trade.setFinishDate(new Date());
        trade.setPhone(mobile);
        trade.setPassportCode(passportNo);
        trade.setCreateTime(new Date());
        log.info("insertApplyPassportTrade---1--->"+trade.toString());
        return super.insert(trade);
    }

    @Override
    public boolean insertActivatePassportTrade(String channelCode, String businessCode, String orderCode,
                                               String realName,String idNo,String mobile,String passportNo,
                                               BankAccount bankAccount)
    {
        log.info("insertActivatePassportTrade---1--->"+bankAccount.toString());
        TradeList trade = new TradeList();
        trade.setChannel(channelCode);
        trade.setBusiness(businessCode);
        trade.setName(bankAccount.getRealName());
        trade.setCardNo(bankAccount.getIdNo());
        trade.setCardType("CID");
        trade.setOrderCode(orderCode);
        trade.setChannel(channelCode);
        trade.setFinishDate(new Date());
        trade.setPhone(bankAccount.getMobile());
        trade.setPassportCode(passportNo);
        trade.setCreateTime(new Date());
        if (bankAccount.getIsNewCus().equals("1"))
            trade.setPingAnNew(bankAccount.getBankAcnt());
        else
            trade.setPingAnOld(bankAccount.getBankAcnt());

        log.info("insertActivatePassportTrade--2---->"+trade.toString());
        return super.insert(trade);
    }

    @Override
    public boolean insertActivatePassport18Trade(String channelCode, String businessCode, String orderCode, String realName, String idNo, String mobile, String passportNo, BankAccount bankAccount)
    {
        log.info("insertActivatePassportTrade---1--->"+bankAccount.toString());
        TradeList trade = new TradeList();
        trade.setChannel(channelCode);
        trade.setBusiness(businessCode);
        trade.setName(realName);
        trade.setCardNo(idNo);
        trade.setCardType("CID");
        trade.setOrderCode(orderCode);
        trade.setChannel(channelCode);
        trade.setFinishDate(new Date());
        trade.setPhone(mobile);
        trade.setPassportCode(passportNo);
        trade.setCreateTime(new Date());
        if (bankAccount.getIsNewCus().equals("1"))
            trade.setPingAnNew(bankAccount.getBankAcnt());
        else
            trade.setPingAnOld(bankAccount.getBankAcnt());

        log.info("insertActivatePassportTrade--2---->"+trade.toString());
        return super.insert(trade);
    }

    @Override
    public boolean insertBuyInsuranceTrade(String channelCode, String businessCode, String orderCode, BankAccount entity, Insurance insurance)
    {
        log.info("insertBuyInsuranceTrade---1--->"+entity.toString());
        TradeList trade = new TradeList();
        trade.setChannel(channelCode);
        trade.setBusiness(businessCode);
        trade.setName(entity.getRealName());
        trade.setCardNo(entity.getIdNo());
        trade.setCardType("CID");
        trade.setOrderCode(orderCode);
        trade.setChannel(channelCode);
        trade.setFinishDate(new Date());
        trade.setPhone(entity.getMobile());
        trade.setCreateTime(new Date());
        if (entity.getIsNewCus().equals("1"))
            trade.setPingAnNew(entity.getBankAcnt());
        else
            trade.setPingAnOld(entity.getBankAcnt());
        log.info("insertBuyInsuranceTrade--3---->"+trade.toString());
        return super.insert(trade);
    }

    @Override
    public TradeList selectByCardNoAndBussion(String cardNo, String businessCode)
    {
        Wrapper<TradeList> wrapper = new EntityWrapper<TradeList>();
        wrapper.eq("cardNo",cardNo);
        wrapper.like("business",businessCode);
        return super.selectOne(wrapper);
    }

    @Override
    public boolean insertDonteTrad(TradeList vo)
    {
        return super.insert(vo);
    }
}
