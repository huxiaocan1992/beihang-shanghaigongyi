package cn.dakaqi.blank.util.wechatPay;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * @author beliveli
 *         <p>
 *         Wechat pay order Result parameter
 */

@Data
@XmlRootElement(name = "xml")
@XmlAccessorType(XmlAccessType.FIELD)
public class PayOrderQuery {

    @XmlElement
    private String appid;

    @XmlElement
    private String mch_id;

    @XmlElement
    private String nonce_str;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String sign;

    @XmlElement
    private String transaction_id;

    @XmlElement
    private String out_trade_no;

}