package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.OrderInfo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
@Repository(value = "orderInfoMapper")
public interface OrderInfoMapper extends BaseMapper<OrderInfo> {

}