package cn.dakaqi.blank.entity.vo;

/**
 * Created by yangx
 * CreateTime: 2016/12/8 12:01
 */
public class ChannelRequestVo {

    private Integer pageSize = 10;
    private Integer pageNo = 1;
    private String keyWords;

    private String name;
    private String business;

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public String getKeyWords() {
        return keyWords;
    }

    public void setKeyWords(String keyWords) {
        this.keyWords = keyWords;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }


}
