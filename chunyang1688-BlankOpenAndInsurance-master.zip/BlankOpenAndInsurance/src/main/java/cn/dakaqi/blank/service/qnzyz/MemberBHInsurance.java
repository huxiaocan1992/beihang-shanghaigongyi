package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;

/**
 * 北航保单信息
 * Created by chunyang on 2015/8/20.
 */
public class MemberBHInsurance implements Serializable
{
    private String insuranceId;//22,
    private String volunteerId;//null,
    private String insuranceNo;//PC0200A005402688,
    private String periodStart;//20150418,
    private String periodEnd;//20160418,
    private String insuranceProcessDate;//null,
    private String premium;//null,
    private String serviceProvider;//GP0200A004998055,
    private String serviceProviderUrl;//null,
    private String transactionBatch;//20150417-110067148001-015635,
    private String payId;//null
    /**
     * 悠活公司添加的字段
     */
    private String activateStatus;//是否已激活 0未 1已

    public MemberBHInsurance(String insuranceId, String volunteerId, String insuranceNo, String periodStart, String periodEnd, String insuranceProcessDate, String premium, String serviceProvider, String serviceProviderUrl, String transactionBatch, String payId, String activateStatus) {
        this.insuranceId = insuranceId;
        this.volunteerId = volunteerId;
        this.insuranceNo = insuranceNo;
        this.periodStart = periodStart;
        this.periodEnd = periodEnd;
        this.insuranceProcessDate = insuranceProcessDate;
        this.premium = premium;
        this.serviceProvider = serviceProvider;
        this.serviceProviderUrl = serviceProviderUrl;
        this.transactionBatch = transactionBatch;
        this.payId = payId;
        this.activateStatus = activateStatus;
    }

    public MemberBHInsurance() {
    }

    public String getActivateStatus()
    {
        return activateStatus;
    }

    public void setActivateStatus(String activateStatus)
    {
        this.activateStatus = activateStatus;
    }

    public String getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(String insuranceId) {
        this.insuranceId = insuranceId;
    }

    public String getVolunteerId() {
        return volunteerId;
    }

    public void setVolunteerId(String volunteerId) {
        this.volunteerId = volunteerId;
    }

    public String getInsuranceNo() {
        return insuranceNo;
    }

    public void setInsuranceNo(String insuranceNo) {
        this.insuranceNo = insuranceNo;
    }

    public String getPeriodStart() {
        return periodStart;
    }

    public void setPeriodStart(String periodStart) {
        this.periodStart = periodStart;
    }

    public String getPeriodEnd() {
        return periodEnd;
    }

    public void setPeriodEnd(String periodEnd) {
        this.periodEnd = periodEnd;
    }

    public String getInsuranceProcessDate() {
        return insuranceProcessDate;
    }

    public void setInsuranceProcessDate(String insuranceProcessDate) {
        this.insuranceProcessDate = insuranceProcessDate;
    }

    public String getPremium() {
        return premium;
    }

    public void setPremium(String premium) {
        this.premium = premium;
    }

    public String getServiceProvider() {
        return serviceProvider;
    }

    public void setServiceProvider(String serviceProvider) {
        this.serviceProvider = serviceProvider;
    }

    public String getServiceProviderUrl() {
        return serviceProviderUrl;
    }

    public void setServiceProviderUrl(String serviceProviderUrl) {
        this.serviceProviderUrl = serviceProviderUrl;
    }

    public String getTransactionBatch() {
        return transactionBatch;
    }

    public void setTransactionBatch(String transactionBatch) {
        this.transactionBatch = transactionBatch;
    }

    public String getPayId() {
        return payId;
    }

    public void setPayId(String payId) {
        this.payId = payId;
    }

    @Override
    public String toString() {
        return "BHInsurance{" +
                "insuranceId='" + insuranceId + '\'' +
                ", volunteerId='" + volunteerId + '\'' +
                ", insuranceNo='" + insuranceNo + '\'' +
                ", periodStart='" + periodStart + '\'' +
                ", periodEnd='" + periodEnd + '\'' +
                ", insuranceProcessDate='" + insuranceProcessDate + '\'' +
                ", premium='" + premium + '\'' +
                ", serviceProvider='" + serviceProvider + '\'' +
                ", serviceProviderUrl='" + serviceProviderUrl + '\'' +
                ", transactionBatch='" + transactionBatch + '\'' +
                ", payId='" + payId + '\'' +
                '}';
    }
}
