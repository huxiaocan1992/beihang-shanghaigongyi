/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.response;

import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 类名称：VolunteerInsuraceVO <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @since 2016/12/2 11:58
 * @version 1.0.0
 */

@Data
@ToString
@Slf4j
public class VolunteerInsuraceVO implements Serializable
{
    private String bankNum;
    private String insuranceNo;
    private String periodStart;
    private String periodEnd;
    private String channelAdsImg;

}
 
 