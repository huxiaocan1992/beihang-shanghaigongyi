package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.ChannelExplain;
import cn.dakaqi.blank.mapper.ChannelExplainMapper;
import cn.dakaqi.blank.service.IChannelExplainService;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-01
 */
@Service
public class ChannelExplainServiceImpl extends ServiceImpl<ChannelExplainMapper, ChannelExplain> implements IChannelExplainService {

    @Override
    public ChannelExplain selectByChanel(Long channel) {
        try {
            Wrapper<ChannelExplain> wrapper = new Wrapper<ChannelExplain>() {
                @Override
                public String getSqlSegment() {
                    return "where channel = " + channel;
                }
            };
            return super.selectOne(wrapper);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
