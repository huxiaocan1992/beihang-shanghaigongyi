/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.BaseController;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.util.Base64Utils;
import cn.dakaqi.blank.util.Constant;
import cn.dakaqi.blank.util.IdcardInfoExtractor;
import cn.dakaqi.blank.util.JsonResult;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 类名称：DakaqiController <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/23 10:50
 * @version: 1.0.0
 */
@RestController
@RequestMapping(value = "/v1/dakaqi")
@Slf4j
@Api(value = "打卡器购买保险保障", description = "打卡器购买保险保障", hidden = false)
public class DakaqiController extends BaseController
{
    @Autowired
    IChannelService channelService;

    @RequestMapping(value = "/checkAuthCode", method = RequestMethod.POST)
    @ApiOperation(value = "打卡器购买保险保障", notes = "打卡器购买保险保障")
    public JsonResult checkAuthCode(
                              @RequestParam("authCode") String authCode,
                              @RequestParam("idNo") String idNo,
                              @RequestParam("realName") String realName,
                              @RequestParam("mobile") String mobile,
                              @RequestParam("volunteerCode") String volunteerCode,
                              @RequestParam("orderCode") String orderCode
                              )
    {
        Map<String, Object> resultMap = new HashMap<>();
        try
        {
            if(null == authCode || "null".equals(authCode) || StringUtils.isEmpty(authCode))
            {
                return renderError("激活码不可以为空");
            }
            Channel channel = null;//this.channelService.selectByCode("");
            if(null == channel)
            {
                return renderError("激活码无效");
            }


            //检查年龄是否在18-35岁
            IdcardInfoExtractor idcardInfo=new IdcardInfoExtractor(idNo);

            int age = idcardInfo.getAge();
            if(age<18 ||age>45)
            {
                String message = "本次只开放18至45岁";
                return renderError(message);
            }
            if(channel.getBusiness().contains("A"))
            {
                String redirectUrl = Constant.getPABUrl() + "/static/web_for_h5/passport/activate/activateInfo.html?orderCode="+orderCode+"&volunteerCode="+volunteerCode+"&mobile="+mobile+"&idNo="+idNo+"&channelCode="+channel.getCode()+"&businessCode="+channel.getBusiness()+"&realName="+ Base64Utils.encode(realName.getBytes());
                resultMap.put("redirectUrl",redirectUrl);
                return renderSuccess(resultMap);
            }
            else
            {
                String message = "此业务暂未开放";
                return renderError(message);
            }
        } catch (Exception cve)
        {
            return renderError(cve.getMessage());
        }
    }
}
 
 