package cn.dakaqi.blank.controller.input.wechat;

import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * @author beliveli on 2016/8/12/0012
 */
@SuppressWarnings("unused")
@Data
@ToString
public class UnifiedOrderVo {
    private String orderCode;
    private BigDecimal total;
}
