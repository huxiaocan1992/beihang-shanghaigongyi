/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.service.pingan;

import cn.dakaqi.blank.controller.input.OpenAccountVO;
import cn.dakaqi.blank.rsa.AesTest;
import cn.dakaqi.blank.rsa.RSASignature;
import cn.dakaqi.blank.util.Base64Utils;
import cn.dakaqi.blank.util.PingAnRequestParam;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * 类名称：PingAnServiceImpl <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016/12/1 16:21
 */
@Service
@Slf4j
public class PingAnServiceImpl implements IPingAnService {
    @Override
    public String saveOpenAccount(HttpServletRequest request, HttpServletResponse response, PingAnRequestParam pingAnRequestParam, OpenAccountVO openAccountVO) throws Exception {
        String discontinueUrl = pingAnRequestParam.getErrorUrl();
        String completionNavigatingButtonName = pingAnRequestParam.getButtnName();
        String completionNavigatingUrl = pingAnRequestParam.getFinshedUrl();

//        completionNavigatingUrl = completionNavigatingUrl
//                + "?channelCode=" + openAccountVO.getChannelCode()
//                + "&businessCode="+openAccountVO.getBusinessCode()
//                + "&idNo=" + openAccountVO.getIdNo()
//                + "&groupCode=GV0000078022" + openAccountVO.getGroupCode()
//                + "&volunteerCode=" + openAccountVO.getVolunteerCode();






        Map<String, String> map = new HashMap<String, String>();
        if(openAccountVO.getBusinessCode().startsWith("G"))
        {
            map.put("trueName", openAccountVO.getGuardianName());
            map.put("idNo", openAccountVO.getGuardianCardNo());
            completionNavigatingUrl = completionNavigatingUrl
                    + "?channelCode=" + openAccountVO.getChannelCode()
                    + "&businessCode="+openAccountVO.getBusinessCode()
                    + "&orderCode="+openAccountVO.getOrderCode()
                    + "&idNo=" + openAccountVO.getIdNo()
                    + "&realName=" + Base64Utils.encode(openAccountVO.getRealName().getBytes())
                    + "&pIdNo=" + openAccountVO.getGuardianCardNo();
//                    + "&passportNo=" + openAccountVO.getPassportNo()
//                    + "&groupCode=" + openAccountVO.getGroupCode()
//                    + "&volunteerCode=" + openAccountVO.getVolunteerCode()
        }
        else
        {
            map.put("trueName", openAccountVO.getRealName());
            map.put("idNo", openAccountVO.getIdNo());
            completionNavigatingUrl = completionNavigatingUrl
                    + "?channelCode=" + openAccountVO.getChannelCode()
                    + "&businessCode="+openAccountVO.getBusinessCode()
                    + "&orderCode="+openAccountVO.getOrderCode()
                    + "&idNo=" + openAccountVO.getIdNo()
                    + "&passportNo=" + openAccountVO.getPassportNo()
                    + "&groupCode=" + openAccountVO.getGroupCode()
                    + "&volunteerCode=" + openAccountVO.getVolunteerCode();
        }

        log.info(completionNavigatingUrl.length() + "---->" + completionNavigatingUrl);

        map.put("timestamp", String.valueOf(System.currentTimeMillis()));
        //map.put("discontinueUrl",discontinueUrl);
        map.put("completionNavigatingButtonName", completionNavigatingButtonName);
        map.put("completionNavigatingUrl", completionNavigatingUrl);

        String ciphertext = "";
        String sign = "";

        String param = JSON.toJSONString(map);
        log.info("param:" + param);
        ciphertext = AesTest.encrypt(param, pingAnRequestParam.getAesKey());
        log.info("ciphertext:" + ciphertext);

        // 加签
        sign = RSASignature.sign(ciphertext, pingAnRequestParam.getPriKey());
        log.info("sign:" + sign);

        String openUrl = pingAnRequestParam.getOpenUrl() + ciphertext + "/" + sign;
        log.info("openUrl:" + openUrl);

        //response.sendRedirect(openUrl);
        return openUrl;

    }
}
 
 