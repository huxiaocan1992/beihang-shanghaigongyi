package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
@TableName(value = "bankAccount")
@ToString
public class BankAccount implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 
	 */
	private String channel;

	/**
	 * 
	 */
	private String realName;

	/**
	 * 
	 */
	private String idNo;

	/**
	 * 
	 */
	private String mobile;

	/**
	 * 系统标识
	 */
	private String systemId;

	/**
	 * 橙子账号
	 */
	private String bankAcnt;

	/**
	 * 橙子账号状态
	 */
	private String bankAcctStatus;

	/**
	 * 是否新客
	 */
	private String isNewCus;

	/**
	 * 橙子开户手机号
	 */
	private String bankMobile;

	/**
	 * 创建时间(交易创建时间：yyyy-MM-dd HH:mm:ss)
	 */
	private String tradeTime;

	/**
	 * 二级电子账号(橙子账户分配给每家专业公司的二级账户)
	 */
	private String channelBankAcct;



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getBankAcnt() {
		return bankAcnt;
	}

	public void setBankAcnt(String bankAcnt) {
		this.bankAcnt = bankAcnt;
	}

	public String getBankAcctStatus() {
		return bankAcctStatus;
	}

	public void setBankAcctStatus(String bankAcctStatus) {
		this.bankAcctStatus = bankAcctStatus;
	}

	public String getIsNewCus() {
		return isNewCus;
	}

	public void setIsNewCus(String isNewCus) {
		this.isNewCus = isNewCus;
	}

	public String getBankMobile() {
		return bankMobile;
	}

	public void setBankMobile(String bankMobile) {
		this.bankMobile = bankMobile;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getChannelBankAcct() {
		return channelBankAcct;
	}

	public void setChannelBankAcct(String channelBankAcct) {
		this.channelBankAcct = channelBankAcct;
	}

}
