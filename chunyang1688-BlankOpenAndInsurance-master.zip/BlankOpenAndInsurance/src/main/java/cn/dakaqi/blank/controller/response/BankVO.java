/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.response;

import cn.dakaqi.blank.entity.BankAccount;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 类名称：BankVO <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016/12/6 11:34
 */

@Data
@ToString
@Slf4j
public class BankVO implements Serializable {
    String bankAcnt;
    String idNo;
    String mobile;
    String realName;
    String tradeTime;
    int isNewCus;//0老账号 1新账号


    public static BankVO buildBankVO(BankAccount bankAccount) {
        BankVO bankVO = new BankVO();
        bankVO.setBankAcnt(bankAccount.getBankAcnt());
        bankVO.setIdNo(bankAccount.getIdNo());
        bankVO.setMobile(bankAccount.getMobile());
        bankVO.setRealName(bankAccount.getRealName());
        bankVO.setTradeTime(bankAccount.getTradeTime());
        bankVO.setIsNewCus(Integer.parseInt(bankAccount.getIsNewCus()));
        return bankVO;
    }
}
 
 