package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/9.
 * Description:
 */
public class BHJsonResult implements Serializable
{
    private static final long serialVersionUID = 1L;

    /**
     * 成功
     */
    public static final int CODE_SUCCESS = 0;

    /**
     * 失败
     */
    public static final int CODE_FAIL = 1;
    /**
     * 返回结果编号：1 失败， 0 成功，
     */
    private int ret = 0;
    /**
     * 返回结果说明
     */
    private String msg = "";

    public int getRet()
    {
        return ret;
    }

    public void setRet(int ret)
    {
        this.ret = ret;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }
}
