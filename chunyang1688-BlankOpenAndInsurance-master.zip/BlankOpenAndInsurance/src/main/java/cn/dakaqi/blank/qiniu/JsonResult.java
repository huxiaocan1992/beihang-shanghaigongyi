package cn.dakaqi.blank.qiniu;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/7.
 */
public class JsonResult implements Serializable
{
    private static final long serialVersionUID = 1L;
    /**
     * 返回结果编号： 0 成功  1 失败
     */
    public static final int CODE_SUCCESS = 0;
    public static final int CODE_FAIL = 1;
    public static final int CODE_NO_DATA = 2;

    private Object data = null;
    private int code = CODE_SUCCESS;
    private String message = "操作成功";


    public JsonResult()
    {
    }

    public JsonResult(int code, String message,Map<String,Object> data)
    {
        this.code = code;
        switch (code)
        {
            case CODE_SUCCESS:
                this.message = "操作成功";
            case CODE_FAIL:
                this.message = "操作成功";
            case CODE_NO_DATA:
                this.message = "暂无数据";
            default:
                this.message = message;
        }
        this.data = data;
    }

    public int getCode()
    {
        return code;
    }

    public void setCode(int code)
    {
        this.code = code;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public Object getData()
    {
        if(null == data)
            data = new HashMap<String,Object>();
        return data;
    }

    public void setData(Object data)
    {
        if(null == data)
            data = new HashMap<String,Object>();

        this.data = data;
    }
}
