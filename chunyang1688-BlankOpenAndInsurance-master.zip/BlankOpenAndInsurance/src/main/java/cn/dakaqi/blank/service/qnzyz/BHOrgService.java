package cn.dakaqi.blank.service.qnzyz;

import cn.dakaqi.blank.util.HttpsUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/13.
 * Description:
 */
@Component
public class BHOrgService
{
    @Autowired
    BHConstant bhConstant;
    @Autowired
    BHAccesssToken bhAccesssToken;
    @Autowired
    BHEncrytByPublicKey bhEncrytByPublicKey;

    static String pageSize = "20";
    private ValueFilter filter = new ValueFilter() {
        @Override
        public Object process(Object obj, String s, Object v) {
            if(v==null)
                return "";
            return v;
        }
    };
    private static SerializerFeature[] features = {SerializerFeature.WriteNullNumberAsZero, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.DisableCircularReferenceDetect};

    /**
     * 志愿者团体注册
     * 客户平台注册的志愿者团体数据同步到志愿者平台
     * @param bhGroup
     * @return
     */
    public String regOrg(BHGroup bhGroup)throws Exception
    {

            String groupCode = null;

            String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhGroup.getGroupAdmMobile());
            String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhGroup.getGroupAdmIdNo());
            bhGroup.setGroupAdmMobile(mobile);
            bhGroup.setGroupAdmIdNo(cardNo);

            //String postUrl = BHConstant.checkNetWork()+"/api/v1/group/reg?client=" + DKQConstant.CLIENTID + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
            String postUrl = bhConstant.checkNetWork()+"/api/v1/group/reg4Inner?client=" + BHConstant.CLIENTID + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
            String postEntity = JSON.toJSONString(bhGroup,filter);
            JSONObject object = JSON.parseObject(postEntity);
            object.remove("groupCode");
            object.remove("orgName");
            postEntity = object.toJSONString();

            String result = HttpsUtil.post(postUrl, postEntity);
            if(result != null && !result.trim().equals(""))
            {
                JSONObject jsonObject = JSON.parseObject(result);
                if(jsonObject != null)
                {
                    int res_code = jsonObject.getInteger("ret");
                    String msg = jsonObject.getString("msg");

                    if(res_code == 0 || res_code == 1703 || res_code == 1109 || res_code == 1206)
                    {
                        JSONObject jsonObject2 = jsonObject.getJSONObject("result");
                        groupCode = jsonObject2.getString("groupCode");
                    }
                    else if(res_code == bhConstant.TOKEN_TIMEOUT)
                    {
                        bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                        //regOrg(clientID,bhGroup);
                        throw new Exception(msg);
                    }
                    else
                    {
                        throw new Exception(msg);
                    }
                }
            }
            return groupCode;
    }

    /**
     * 志愿员自己创建社团
     * @param map
     * @return
     * @throws Exception
     */
    public String reg4Social(Map<String,String> map)throws Exception
    {
        String groupCode = null;

        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, map.get("groupAdmMobile"));
        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, map.get("groupAdmIdNo"));
        map.put("groupAdmMobile",mobile);
        map.put("groupAdmIdNo",cardNo);
        String postUrl = bhConstant.checkNetWork()+"/api/v1/group/reg4Social?client=" + BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);

        String result = HttpsUtil.post(postUrl, postEntity);
        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");

                if(res_code == 0)
                {
                    JSONObject jsonObject2 = jsonObject.getJSONObject("result");
                    groupCode = jsonObject2.getString("groupCode");
                }
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //regOrg(clientID,bhGroup);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return groupCode;
    }
//    /**
//     * 志愿者团体信息更新
//     * 当志愿者团体信息在客户平台有更新通过该接口把数据同步到志愿者平台
//     * @param bhGroup
//     * @return
//     */
//    public boolean updateOrg(BHGroup bhGroup)throws Exception
//    {
//        boolean F = false;
//        String mobile = bhEncrytByPublicKey.encryptByPublicKey(DKQConstant.CLIENTID, bhGroup.getGroupAdmMobile());
//        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(DKQConstant.CLIENTID, bhGroup.getGroupAdmIdNo());
//        bhGroup.setGroupAdmMobile(mobile);
//        bhGroup.setGroupAdmIdNo(cardNo);
//
//            String postUrl = BHConstant.checkNetWork()+"/api/v1/group/update?client="+ DKQConstant.CLIENTID
//                    + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//            String postEntity = JSON.toJSONString(bhGroup,filter);
//            JSONObject object = JSON.parseObject(postEntity);
//            object.remove("orgCode");
//            object.remove("orgName");
//            object.remove("groupAdmPwd");
//            postEntity = object.toJSONString();
//
//            String result = HttpsUtil.post(postUrl, postEntity);
//            if(result != null && !result.trim().equals(""))
//            {
//                JSONObject jsonObject = JSON.parseObject(result);
//                if(jsonObject != null)
//                {
//                    int res_code = jsonObject.getInteger("ret");
//                    String msg = jsonObject.getString("msg");
//                    if(res_code == 0)
//                    {
//                        F = true;
//                    }
//                    else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                    {
//                        bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                        //updateOrg(clientID,bhGroup);
//                        throw new Exception(msg);
//                    }
//                    else
//                    {
//                        throw new Exception(msg);
//                    }
//                }
//            }
//            return F;
//    }
//
//    /**
//     * 志愿者团体查询
//     * 查询客户平台下面的志愿者团体信息
//     * @param groupCode
//     * @param orgCode
//     * @return
//     */
//    public List<Organization> search(String groupCode,String orgCode,String pageIdx)throws Exception
//    {
//        List<Organization> orgs = null;
//
//        Map<String,String > map = new HashMap<String, String>();
//        map.put("groupCode",groupCode);
//        map.put("orgCode",orgCode);
//
//            //String postUrl = BHConstant.checkNetWork()+"/api/v1/group/search?client="+ DKQConstant.CLIENTID + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//            String postUrl = BHConstant.checkNetWork()+"/api/v1/group/search4Inner?client="+ DKQConstant.CLIENTID   + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//            String postEntity = JSON.toJSONString(map);
//            String result = HttpsUtil.post(postUrl, postEntity);
//            if(StringUtils.isNotEmpty(result) && !result.equals("null"))
//            {
//                JSONObject jsonObject = JSONObject.parseObject(result);
//                if(jsonObject != null)
//                {
//                    int res_code = jsonObject.getInteger("ret");
//                    String msg = jsonObject.getString("msg");
//                    if(res_code == 0)
//                    {
//                        orgs = new ArrayList<Organization>();
//                        JSONArray jsonArray = jsonObject.getJSONArray("result");
//                        if(null == jsonArray || jsonArray.size() == 0)
//                            return null;
//                        for(int i=0;i<jsonArray.size();i++)
//                        {
//                            JSONObject object = jsonArray.getJSONObject(i);
//                            String groupCode2 = object.getString("groupCode");
//                            String groupName = object.getString("groupName");
//                            String groupType = object.getString("groupType");
//                            String groupAdmCode = object.getString("groupAdmCode");
//                            String groupProvince = object.getString("groupProvince");//省份
//                            String groupCity = object.getString("groupCity");//城市
//                            String groupDistrict = object.getString("groupDistrict");//区县
//                            String groupAddress = object.getString("groupAddress");
//                            String groupPostcode = object.getString("groupPostcode");
//                            String parentorgCode = object.getString("parentorgCode");
//                            String parentOrgName = object.getString("parentOrgName");
//                            BHGroup bhGroup= new BHGroup(groupCode2, groupName, groupType, groupAdmCode, groupProvince,groupCity,groupDistrict,groupAddress,
//                                    groupPostcode, parentorgCode,parentOrgName);
//
//                            orgs.add(BHGroup.bhgroup2nativeorg(bhGroup));
//                        }
//                    }
//                    else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                    {
//                        bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                        //search(clientID, groupCode, orgCode);
//                        throw new Exception(msg);
//                    }
//                    else
//                    {
//                        throw new Exception(msg);
//                    }
//                }
//            }
//            return orgs;
//    }
//
//    /**
//     * 查询指定groupCode社团
//     * @param groupCode
//     * @param orgCode
//     * @return
//     * @throws Exception
//     */
//    public BHGroup findByGroupCode(String groupCode,String orgCode)throws Exception
//    {
//        BHGroup bhGroup = null;
//        Map<String,String > map = new HashMap<String, String>();
//        map.put("groupCode",groupCode);
//        map.put("orgCode",orgCode);
//
//        String postUrl = BHConstant.checkNetWork()+"/api/v1/group/search?client="+ DKQConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result) && !result.equals("null"))
//        {
//            JSONObject jsonObject = JSONObject.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code == 0)
//                {
//                    JSONArray jsonArray = jsonObject.getJSONArray("result");
//                    if(null == jsonArray || jsonArray.size() == 0)
//                        return null;
//                    for(int i=0;i<jsonArray.size();i++)
//                    {
//                        JSONObject object = jsonArray.getJSONObject(i);
//                        String groupCode2 = object.getString("groupCode");
//                        String groupName = object.getString("groupName");
//                        String groupType = object.getString("groupType");
//                        String groupAdmCode = object.getString("groupAdmCode");
//                        String groupProvince = object.getString("groupProvince");//省份
//                        String groupCity = object.getString("groupCity");//城市
//                        String groupDistrict = object.getString("groupDistrict");//区县
//                        String groupAddress = object.getString("groupAddress");
//                        String groupPostcode = object.getString("groupPostcode");
//                        String parentorgCode = object.getString("parentorgCode");
//                        String parentOrgName = object.getString("parentOrgName");
//                        bhGroup= new BHGroup(groupCode2, groupName, groupType, groupAdmCode, groupProvince,groupCity,groupDistrict,groupAddress,
//                                groupPostcode, parentorgCode,parentOrgName);
//
//                    }
//                }
//                else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return bhGroup;
//    }
//    /**
//     * 志愿者团体查询
//     * 查询客户平台下面的志愿者团体信息
//     * @param province
//     * @param city
//     * @param district
//     * @param pageIdx
//     * @return
//     * @throws Exception
//     */
//    public List<Organization> findGroupByRegion(String province,String city,String district,String pageIdx)throws Exception
//    {
//       List<Organization> orgs = null;
//
//        Map<String,String > map = new HashMap<String, String>();
//        map.put("province",province);
//        map.put("city",city);
//        map.put("district",district);
//        map.put("pageIdx",pageIdx);
//        map.put("pageSize",pageSize);
//
//        String postUrl = BHConstant.checkNetWork()+"/api/v1/group/findGroupByRegion?client="+ DKQConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result) && !result.equals("null"))
//        {
//            JSONObject jsonObject = JSONObject.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code == 0)
//                {
//                    jsonObject = jsonObject.getJSONObject("result");
//                    int total = jsonObject.getInteger("total");
//                    int totalPage = jsonObject.getInteger("totalPage");
//
//                    orgs = new ArrayList<Organization>();
//                    JSONArray jsonArray = jsonObject.getJSONArray("result");
//                    if(null == jsonArray || jsonArray.size() == 0)
//                        return null;
//                    for(int i=0;i<jsonArray.size();i++)
//                    {
//                        JSONObject object = jsonArray.getJSONObject(i);
//                        String groupCode2 = object.getString("groupCode");
//                        String groupName = object.getString("groupName");
//                        String groupType = object.getString("groupType");
//                        String groupAdmCode = object.getString("groupAdmCode");
//                        String groupProvince = object.getString("groupProvince");//省份
//                        String groupCity = object.getString("groupCity");//城市
//                        String groupDistrict = object.getString("groupDistrict");//区县
//                        String groupAddress = object.getString("groupAddress");
//                        String groupPostcode = object.getString("groupPostcode");
//                        String parentorgCode = object.getString("parentorgCode");
//                        String parentOrgName = object.getString("parentOrgName");
//                        BHGroup bhGroup= new BHGroup(groupCode2, groupName, groupType, groupAdmCode, groupProvince,groupCity,groupDistrict,groupAddress,
//                                groupPostcode, parentorgCode,parentOrgName);
//
//                        orgs.add(BHGroup.bhgroup2nativeorg(bhGroup));
//                    }
//                }
//                else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                    //search(clientID, groupCode, orgCode);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return orgs;
//    }
//    /**
//     * 团组织查询
//     * 查询客户平台下面的团组织信息
//     * @param childLevelFlag
//     * @param orgCode
//     * @return
//     */
//    public List<Department>  searchorg(String childLevelFlag,String orgCode,String pageIdx)throws Exception
//    {
//        List<Department> departments = null;
//
//        Map<String,String > map = new HashMap<String, String>();
//        map.put("childLevelFlag",childLevelFlag);
//        map.put("orgCode",orgCode);
//
//            String postUrl = BHConstant.checkNetWork()+"/api/v1/group/searchorg?client="+ DKQConstant.CLIENTID
//                    + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//            String postEntity = JSON.toJSONString(map,SerializerFeature.WriteMapNullValue);
//            String result = HttpsUtil.post(postUrl, postEntity);
//            if(result != null && !result.trim().equals(""))
//            {
//                JSONObject jsonObject = JSONObject.parseObject(result);
//                if(jsonObject != null)
//                {
//                    int res_code = jsonObject.getInteger("ret");
//                    String msg = jsonObject.getString("msg");
//                    if(res_code == 0)
//                    {
//                        departments = new ArrayList<Department>();
//                        JSONArray jsonArray = jsonObject.getJSONArray("result");
//                        if(null == jsonArray || jsonArray.size() == 0)
//                            return null;
//                        for(int i=0;i<jsonArray.size();i++)
//                        {
//                            JSONObject object = jsonArray.getJSONObject(i);
//                            String orgCode2 = object.getString("orgCode");
//                            String orgName = object.getString("orgName");
//                            String orgShortName = object.getString("orgShortName");
//                            String orgAddress = object.getString("orgAddress");
//                            String orgPostCode = object.getString("orgPostCode");
//                            String parentOrgCode = object.getString("parentOrgCode");
//                            String parentOrgName = object.getString("parentOrgName");
//                            BHOrg bhOrg = new BHOrg(orgAddress, orgCode2, orgName, orgPostCode, orgShortName, parentOrgCode, parentOrgName);
//
//                            departments.add(BHOrg.bHOrg2Department(bhOrg));
//                        }
//                    }
//                    else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                    {
//                        bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                        //searchorg(clientID, childLevelFlag, orgCode);
//                        throw new Exception(msg);
//                    }
//                    else
//                    {
//                        throw new Exception(msg);
//                    }
//                }
//            }
//            return departments;
//    }
//
//    /**
//     * 团组织查询
//     * 查询指定orgCode的团组织信息
//     * @param orgCode
//     * @return
//     */
//    public Department  searchorgbyCode(String orgCode)throws Exception
//    {
//        Department dep = null;
//
//        Map<String,String > map = new HashMap<String, String>();
//        map.put("orgCode",orgCode);
//
//        String postUrl = BHConstant.checkNetWork()+"/api/v1/group/searchorgbyCode?client="+ DKQConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(result != null && !result.trim().equals(""))
//        {
//            JSONObject jsonObject = JSONObject.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code == 0)
//                {
//                    JSONObject object = jsonObject.getJSONObject("result");
//                    String orgCode2 = object.getString("orgCode");
//                    String orgName = object.getString("orgName");
//                    String orgShortName = object.getString("orgShortName");
//                    String orgAddress = object.getString("orgAddress");
//                    String orgPostCode = object.getString("orgPostCode");
//                    String parentOrgCode = object.getString("parentOrgCode");
//                    String parentOrgName = object.getString("parentOrgName");
//                    BHOrg bhOrg = new BHOrg(orgAddress, orgCode2, orgName, orgPostCode, orgShortName, parentOrgCode, parentOrgName);
//                    dep = BHOrg.bHOrg2Department(bhOrg);
//                }
//                else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                    //searchorg(clientID, childLevelFlag, orgCode);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return dep;
//    }
//
//    /**
//     * 机构信息核实
//     * 客户平台可以通过该接口核实组织机构代码的有效性
//     * @param admCode
//     * @return
//     */
//    public String checkadmcode(String admCode)throws Exception
//    {
//
//        String admName = null;
//        Map<String,String> map = new HashMap<String, String>();
//        map.put("admCode",admCode);
//        map.put("admName","admName");
//            String postUrl = BHConstant.checkNetWork()+"/api/v1/group/checkadmcode?client="+ DKQConstant.CLIENTID
//                    + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
//            String postEntity = JSON.toJSONString(map,filter);
//            JSONObject object = JSON.parseObject(postEntity);
//            object.remove("admName");
//            postEntity = object.toJSONString();
//
//            String result = HttpsUtil.post(postUrl, postEntity);
//            if(result != null && !result.trim().equals(""))
//            {
//                JSONObject jsonObject = JSON.parseObject(result);
//                if(jsonObject != null)
//                {
//                    int res_code = jsonObject.getInteger("ret");
//                    String msg = jsonObject.getString("msg");
//                    if(res_code == 0)
//                    {
//                        object = jsonObject.getJSONObject("result");
//                        admName = object.getString("admName");
//                    }
//                    else if(res_code == BHConstant.TOKEN_TIMEOUT)
//                    {
//                        bhAccesssToken.refreshToken(DKQConstant.CLIENTID);
//                        throw new Exception(msg);
//                    }
//                    else
//                    {
//                        throw new Exception(msg);
//                    }
//                }
//            }
//            return admName;
//    }

    /**
     * 添加管理员
     * @param groupCode
     * @param groupAdmUserName
     * @param groupAdmMobile
     * @param groupAdmPwd
     * @param groupAdmName
     * @param groupAdmIdNo
     * @param groupAdmTel
     * @throws Exception
     */
    public int addManager(String groupCode,String groupAdmUserName,String groupAdmMobile,String groupAdmPwd,String groupAdmName,String groupAdmIdNo,String groupAdmTel)throws Exception
    {
        int res_code =1003;
        Map<String,String > map = new HashMap<String, String>();
        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, groupAdmMobile);
        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, groupAdmIdNo);
        map.put("groupCode",groupCode);
        map.put("groupAdmUserName",groupAdmUserName);
        map.put("groupAdmMobile",mobile);
        map.put("groupAdmPwd",groupAdmPwd);
        map.put("groupAdmName",groupAdmName);
        map.put("groupAdmIdNo",cardNo);
        map.put("groupAdmTel",groupAdmTel);


//        String postUrl = BHConstant.checkNetWork()+"/api/v1/group/addManager?client="+ DKQConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(DKQConstant.CLIENTID);
        String postUrl = bhConstant.checkNetWork()+"/api/v1/group/addManager4Inner?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map);
        String result = HttpsUtil.post(postUrl, postEntity);
        JSONObject jsonObject = JSONObject.parseObject(result);
        res_code = jsonObject.getInteger("ret");
        String msg = jsonObject.getString("msg");
        if(res_code == 0 || res_code == 1703 || res_code == 1109 || res_code == 1206 ||res_code == 1407)
        {
            return res_code;
        }
        else if(res_code == bhConstant.TOKEN_TIMEOUT)
        {
            bhAccesssToken.refreshToken(BHConstant.CLIENTID);
            throw new Exception(msg);
        }
        else
        {
            throw new Exception(msg);
        }
    }
}
