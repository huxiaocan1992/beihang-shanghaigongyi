package cn.dakaqi.blank.service.qnzyz;

import cn.dakaqi.blank.util.HttpsUtil;
import cn.dakaqi.blank.util.MD5Util;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/6.
 * Description:
 */
@Service
@ToString
@Slf4j
public class BHMemberService
{
    @Autowired
    BHConstant bhConstant;
    @Autowired
    BHAccesssToken bhAccesssToken;
    @Autowired
    BHEncrytByPublicKey bhEncrytByPublicKey;

    static String pageSize = "20";
    private ValueFilter filter = new ValueFilter() {
        @Override
        public Object process(Object obj, String s, Object v) {
            if(v==null)
                return "";
            return v;
        }
    };
    private static SerializerFeature[] features = {SerializerFeature.WriteNullNumberAsZero, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.DisableCircularReferenceDetect};

    /**
     * 简化注册
     *
     * @param bhMember the bh member
     * @return json object
     * @throws Exception the exception
     */
    public JSONObject simpleReg(BHMember bhMember)throws Exception
    {
        log.info(bhMember.toString());
        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,bhMember.getLoginMobile());
        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhMember.getCertificateNo());
        Map<String,String> map = new HashMap<String,String>();
        map.put("groupCode",bhMember.getGroupCode());
        map.put("certificateType",bhMember.getCertificateType());
        map.put("certificateNo",cardNo);
        map.put("loginMobile",mobile);
        map.put("userName",bhMember.getUserName());
        map.put("userType",bhMember.getUserType());
        map.put("loginPasswd",bhMember.getLoginPasswd().toLowerCase());
        map.put("gender",bhMember.getGender());
        map.put("birthday",bhMember.getBirthday());
        map.put("eduLevel",bhMember.getEduLevel());
        map.put("politicalStatus",bhMember.getPoliticalStatus());

        //待审核
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg4Inner?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        //直接通过审核
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg?client="+ BHConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            return jsonObject;
        }
        return null;
    }
    /**
     * 简化注册
     * @param bhMember
     * @return
     * @throws Exception
     */
    public String simpleRegBak(BHMember bhMember)throws Exception
    {
        log.info(bhMember.toString());
        String volunteerCode = null;
        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,bhMember.getLoginMobile());
        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhMember.getCertificateNo());
        Map<String,String> map = new HashMap<String,String>();
        map.put("groupCode",bhMember.getGroupCode());
        map.put("certificateType",bhMember.getCertificateType());
        map.put("certificateNo",cardNo);
        map.put("loginMobile",mobile);
        map.put("userName",bhMember.getUserName());
        map.put("userType",bhMember.getUserType());
        map.put("loginPasswd",bhMember.getLoginPasswd().toLowerCase());
        map.put("gender",bhMember.getGender());
        map.put("birthday",bhMember.getBirthday());
        map.put("eduLevel",bhMember.getEduLevel());
        map.put("politicalStatus",bhMember.getPoliticalStatus());

        System.out.println("simpleReg Map values:" + map.toString());
        //待审核
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg4Inner?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        //直接通过审核
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg?client="+ BHConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(res_code == 0 || res_code == 1703 || res_code == 1109 || res_code ==1202  || res_code ==1206)
                {
                    JSONObject jsonObject2 = jsonObject.getJSONObject("result");
                    volunteerCode = jsonObject2.getString("volunteerCode");
                }
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //reg(clientID, bhMember);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return volunteerCode;
    }
    /**
     * 平台用户注册接口
     * @param loginMobile
     * @param loginPasswd
     * @return
     * @throws Exception
     */
    public void reg4Platform(String loginMobile,String loginPasswd)throws Exception
    {
        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,loginMobile);
        String passwd= bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, loginPasswd);
        Map<String,String> map = new HashMap<String,String>();
        map.put("loginMobile",mobile);
        map.put("loginPasswd", passwd);
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg4Platform?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        HttpsUtil.post(postUrl, postEntity);
    }

//    /**
//     * 志愿者注册
//     * @param bhMember
//     * @return
//     */
//    public String reg2(BHMember bhMember)throws Exception
//    {
//        String volunteerCode = null;
//        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,bhMember.getLoginMobile());
//        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhMember.getCertificateNo());
//        bhMember.setLoginMobile(mobile);
//        bhMember.setCertificateNo(cardNo);
//
//        //待审核
////        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg4Inner?client="+ BHConstant.CLIENTID
////                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        //直接通过审核
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/reg?client="+ BHConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(bhMember, filter);
//        JSONObject jsonOb = JSON.parseObject(postEntity);
//        jsonOb.remove("volunteerCode");
//        jsonOb.remove("volunteerScore");
//        jsonOb.remove("userStatus");
//        jsonOb.remove("groupName");
//        jsonOb.remove("orgCode");
//        jsonOb.remove("orgName");
//        postEntity = jsonOb.toJSONString();
//
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(result != null && !result.trim().equals(""))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code == 0 || res_code == 1703 || res_code == 1109 || res_code ==1202)
//                {
//                    JSONObject jsonObject2 = jsonObject.getJSONObject("result");
//                    volunteerCode = jsonObject2.getString("volunteerCode");
//                }
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                   //reg(clientID, bhMember);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//
//        return volunteerCode;
//    }

    /**
     * 志愿者信息更新
     *
     * @param bhMember
     * @return
     */
    public int volunteerUpdate(BHMember bhMember)throws Exception
    {
        log.info(bhMember.toString());
        int res_code = 0;
        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,bhMember.getLoginMobile());
        String cardNo = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, bhMember.getCertificateNo());
        bhMember.setLoginMobile(mobile);
        bhMember.setCertificateNo(cardNo);

        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/update?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(bhMember,filter);
        JSONObject jsonOb = JSON.parseObject(postEntity);
        jsonOb.remove("loginPasswd");
        jsonOb.remove("volunteerFlag");
        jsonOb.remove("volunteerScore");
        jsonOb.remove("userStatus");
        jsonOb.remove("groupName");
        jsonOb.remove("orgCode");
        jsonOb.remove("orgName");
        postEntity = jsonOb.toJSONString();
        String result = HttpsUtil.post(postUrl, postEntity);
        if(StringUtils.isNotEmpty(result))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0== res_code)
                    return res_code;
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //volunteerUpdate(clientID,bhMember);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return res_code;
    }

    /**
     * 志愿者密码修改
     *
     * @param volunteerCode
     * @param newPassword
     * @return
     */
    public int updatePwd(String volunteerCode,String oldPassword,String newPassword)throws Exception
    {
        int res_code = 0;
        Map<String,String> map = new HashMap<String,String>();
        map.put("volunteerCode",volunteerCode);
        map.put("oldPassword", MD5Util.MD5(oldPassword));
        map.put("newPassword",MD5Util.MD5(newPassword));
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/resetVolunteerPwd?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0==res_code)
                    return res_code;
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //updatePwd(clientID,volunteerCode,oldPassword,newPassword);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
            return res_code;
    }
//
//    /**
//     * 查询本平台下面的志愿者信息
//     *
//     * @param groupCode
//     * @param volunteerCode
//     * @return
//     */
//    public List<Member> findVoluteer(String groupCode,String volunteerCode,String pageIdx)throws Exception
//    {
//        List<Member> list = null;
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("volunteerCode",volunteerCode);
//        map.put("groupCode",groupCode);
//
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/findVolunteer?client="+ BHConstant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(result != null && !result.trim().equals(""))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code == 0)
//                {
//                    list = new ArrayList<Member>();
//                    JSONArray jsonArray = jsonObject.getJSONArray("result");
//                    if(null == jsonArray || jsonArray.size() == 0)
//                        return null;
//                    for(int i=0;i<jsonArray.size();i++)
//                    {
//                        JSONObject object = jsonArray.getJSONObject(i);
//                        BHMember bhMember = JSON.toJavaObject(object,BHMember.class);
//                        if(null != bhMember)
//                        {
//                            bhMember.setLoginMobile(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID, bhMember.getLoginMobile()));
//                            bhMember.setCertificateNo(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID,bhMember.getCertificateNo()));
//                            bhMember.setGuardianMobile(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID,bhMember.getGuardianMobile()));
//                            bhMember.setUserStatus("1");
//                        }
//                        list.add(BHMember.toMember(bhMember));
//                    }
//                }
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return list;
//    }

    /**
     * 个人信息核实
     *
     * @param certificateType
     * @param certificateNo
     * @param name
     * @param mobile
     * @return
     */
    public String checkinfo(String certificateType,String certificateNo,String name,String mobile)throws Exception
    {
        String volunteerCode = "";
        Map<String,String> map = new HashMap<String, String>();
        map.put("certificateType",certificateType);
        map.put("certificateNo",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, certificateNo));
        map.put("name",name);
        map.put("mobile",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,mobile));
        System.out.println("checkinfo----------->" + map.toString());
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/checkinfo?client="+BHConstant.CLIENTID
            +"&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0==res_code)
                {
                    return  null;
                }
                else if(res_code == 1202 || res_code == 1206)
                {
                    JSONObject jsonObject2 = jsonObject.getJSONObject("result");
                    volunteerCode = jsonObject2.getString("volunteerCode");
                }
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //checkinfo(clientID, certificateType, certificateNo, name, mobile);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return volunteerCode;
    }

//
//    /**
//     * 志愿者登陆
//     *
//     * @param volunteerMobile
//     * @param volunteerPwd
//     * @param loginIp
//     * @param loginType
//     * @return
//     */
//    public Member volunteer(String volunteerMobile,String volunteerPwd,String loginIp,String loginType)throws Exception
//    {
//        Member member = null;
//        Map<String,String> map = new HashMap<String, String>();
//        map.put("volunteerMobile",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID, volunteerMobile));
//        //map.put("volunteerMobile",volunteerMobile);
//        map.put("volunteerPwd",MD5Util.MD5(volunteerPwd).toLowerCase());
//        map.put("loginIp",loginIp);//loginIploginIp
//        map.put("loginType",loginType);
//            String postUrl = bhConstant.checkNetWork()+"/api/v1/auth/volunteer?client="+ BHConstant.CLIENTID
//                    +"&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//            String postEntity = JSON.toJSONString(map,filter);
//            String result = HttpsUtil.post(postUrl, postEntity);
//            if(result != null && !result.trim().equals(""))
//            {
//                JSONObject jsonObject = JSON.parseObject(result);
//                if(jsonObject != null)
//                {
//                    int res_code = jsonObject.getInteger("ret");
//                    String msg = jsonObject.getString("msg");
//                    if(res_code == 0)
//                    {
//                        String result2 = jsonObject.getString("result");
//                        BHMember bhMember = JSON.toJavaObject(JSON.parseObject(result2),BHMember.class);
//                        if(null != bhMember)
//                        {
//                            if(StringUtils.isNotEmpty(bhMember.getLoginMobile()))
//                            bhMember.setLoginMobile(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID, bhMember.getLoginMobile()));
//                            if(StringUtils.isNotEmpty(bhMember.getCertificateNo()))
//                            bhMember.setCertificateNo(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID,bhMember.getCertificateNo()));
//                            if(StringUtils.isNotEmpty(bhMember.getGuardianMobile()))
//                            bhMember.setGuardianMobile(bhEncrytByPublicKey.decryptByPublicKey(BHConstant.CLIENTID,bhMember.getGuardianMobile()));
//
//                            member = BHMember.toMember(bhMember);
//
//                        }
//                        else
//                        {
//                            System.out.println("-----------------------------is null from BH volunteer -------------------------");
//                        }
//
//                    }
//                    else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                    {
//                        bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                        //volunteer(clientID, volunteerMobile, volunteerPwd, loginIp,loginType);
//                        throw new Exception(msg);
//                    }
//                    else
//                    {
//                        throw new Exception(msg);
//                    }
//                }
//            }
//            return member;
//    }

    /**
     * 志愿者登陆记录
     *
     * @param loginMobile
     * @param loginTime
     * @param loginIp
     * @param loginType
     * @return
     */
    public int accesslog(String loginMobile,String loginTime,String loginIp,String loginType)throws Exception
    {
            int res_code = 0;
            Map<String,String> map = new HashMap<String, String>();
            map.put("loginMobile",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,loginMobile));
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd HHmmss");
            map.put("loginTime",sdf2.format(new Date()));
            map.put("loginIp",loginIp);
            map.put("loginType",loginType);

            String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/accesslog?client=" + BHConstant.CLIENTID
                +"&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
            String postEntity = JSON.toJSONString(map,filter);
            String result = HttpsUtil.post(postUrl, postEntity);

            if(result != null && !result.trim().equals(""))
            {
                JSONObject jsonObject = JSON.parseObject(result);
                if(jsonObject != null)
                {
                    res_code = jsonObject.getInteger("ret");
                    String msg = jsonObject.getString("msg");
                    if(0==res_code)
                        return res_code;
                    else if(res_code == bhConstant.TOKEN_TIMEOUT)
                    {
                        bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                        //accesslog(clientID, loginMobile, loginTime, loginIp, loginType);
                        throw new Exception(msg);
                    }
                    else
                    {
                        throw new Exception(msg);
                    }
                }
            }
            return res_code;
    }

    /**
     * 查看指定会员的保险信息
     *
     * @param volunteerCode
     * @return
     * @throws Exception
     */
    public BHInsurance getVolunteerInsurance(String volunteerCode)throws Exception
    {
        BHInsurance bhInsurance = null;
        int res_code = 0;
        Map<String,String> map = new HashMap<String, String>();
        map.put("volunteerCode",volunteerCode);

        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/getVolunteerInsurance?client=" + BHConstant.CLIENTID
                +"&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        if(result != null && !result.trim().equals(""))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0==res_code)
                {
                    bhInsurance = JSON.toJavaObject(jsonObject.getJSONObject("result"),BHInsurance.class);
                }
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return bhInsurance;
    }

    public int managerLogin(String userAccount,String userPwd)throws Exception
    {
        int res_code = 1;
        Map<String,String> map = new HashMap<String,String>();
        map.put("userAccount",userAccount);
        //map.put("userAccount",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,userAccount));
        map.put("userPwd",MD5Util.MD5(userPwd).toLowerCase());
        String postUrl = bhConstant.checkNetWork()+"/api/v1/auth/user?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(StringUtils.isNotEmpty(result))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0==res_code)
                    return res_code;
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    //updatePwd(clientID,volunteerCode,oldPassword,newPassword);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return res_code;
    }

    /**
     * 购买平安保险的接口
     *
     * @param applyEncryption
     * 保险信息（applyEncryption）格式为： 手机号|姓名|证件号|证件类型|保单生效日期|保期|volunteerCode，
     * 如：13541123339|张三|654023197912214345|CID|20151001 154100|13|31-00000018-8
     * 其中：保单生效日期格式为yyyyMMdd HHmmss；保期 以月为单位
     * @return
     * @throws Exception
     */
    public JSONObject applyInsurance(String applyEncryption)throws Exception
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("applyEncryption",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,applyEncryption));
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/applyInsurance?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        System.out.println("北航返回购买保单信息："+result);

        if(StringUtils.isNotEmpty(result))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            return jsonObject;
        }
        return null;
    }

    /**
     * 加入指定的社团(直接通过)
     *
     * @param volunteerCode
     * @param groupCode
     * @return
     * @throws Exception
     */
    public JSONObject joinGroup(String volunteerCode,String groupCode)throws Exception
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("volunteerCode",volunteerCode);
        map.put("groupCode",groupCode);
        //直接通过
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        //需要审核
        //String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup4Inner?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(StringUtils.isNotEmpty(result))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            return jsonObject;
        }
        return null;
    }
    public int joinGroupBak(String volunteerCode,String groupCode)throws Exception
    {
        int res_code = 1;
        Map<String,String> map = new HashMap<String,String>();
        map.put("volunteerCode",volunteerCode);
        map.put("groupCode",groupCode);
        //直接通过
        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        //需要审核
        //String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup4Inner?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);
        if(StringUtils.isNotEmpty(result))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(0==res_code || 1405 == res_code)
                    return res_code;
                else if(res_code == bhConstant.TOKEN_TIMEOUT)
                {
                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
                    throw new Exception(msg);
                }
                else
                {
                    throw new Exception(msg);
                }
            }
        }
        return res_code;
    }
//    /**
//     * 会员退出指定社团
//     * @param volunteerCode
//     * @param groupCode
//     * @return
//     * @throws Exception
//     */
//    public int quitGroup(String volunteerCode ,String groupCode)throws Exception
//    {
//        int res_code = 1;
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("volunteerCode",volunteerCode);
//        map.put("groupCode",groupCode);
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/quitGroup?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code==0)
//                {
//                    return res_code;
//                }
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return res_code;
//    }
//    /**
//     * 加入指定的社团(需要审核)
//     *
//     * @param volunteerCode
//     * @param groupCode
//     * @return
//     * @throws Exception
//     */
//    public int joinGroup4Inner(String volunteerCode,String groupCode)throws Exception
//    {
//        int res_code = 1;
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("volunteerCode",volunteerCode);
//        map.put("groupCode",groupCode);
//        //直接通过
//        //String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        //需要审核
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/joinGroup4Inner?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(0==res_code)
//                    return res_code;
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return res_code;
//    }
//
//    /**
//     * 志愿者找回密码
//     *
//     * @param loginMobile
//     * @param last6IdNo
//     * @return
//     * @throws Exception
//     */
//    public int forgetVolunteerPwd(String loginMobile,String last6IdNo)throws Exception
//    {
//        int res_code = 1;
//        String mobile = bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,loginMobile);
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("loginMobile",mobile);
//        map.put("last6IdNo",last6IdNo);
//        System.out.println("last6IdNo------>" + last6IdNo);
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/volunteer/forgetVolunteerPwd?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(0==res_code)
//                    return res_code;
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return res_code;
//    }
//
//    /**
//     * 查询指定用户的所有权限标签
//     *
//     * @param PRJV_USER_ID
//     * @return
//     * @throws Exception
//     */
//    public String queryUserTag(int PRJV_USER_ID)throws Exception
//    {
//        String result = "";
//        //查询指定用户的所有标签
//        String sql = "select T.TAG_CODE AS TAG_CODE from PRJV_USER_TAG AS T WHERE T.USER_ID =  '"+ PRJV_USER_ID+"'";
//        List<Map<String,Number>> list = this.baseDAO.queryNativeSql(sql);
//        if(null == list || list.size() == 0)
//            return result;
//        for(Map<String,Number> map:list)
//        {
//            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(map));
//            result = result+jsonObject.getString("TAG_CODE") + ",";
//        }
//        if(StringUtils.isNotEmpty(result))
//        {
//            result = result.substring(0,result.length()-1);
//        }
//        return result;
//    }
//
//    /**
//     * 查询指定用户(非志愿者)
//     *
//     * @param loginMobile
//     * @param certificateType
//     * @param certificateNo
//     * @return
//     * @throws Exception
//     */
//    public BHUser findUser(String loginMobile,String certificateType,String certificateNo)throws Exception
//    {
//        BHUser bhUser = null;
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("loginMobile",bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,loginMobile));
//        map.put("certificateType",certificateType);
//        map.put("certificateNo", bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,certificateNo));
//        String postUrl = bhConstant.checkNetWork()+"/api/v1/user/findUser?client="+ BHConstant.CLIENTID+ "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(0==res_code)
//                {
//                    JSONObject object = jsonObject.getJSONObject("result");
//                    if(null != object)
//                    {
//                        if(null == object.getString("userId"))
//                            return null;
//                        else
//                        {
//                            bhUser = JSON.toJavaObject(object,BHUser.class);
//                        }
//                    }
//                }
//                else if(res_code == bhConstant.TOKEN_TIMEOUT)
//                {
//                    bhAccesssToken.refreshToken(BHConstant.CLIENTID);
//                    throw new Exception(msg);
//                }
//                else
//                {
//                    throw new Exception(msg);
//                }
//            }
//        }
//        return bhUser;
//    }
//

    /**
     * 检查用户的信息是否全部被锁
     * @param token
     * @param volunteerCode
     * @param userName
     * @param userCertNo
     * @param userCertType
     * @param userMobile
     * @param dataSource
     * @return
     * @throws Exception
     */
    public boolean lockInfo(String token,String volunteerCode,
                               String userName,String userCertNo,
                               String userCertType,String userMobile,
                               String dataSource)throws Exception{

        Map<String,String> map = new HashMap<String,String>();
        map.put("volunteerCode",volunteerCode);
        map.put("userName",userName);
        map.put("userCertNo", bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,userCertNo));
        map.put("userCertType",userCertType);
        map.put("userMobile", bhEncrytByPublicKey.encryptByPublicKey(BHConstant.CLIENTID,userMobile));
        map.put("dataSource",dataSource);


        String postUrl = bhConstant.checkNetWork()+"/api/v1/info/lockInfo?client="+ BHConstant.CLIENTID+ "&token="+token;
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        //{"ret":0,"msg":"","result":{"lockResult":"success"}}
        JSONObject json = (JSONObject) JSONObject.parse(result);
        String ret = json.get("ret").toString();
        if("0".equals(ret)){
            JSONObject r = (JSONObject)json.get("result");
            if("success".equals(r.getString("lockResult"))){
                return true;
            }
        }else{
            throw new Exception(json.get("msg").toString());
        }

        return false;
    }
//
//    /**
//     * /info/ensureAllInfo 这个是确认三个field是否锁定的
//     *
//     * @param token
//     * @param userId
//     * @return
//     * @throws Exception
//
//    public boolean ensureAllInfo(String token,String userId)throws Exception{
//
//    }
//     */
//
//    /**
//     * /info/ensureOneInfo 这个是确认谋一个field是否锁定的
//     *  private String userId =null;
//     private String ensureField=null;
//     *
//     * @param token
//     * @param userId
//     * @param ensureField
//     * @return
//     * @throws Exception
//
//    public boolean ensureOneInfo(String token,String userId,String ensureField)throws Exception{
//
//    }
//     */
}
