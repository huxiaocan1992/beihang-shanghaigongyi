package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.AdminUser;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
@Repository(value = "adminUserMapper")
public interface AdminUserMapper extends BaseMapper<AdminUser> {
    AdminUser selectByMobile(String mobile);
}