package cn.dakaqi.blank.controller.response;

import cn.dakaqi.blank.util.wechatPay.PayJsWithAppId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubmitSuccessResponseItem {

    private String orderId = "";

    private String orderCode = "";

    private String callBack = "";

    private String prePay_Id = "";

    private PayJsWithAppId payConfig = null;

    public static SubmitSuccessResponseItem build(String orderId, String orderCode, String prepay_id,
                                                  PayJsWithAppId payConfig) {
        SubmitSuccessResponseItem submitSuccessResponseItem = new SubmitSuccessResponseItem();
        submitSuccessResponseItem.setOrderId(orderId);
        submitSuccessResponseItem.setOrderCode(orderCode);
        submitSuccessResponseItem.setPrePay_Id(prepay_id);
        submitSuccessResponseItem.setPayConfig(payConfig);

        return submitSuccessResponseItem;
    }

    public static SubmitSuccessResponseItem build(String orderId, String orderCode, String prepay_id,
                                                  PayJsWithAppId payConfig, String callBackUrl) {
        SubmitSuccessResponseItem submitSuccessResponseItem = new SubmitSuccessResponseItem();
        submitSuccessResponseItem.setOrderId(orderId);
        submitSuccessResponseItem.setOrderCode(orderCode);
        submitSuccessResponseItem.setPrePay_Id(prepay_id);
        submitSuccessResponseItem.setPayConfig(payConfig);
        submitSuccessResponseItem.setCallBack(callBackUrl);

        return submitSuccessResponseItem;
    }
}
