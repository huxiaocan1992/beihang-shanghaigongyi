package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.entity.InsuranceUser;
import cn.dakaqi.blank.entity.web.SessionHolder;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.service.InsuranceUserService;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.Date;

@Controller
@RequestMapping("/insuranceUser")
@Slf4j
@ApiIgnore
public class InsuranceUserController {

    @Resource
    private InsuranceUserService insuranceUserService;

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseBody
    public DataResponseVo save(@RequestBody InsuranceUser insuranceUser) {
        String openId = SessionHolder.getOpenId();
        if (StringUtils.isEmpty(openId)) {
            return new DataResponseVo(StatusCode.SERVER_EXCEPTION.getCode(), "用户信息获取失败");
        }

        insuranceUser.setCreateTime(new Date());
        insuranceUser.setOpenId(openId);

        insuranceUserService.insertOrUpdate(insuranceUser);

        return new DataResponseVo(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
    }
}
