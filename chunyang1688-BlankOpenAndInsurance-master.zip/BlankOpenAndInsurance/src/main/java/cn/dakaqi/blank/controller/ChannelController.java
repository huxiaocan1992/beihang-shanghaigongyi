package cn.dakaqi.blank.controller;

import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.TradeListVo;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.rsa.AesTest;
import cn.dakaqi.blank.rsa.RSASignature;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.util.JsonResult;
import cn.dakaqi.blank.util.PageData;
import com.baomidou.mybatisplus.plugins.Page;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Yanghu
 * @since 2016-11-30
 */
@RestController
@RequestMapping("/channel")
@Slf4j
@Api(value = "测试")
public class ChannelController extends BaseController {
    @Autowired
    IChannelService channelService;

    @ResponseBody
    @RequestMapping(method = RequestMethod.GET)
    public Object getList() {
        List<Channel> r = channelService.selectList(null);
        return renderSuccess(r);
    }

    @RequestMapping(value = "/encrypt", method = RequestMethod.GET)
    public JsonResult encrypt(@RequestParam("source") String source, @RequestParam("aes_key") String aes_key) {
        String ciphertext = "";
        Map<String, Object> resultMap = new HashMap<>();
        try {
            // AES加密
            ciphertext = AesTest.encrypt(source, aes_key);
            System.out.println("ciphertext:" + ciphertext);
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }
        resultMap.put("ciphertext", ciphertext);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/decrypt", method = RequestMethod.GET)
    public JsonResult decrypt(@RequestParam("source") String source, @RequestParam("aes_key") String aes_key) {
        String ciphertext = "";
        Map<String, Object> resultMap = new HashMap<>();
        try {
            // AES加密
            ciphertext = AesTest.decrypt(source, aes_key);
            System.out.println("ciphertext:" + ciphertext);
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }
        resultMap.put("ciphertext", ciphertext);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/sign", method = RequestMethod.GET)
    public JsonResult sign(@RequestParam("source") String source, @RequestParam("private_key") String private_key) {
        String sign = "";
        Map<String, Object> resultMap = new HashMap<>();
        try {
            // AES加密
            sign = RSASignature.sign(source, private_key);
            System.out.println("sign:" + sign);
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }
        resultMap.put("sign", sign);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/verify", method = RequestMethod.GET)
    public JsonResult verify(@RequestParam("source") String source, @RequestParam("sign") String sign, @RequestParam("public_key") String public_key) {
        boolean flag = false;
        Map<String, Object> resultMap = new HashMap<>();
        try {
            // 验签
            flag = RSASignature.verify(source, sign, public_key);
            System.out.println("验签结果 : " + flag);
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }
        resultMap.put("flag", flag);
        return renderSuccess(resultMap);
    }

    @RequestMapping(value = "/testpage", method = RequestMethod.GET)
    public JsonResult testpage(@RequestParam("page") int page) {
        Map<String, Object> resultMap = new HashMap<>();
        try {
            Page<Channel> data = this.channelService.testQueryByPage(page, 2);
            resultMap.put("data", data);
        } catch (Exception e) {
            e.printStackTrace();
            return renderError(e.getMessage());
        }

        return renderSuccess(resultMap);
    }


    /**
     * 微信回调
     * 根据channel的code返回回调页面
     */
    @RequestMapping(value = "/queryBycode", method = RequestMethod.POST)
    @ResponseBody
    public Object queryOrderList(@RequestBody Channel param) throws Exception {
        if (param.getCode() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel = channelService.selectByCode(param.getCode());
        if (channel.getPageRetUrl() != null) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), channel.getPageRetUrl());
        } else {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        }

    }


//    @RequestMapping("/")
//    public ModelAndView index(ModelAndView modelAndView) {
//        modelAndView.setViewName("index");
//        modelAndView.addObject("userList", userService.selectList(null));
//        return modelAndView;
//    }
//
//    @RequestMapping("/preSave")
//    public ModelAndView preSave(ModelAndView modelAndView, @RequestParam(value = "id", required = false) Long id) {
//        modelAndView.setViewName("save");
//        if (id != null) {
//            modelAndView.addObject("user", userService.selectById(id));
//        }
//        return modelAndView;
//    }
//
//    @ResponseBody
//    @RequestMapping("save")
//    public Object save(User user) {
//        if (user.getId() == null) {
//            return userService.insert(user) ? renderSuccess("添加成功") : renderError("添加失败");
//        } else {
//            return userService.updateById(user) ? renderSuccess("修改成功") : renderError("修改失败");
//        }
//    }
//
//    @ResponseBody
//    @RequestMapping("/delete")
//    public Object delete(@RequestParam(value = "id", required = false) Long id) {
//        return userService.deleteById(id) ? renderSuccess("删除成功") : renderError("删除失败");
//    }


}
