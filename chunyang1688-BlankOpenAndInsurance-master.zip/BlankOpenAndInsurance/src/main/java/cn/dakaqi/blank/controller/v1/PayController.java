/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.BaseController;
import cn.dakaqi.blank.controller.input.PayInputVO;
import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.controller.response.SubmitSuccessResponseItem;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.OrderInfo;
import cn.dakaqi.blank.entity.web.SessionHolder;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.exception.LoginRequiredException;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.service.OrderInfoService;
import cn.dakaqi.blank.util.DateUtil;
import cn.dakaqi.blank.util.OrderStatus;
import cn.dakaqi.blank.util.Tools;
import com.mangofactory.swagger.annotations.ApiIgnore;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * 类名称：PayController <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @version 1.0.0
 * @since 2016/12/7 15:26
 */

@RestController
@RequestMapping(value = "/pay")
@Slf4j
@Api(value = "支付", description = "支付", hidden = false)
@ApiIgnore
public class PayController extends BaseController {
    @Autowired
    OrderInfoService orderInfoService;

    @Resource
    private IChannelService channelService;

    @RequestMapping(value = "/pay4wechat", method = RequestMethod.POST)
    @ApiOperation(value = "微信支付", notes = "微信支付")
    @ResponseBody
    public DataResponseVo<SubmitSuccessResponseItem> explain(HttpServletRequest request, @RequestBody PayInputVO payInputVO) {

        OrderInfo orderInfo = new OrderInfo();
        String temp = DateUtil.currentDateStringTrim().substring(2, DateUtil.currentDateStringTrim().length());
        orderInfo.setUuid(Tools.getUUID());
        orderInfo.setOrderCode(payInputVO.getChannelCode() + payInputVO.getBusinessCode() + temp + Tools.generateShortUuid());
        orderInfo.setOrderChannel(payInputVO.getChannelCode());
        orderInfo.setOrderBusiness(payInputVO.getBusinessCode());
        orderInfo.setTotal(new BigDecimal(payInputVO.getMoney()));
        orderInfo.setPayState(OrderStatus.UNPAY.getSequenceId());
        orderInfo.setCreateTime(new Date());
        orderInfo.setUpdateTime(new Date());
        orderInfo.setOrderStatus(OrderStatus.UNPAY.getSequenceId());
        orderInfo.setPayState(1); //1 待支付 2 支付成功
        orderInfo.setPayPattern(1);//默认1网页支付

        orderInfo.setBeneficiary(payInputVO.getProjectName());
        orderInfo.setSourcePayUser(payInputVO.getUserId());
        orderInfo.setSourceOrderCode(payInputVO.getOrderCode());

        this.orderInfoService.insert(orderInfo);

        if (SessionHolder.getOpenId() == null || "".equals(SessionHolder.getOpenId())) {
            throw new LoginRequiredException(StatusCode.COMMON_USER_NOT_LOGIN.getCode() + "", StatusCode.COMMON_USER_NOT_LOGIN.getMessage());
        }

        SubmitSuccessResponseItem item = orderInfoService.unifiedOrder(Tools.getIpAddr(request), orderInfo.getOrderCode(), SessionHolder.getOpenId());

        Channel channel = channelService.selectByCode(payInputVO.getChannelCode());

        //页面回调地址
        item.setCallBack(channel.getPageRetUrl());

        String prePayId = item.getPrePay_Id();
        if (prePayId != null && !Objects.equals("", prePayId)) {
            orderInfo.setPrepayId(prePayId);
        }

        this.orderInfoService.updateById(orderInfo);

        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), item);
    }
}
 
 