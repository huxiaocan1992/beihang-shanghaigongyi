package cn.dakaqi.blank.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookieUtil {
    
    public static String getCookieOpenid(HttpServletRequest request) {
        try {
            Cookie[] cookies = request.getCookies();
            if (null != cookies)
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("newOpenId")) {
                        String openid = cookie.getValue();
                        return openid;
                    }
                }
        } catch (Exception ignored) {
        }
        return null;
    }
    
    public static String getCookieAccess(HttpServletRequest request) {
        try {
            Cookie[] cookies = request.getCookies();
            if (null != cookies)
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("accessToken")) {
                        String token = cookie.getValue();
                        return token;
                    }
                }
        } catch (Exception ignored) {
        }
        return null;
    }
    
    public static String getSessionId(HttpServletRequest request) {
        try {
            Cookie[] cookies = request.getCookies();
            if (null != cookies)
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("sessionId")) {
                        String token = cookie.getValue();
                        return token;
                    }
                }
        } catch (Exception ignored) {
        }
        return null;
    }
    
}
