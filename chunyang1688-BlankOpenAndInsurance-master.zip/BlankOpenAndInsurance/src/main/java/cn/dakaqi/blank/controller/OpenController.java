package cn.dakaqi.blank.controller;

import cn.dakaqi.blank.service.OrderInfoService;
import com.mangofactory.swagger.annotations.ApiIgnore;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *   前端控制器
 * </p>
 *
 * @author Yanghu
 * @since 2016-11-30
 */
@Controller
@RequestMapping("/open")
@ApiIgnore
public class OpenController extends BaseController
{
    @Resource
    private OrderInfoService orderInfoService;

    @RequestMapping(value = "/success", method = RequestMethod.POST)
    @ResponseBody
    public String success(HttpServletRequest request) throws Exception {
        return orderInfoService.wxCallback(request.getInputStream());
    }
}
