package cn.dakaqi.blank.exception;

/**
 * @author chunyang on 2016/3/21.
 */
public class ServiceRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 2319364757089619066L;
    private int code = 0;
    private String message = null;

    public ServiceRuntimeException() {
        super();
    }

    public ServiceRuntimeException(String message) {
        this.message = message;
    }

    public ServiceRuntimeException(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public ServiceRuntimeException(Throwable cause) {
        super(cause);
    }

    public ServiceRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
