package cn.dakaqi.blank.enumerate;

/**
 * @author jayli
 */
public enum SpecialUrlType {
    INDEX_PAGE("1"), PAY_URL("2"), INSURANCE_BINDING("3"),;

    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    SpecialUrlType(String type) {
        this.type = type;
    }
}
