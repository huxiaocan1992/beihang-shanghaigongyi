package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.Insurance;
import cn.dakaqi.blank.mapper.InsuranceMapper;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.service.IInsuranceService;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.service.qnzyz.*;
import cn.dakaqi.blank.util.Constant;
import cn.dakaqi.blank.util.DateUtil;
import cn.dakaqi.blank.util.StringUtil;
import cn.dakaqi.blank.util.Tools;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-02
 */
@Service
@Slf4j
public class InsuranceServiceImpl extends ServiceImpl<InsuranceMapper, Insurance> implements IInsuranceService {
    /**
     * The Channel service.
     */
    @Autowired
    IChannelService channelService;
    @Autowired
    BHMemberService bhMemberService;
    @Autowired
    BHAccesssToken bhAccesssToken;
    @Autowired
    ITradeListService tradeListService;


    /**
     * 购买保险
     *
     * @param channelCode   渠道编码
     * @param idNo          身份证号
     * @param groupCode     社团编码
     * @param volunteerCode 志愿者编码
     * @throws Exception
     */
    @Override
    public Insurance saveInsurance(String channelCode, String bussionCode,String idNo, String groupCode, final String volunteerCode, String realName, String mobile) throws Exception {
        Insurance insurance = null;

        log.info("saveInsurance----------channelCode:" + channelCode + ",bussionCode:"  +bussionCode + ",idNo:" + idNo + ",groupCode" +groupCode + ",volunteerCode:" + volunteerCode + ",realName:" + realName+ ",mobile:" + mobile);
        //检查当前渠道是否需要购买保险
        Wrapper<Channel> channelWrapper = new Wrapper<Channel>() {
            @Override
            public String getSqlSegment() {
                return " where code = '" + channelCode + "'";
            }
        };
        Channel channel = this.channelService.selectOne(channelWrapper);
        if (null == channel) {
            log.info("渠道无效");
            return null;
        }
        //检查当前渠道是否需要购买保险
        if (!bussionCode.contains("D") && !bussionCode.contains("A") && !bussionCode.contains("F")  && !bussionCode.contains("G")) {
            return null;
        }
        //检查当前用户是否是注册志愿者
        if (null != volunteerCode && !"null".equals(volunteerCode) && StringUtil.isNotEmpty(volunteerCode))
        {
            log.info("saveInsurance----------3----------->");
            //检查本地保险表中是否已存在
            Wrapper<Insurance> insuranceWrapper = new Wrapper<Insurance>() {
                @Override
                public String getSqlSegment() {
                    return " where volunteerCode = '" + volunteerCode + "' and status = " + Constant.HAS_INSURANCE_YES + " order by id desc limit 1 ";
                }
            };
            insurance = super.selectOne(insuranceWrapper);
            if (null != insurance)
                return insurance;
            log.info("saveInsurance----------4----------->");
            //购买保险
            insurance = saleFromBH(channel.getCode(),volunteerCode, realName, idNo, mobile);
        }
        else
        {
            if(null == groupCode || StringUtil.isEmpty(groupCode) || "null".equals(groupCode))
                groupCode = "GV0000079457";
            //加入当前社团,成为一名志愿者
            if (null != groupCode && StringUtil.isNotEmpty(groupCode))
            {
                try {
                    String volCode = joinGroup(groupCode, idNo, realName, mobile);
                    if (null != volCode && StringUtil.isNotEmpty(volCode))
                        insurance = saleFromBH(channel.getCode(),volCode, realName, idNo, mobile);
                    if (null != insurance)
                    {
                        String insuranceNo = insurance.getInsuranceNo();
                        //检查本地保险表中是否已存在
                        Wrapper<Insurance> insuranceWrapper = new Wrapper<Insurance>() {
                            @Override
                            public String getSqlSegment() {
                                return " where insuranceNo = '" + insuranceNo + "' limit 1 ";
                            }
                        };
                        Insurance tempInsurance = super.selectOne(insuranceWrapper);
                        if (null != tempInsurance)
                            return tempInsurance;

                        super.insert(insurance);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return insurance;
    }
    @Override
    public Insurance selectByVolunteerCode(String volunteerCode) {
        Insurance insurance;
        try {

            Wrapper<Insurance> insuranceWrapper = new Wrapper<Insurance>() {
                @Override
                public String getSqlSegment() {
                    return " where volunteerCode = '" + volunteerCode + "' and status = " + Constant.HAS_INSURANCE_YES + " order by id desc limit 1 ";
                }
            };
            insurance = super.selectOne(insuranceWrapper);
            if (null == insurance) {
                //查询北航库中是否有保险记录
                BHInsurance bhInsurance = bhMemberService.getVolunteerInsurance(volunteerCode);
                if (null != bhInsurance) {
                    insurance = buidlBHInsurance(volunteerCode, bhInsurance);
                    if (null != insurance)
                        super.insert(insurance);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return insurance;
    }

    @Override
    public Insurance selectByInsuranceNo(String insuranceNo) {
        Wrapper<Insurance> insuranceWrapper = new Wrapper<Insurance>() {
            @Override
            public String getSqlSegment() {
                return " where insuranceNo = '" + insuranceNo + "' and status = " + Constant.HAS_INSURANCE_YES + " order by id desc limit 1 ";
            }
        };
        return super.selectOne(insuranceWrapper);
    }

    /**
     * 加入指定社团，成为志愿者
     *
     * @param groupCode 社团编码
     * @param idNo      身份证号
     * @param realName  真实姓名
     * @param mobile    手机号
     * @return 加入结果
     * @throws Exception
     */
    private String joinGroup(String groupCode, String idNo, String realName, String mobile) throws Exception {
        String volunteerCode = "";
        BHMember bhMember = new BHMember();
        bhMember.setLoginMobile(mobile);
        bhMember.setCertificateType("CID");
        bhMember.setCertificateNo(idNo);
        bhMember.setGroupCode(groupCode);
        bhMember.setUserName(realName);
        bhMember.setUserType("2");
        bhMember.setLoginPasswd("123456");
        bhMember.setGender(Tools.getGenderFromCardNO(idNo));
        bhMember.setBirthday(Tools.getBirthFromCardNO(idNo));
        bhMember.setEduLevel("10");
        bhMember.setPoliticalStatus("3");
        log.info(bhMember.toString());
        JSONObject jsonObject = this.bhMemberService.simpleReg(bhMember);
        if (jsonObject != null) {
            int res_code = jsonObject.getInteger("ret");
            String msg = jsonObject.getString("msg");
            if (res_code == 0 || res_code == 1703 || res_code == 1109 || res_code == 1202 || res_code == 1206) {
                JSONObject jsonObject2 = jsonObject.getJSONObject("result");
                volunteerCode = jsonObject2.getString("volunteerCode");
            } else {
                throw new Exception(msg);
            }
        }
        return volunteerCode;
    }

    /**
     * 向北航购买保险
     *
     * @param volunteerCode 志愿者编码
     */
    private Insurance saleFromBH(String channel,String volunteerCode, String userName, String userCertNo, String userMobile) {
        BHInsurance bhInsurance;
        try {
            log.info("saveInsurance----------5----------->");
            //查询当前用户是否已购买过保险
            bhInsurance = bhMemberService.getVolunteerInsurance(volunteerCode);
            if (null != bhInsurance) {
                return buidlBHInsurance(volunteerCode, bhInsurance);
            }

            String token = bhAccesssToken.getAccessToken(BHConstant.CLIENTID);
            boolean flag = bhMemberService.lockInfo(token, volunteerCode, userName, userCertNo, "CID", userMobile, "8000");
            if (!flag) {
                //用户锁定失败
                log.error("购买保险时,用户锁定失败");
                return null;
            }

            //向北航系统购买
            JSONObject jsonObject = bhMemberService.applyInsurance(getApplyEncryption(userMobile, userName, userCertNo, "CID",
                    System.currentTimeMillis(), 12, volunteerCode));

            if (jsonObject.getInteger("ret") > 0) {
                //保险领取失败
                log.error("购买保险时,用户锁定失败:" + jsonObject.getString("msg"));
                return null;
            }

            //insertTradeList(channel,userCertNo,userMobile);
            bhInsurance = bhMemberService.getVolunteerInsurance(volunteerCode);
            if (null != bhInsurance)
                return buidlBHInsurance(volunteerCode, bhInsurance);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return null;

    }

    /**
     * 拼接领取保险参数字符串
     *
     * @param phone         手机号
     * @param name          姓名
     * @param idCard        证件号
     * @param cardType      证件类型
     * @param startDate     保单生效日期
     * @param longTime      保期
     * @param volunteerCode 用户编码
     * @return 拼接成功后字符串
     */
    private String getApplyEncryption(String phone, String name, String idCard, String cardType, long startDate, int longTime, String volunteerCode) {
        //手机号|姓名|证件号|证件类型|保单生效日期|保期|volunteerCode
        //13541123339|张三|654023197912214345|CID|20151001 154100|13|31-00000018-8
        //其中：保单生效日期格式为yyyyMMdd HHmmss；保期 以月为单位

        DateFormat sdf = new SimpleDateFormat("yyyyMMdd HHmmss");

        return phone + "|" + name + "|" + idCard + "|" + cardType + "|" + sdf.format(new Timestamp(startDate)) + "|" + longTime + "|" + volunteerCode;
    }

    /**
     * Buidl bh insurance insurance.
     *
     * @param volunteerCode the volunteer code
     * @param bhInsurance   the bh insurance
     * @return the insurance
     */
    public Insurance buidlBHInsurance(String volunteerCode, BHInsurance bhInsurance) {
        Insurance insurance = new Insurance();
        insurance.setVolunteerCode(volunteerCode);
        insurance.setInsuranceNo(bhInsurance.getInsuranceNo());
        insurance.setPeriodStart(bhInsurance.getPeriodStart());
        insurance.setPeriodEnd(bhInsurance.getPeriodEnd());
        insurance.setServiceProvider(bhInsurance.getServiceProvider());
        insurance.setServiceProviderUrl(bhInsurance.getServiceProviderUrl());
        insurance.setStatus(Constant.INSURANCE_STATUS_VALID);
        insurance.setPayId(bhInsurance.getPayId());
        insurance.setPremium(bhInsurance.getPremium());
        insurance.setInsuranceProcessDate(bhInsurance.getInsuranceProcessDate());
        insurance.setTransactionBatch(bhInsurance.getTransactionBatch());
        insurance.setCreateTime(DateUtil.getToday());
        return insurance;
    }
}