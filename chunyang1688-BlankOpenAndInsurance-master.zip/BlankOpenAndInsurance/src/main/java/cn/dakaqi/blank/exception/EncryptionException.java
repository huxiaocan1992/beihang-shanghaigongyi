package cn.dakaqi.blank.exception;

public class EncryptionException extends RuntimeException {
    
    /**
     *
     */
    private static final long serialVersionUID = 7010870377596849574L;
    
    private String field;
    
    private String errorCode;
    
    public String getField() {
        return field;
    }
    
    public void setField(String field) {
        this.field = field;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    
    public EncryptionException(String field, String errorCode) {
        super(errorCode);
        this.field = field;
        this.errorCode = errorCode;
    }
}
