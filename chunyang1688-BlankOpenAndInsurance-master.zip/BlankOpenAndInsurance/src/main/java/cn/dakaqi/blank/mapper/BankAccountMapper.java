package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.BankAccount;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
@Repository(value = "bankAccountMapper")
public interface BankAccountMapper extends BaseMapper<BankAccount> {

}