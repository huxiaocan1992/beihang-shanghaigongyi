package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-20
 */
@TableName("activateRecord")
@ToString
public class ActivateRecord implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 姓名
	 */
	private String realName;

	/**
	 * 手机号
	 */
	private String mobile;

	/**
	 * 身份证
	 */
	private String idNo;

	/**
	 * 银行卡号
	 */
	private String backAccount;

	/**
	 * 护照编号
	 */
	private String passportNo;

	/**
	 * 激活状态 10未 20已
	 */
	private Integer status;

	/**
	 * 创建时间
	 */
	private Date createTime;



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public String getBackAccount() {
		return backAccount;
	}

	public void setBackAccount(String backAccount) {
		this.backAccount = backAccount;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
