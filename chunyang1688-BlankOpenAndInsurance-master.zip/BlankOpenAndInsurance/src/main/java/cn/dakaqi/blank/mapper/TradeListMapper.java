package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.ChannelRequestVo;
import cn.dakaqi.blank.entity.vo.TradeListVo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-07
 */
@Repository(value = "tradeListMapper")
public interface TradeListMapper extends BaseMapper<TradeList> {

    List<TradeList> queryPage(TradeListVo vo);
    int queryPageCount(TradeListVo vo);

}