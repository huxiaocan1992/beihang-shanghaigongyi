package cn.dakaqi.blank.service.pingan;

import cn.dakaqi.blank.controller.input.OpenAccountVO;
import cn.dakaqi.blank.util.PingAnRequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author chunyang on 2016/12/1.
 */
public interface IPingAnService
{

    /**
     * Save open account.
     *
     * @param request            the request
     * @param response           the response
     * @param pingAnRequestParam the ping an request param
     * @param openAccountVO      the open account vo
     * @throws Exception the exception
     */
    String saveOpenAccount(HttpServletRequest request, HttpServletResponse response, PingAnRequestParam pingAnRequestParam, OpenAccountVO openAccountVO)throws Exception;
}
