package cn.dakaqi.blank.util;

public enum OrderStatus {
    UNPAY(10), PAYING(20), TOCONFIRM(30), FINISHED(40), CANCELED(50),REFUNDING(60), REFUND(70), REFUNDFAIL(80);
            
    private int sequenceId;
    
    private OrderStatus(int sequenceId) {
        this.sequenceId = sequenceId;
    }
    
    public int getSequenceId() {
        return sequenceId;
    }
    
}