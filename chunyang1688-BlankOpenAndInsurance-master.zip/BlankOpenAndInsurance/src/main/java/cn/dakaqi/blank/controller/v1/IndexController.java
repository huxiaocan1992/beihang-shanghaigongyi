package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.input.wechat.UrlRequestVo;
import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.enumerate.SpecialUrl;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.exception.ServiceRuntimeException;
import cn.dakaqi.blank.util.ConfigUtil;
import cn.dakaqi.blank.util.wechatPay.JsUtil;
import cn.dakaqi.blank.util.wechatPay.Ticket;
import cn.dakaqi.blank.util.wechatPay.Token;
import cn.dakaqi.blank.util.wechatPay.WechatUtil;
import com.alibaba.fastjson.JSONObject;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping("/index")
@Slf4j
@ApiIgnore
public class IndexController {

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    private final static String WEI_XIN_BROWSER = "micromessenger/";

    /**
     * 获取微信签名
     *
     * @param param 需要签名的页面
     * @return 签名信息
     */
    @RequestMapping(method = RequestMethod.POST, value = "/getWeChatJsSign")
    @ResponseBody
    public DataResponseVo<JSONObject> getWeChatJsSign(@RequestBody UrlRequestVo param) {

        if (StringUtils.isEmpty(param.getUrl())) {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), "输入参数异常");
        }


        String accessToken = redisTemplate.opsForValue().get("wxAccessToken");
        if (StringUtils.isBlank(accessToken)) {
            Token token = WechatUtil.token(ConfigUtil.getWxAppId(), ConfigUtil.getWxSecret());

            if (token == null || token.getAccess_token() == null) {
                return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), "token获取异常");
            }

            accessToken = token.getAccess_token();

            redisTemplate.opsForValue().set("wxAccessToken", accessToken);
            redisTemplate.expire("wxAccessToken", 3600, TimeUnit.SECONDS);

        }

        Ticket ticket = WechatUtil.ticketGetticket(accessToken);

        String jsTiket = ticket.getTicket();
        String json = JsUtil.generateConfigJson(jsTiket, false, ConfigUtil.getWxAppId(), param.getUrl(), "showOptionMenu", "hideOptionMenu", "hideMenuItems", "closeWindow", "chooseWXPay", "scanQRCode", "onMenuShareTimeline", "onMenuShareAppMessage", "openLocation", "getLocation");
        JSONObject jsonObject = JSONObject.parseObject(json);
        log.info("/IndexController/getWeChatJsSign, responseJson" + jsonObject);
        return new DataResponseVo<>(StatusCode.OK.getCode(), jsTiket, jsonObject);
    }

    /**
     * 初始入口 通过这个接口获取openId
     *
     * @param request  http请求
     * @param response HttpResponse
     */
    @RequestMapping(method = RequestMethod.GET, value = "/indexPage")
    @ResponseBody
    public void indexSilent(HttpServletRequest request, HttpServletResponse response) {
        String paramString = request.getQueryString();
        Map<String, String[]> requestParameterMap = request.getParameterMap();
        log.info("/IndexController/indexPage, paramString" + paramString);
        String userAgent = request.getHeader("user-agent").toLowerCase();
        log.info("/IndexController/indexPage, userAgent : " + userAgent);

        try {
            //微信浏览器
            if ((userAgent.indexOf(WEI_XIN_BROWSER.toLowerCase()) > 0)) {

                log.info("/IndexController/indexPage, wei xin browser" + paramString);

                String callbackUrl = "/index/indexCb";
                if (requestParameterMap.get("type") != null && SpecialUrl.getByType(requestParameterMap.get("type")[0]) != null) {
                    callbackUrl = SpecialUrl.getByType(requestParameterMap.get("type")[0]).getCallbackUrl();
                }
                String wechatUrl = ConfigUtil.getRootUrl();
                log.info("/IndexController/indexPage, beliveli ==== wechatUrl > " + wechatUrl);

                String redirectUrl = WechatUtil.getWXOauthPageApi(ConfigUtil.getWxAppId(), wechatUrl
                        + callbackUrl + "?" + URLEncoder.encode(paramString, "UTF-8"));

                log.info("/IndexController/indexPage, beliveli ==== redirectUrl > " + redirectUrl);
                response.sendRedirect(redirectUrl);
            } else { //其他浏览器
                log.info("/IndexController/indexPage, not wei xin browser");
            }
        } catch (IOException e) {
            throw new ServiceRuntimeException(StatusCode.SERVER_EXCEPTION.getCode(), "Confront problem at /index/indexPage");
        }

    }

    /**
     * 获取OpenId的微信服务器回调接口
     *
     * @param request  http请求
     * @param response httpResponse
     */
    @RequestMapping(method = RequestMethod.GET, value = "/indexCb")
    @ResponseBody
    public void indexSilentCb(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String[]> requestParameterMap = request.getParameterMap();
        String paramString = "";
        try {
            paramString = URLDecoder.decode(request.getQueryString(), "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        if (requestParameterMap.get("code") == null) {
            throw new ServiceRuntimeException(StatusCode.SERVER_EXCEPTION.getCode(), "exception.wechat.not.authorization");
        }
        String code = requestParameterMap.get("code")[0];

        log.info("/IndexController/indexcb, param : " + paramString);
        HashMap<String, String> hashMap = WechatUtil.getOpenId(ConfigUtil.getWxAppId(), ConfigUtil.getWxSecret(), code);
        log.info("/IndexController/indexcb, Hash : " + hashMap);
        String openId = null;
        String token = null;
        if ((hashMap != null ? hashMap.get("openid") : null) != null && hashMap.get("token") != null) {
            openId = hashMap.get("openid");
            token = hashMap.get("token");
            log.info("/IndexController/indexcb, openId : " + openId + ", token : " + token);

//            Token _token = WechatUtil.token(ConfigUtil.getWxAppId(), ConfigUtil.getWxSecret());
//            if (_token != null) {
//                UserInfo info = WechatUtil.getUserInfo(_token.getAccess_token(), openId);
//                if (null != info && info.getOpenid() != null) {
//                    userService.saveWX(info);
//                }else {
//                    throw new ServiceRuntimeException("exception.wechat.not.authorization");
//                }
//            }
        }
        log.info("/IndexController/indexcb, openId : " + openId);
        if (!StringUtils.isEmpty(openId)) {
            Cookie cookie = new Cookie("newOpenId", openId);
            cookie.setMaxAge(60 * 60 * 24 * 365);
            cookie.setPath("/");
            response.addCookie(cookie);
        }
        if (!StringUtils.isEmpty(token)) {
            Cookie cookie = new Cookie("accessToken", token);
            cookie.setMaxAge(60 * 60 * 24 * 365);
            cookie.setPath("/");
            response.addCookie(cookie);
        }
        try {
            String wechatUrl = ConfigUtil.getRootUrl();

            String redirectStr = "/static/index.html";
            if (requestParameterMap.get("type") != null && SpecialUrl.getByType(requestParameterMap.get("type")[0]) != null) {
                redirectStr = SpecialUrl.getByType(requestParameterMap.get("type")[0]).getRedirectUrl();
            }
            String redirectUrl = wechatUrl + redirectStr;
            log.info("/IndexController/indexcb, redirectUrl" + redirectUrl + "?" + paramString);
            response.sendRedirect(redirectUrl + "?" + paramString);
        } catch (IOException e) {
            throw new RuntimeException("Confront problem at getOpenIdStepTwo");
        }
    }

    /**
     * 测试接口  给定一个openId
     *
     * @param response httpResponse
     */
    @RequestMapping(method = RequestMethod.GET, value = "/test")
    @ResponseBody
    public void setTestOpenId(HttpServletResponse response) {
        // Set a fake openId for dev purpose
        String openId = "oNcrgvpKHJOeyrF-3DjXCND6KF3k";
        Cookie cookie = new Cookie("newOpenId", openId);
        cookie.setMaxAge(60 * 60 * 24 * 3);
        cookie.setPath("/");
        response.addCookie(cookie);
        try {
            response.sendRedirect("/static/index.html?ngoCode=GV0000076919");
        } catch (IOException e) {
            throw new RuntimeException("Confront problem at getOpenIdStepTwo");
        }
    }
}