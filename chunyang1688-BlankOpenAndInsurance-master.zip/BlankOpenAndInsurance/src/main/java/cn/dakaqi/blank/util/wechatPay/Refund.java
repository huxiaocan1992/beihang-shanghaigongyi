package cn.dakaqi.blank.util.wechatPay;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * @author jinyifeng5969@163.com
 *         <p>
 *         Wechat pay refund request parameter
 */

@Data
@XmlRootElement(name = "xml")
@XmlAccessorType(XmlAccessType.FIELD)
public class Refund {

    @XmlElement
    private String appid;

    @XmlElement
    private String mch_id;

    @XmlElement
    private String device_info;

    @XmlElement
    private String nonce_str;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String sign;

    @XmlElement
    private String transaction_id;

    @XmlElement
    private String out_trade_no;

    @XmlElement
    private String out_refund_no;

    @XmlElement
    private String total_fee;

    @XmlElement
    private String refund_fee;

    @XmlElement
    private String refund_fee_type;

    @XmlElement
    private String op_user_id;

}