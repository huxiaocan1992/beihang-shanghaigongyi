package cn.dakaqi.blank.service.qnzyz;

import org.springframework.stereotype.Component;

/**
 * Authoer:chunyang
 * ProjectName:Volunteer
 * Date: 2015/7/14.
 * Description:
 */
@Component
public class BHConstant
{

    public String BasePath = "";
    public int TOKEN_TIMEOUT =	1003;//token已超时

    //public static  String CLIENTID =  "100189";
    //public static  String PUBLICKEY =  "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjgZktm9br7rozXnvyzfucAqDcbfK/q8LEelokAzcFXgITAhIvaWXVHiLLPW2WDO1tW8+cFJs4f/BC6lPojTRy4TCbVZEzKEObUiPz6SoRKXrkG7ZiDu4RTGZfJOY3KYluNYxXOINUrwUoZItHNgWXVDOgXo8hPAQaXlOOMv/WUQIDAQAB";

//    public static  String CLIENTID = "100009";
//    public static  String PUBLICKEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0FhAal1diWCkErdynsiCaw9yKuNTs7OQwoP4rYivCNXe2bgATYRrSXNih3V+UzCdIcKZr/YI2zXOdNHwxJmORmqd+vDcDm7PeFlqWHX4tiMAEiHfvJ6r3rXW2oYhNeajvX/TqPmGF/sKsIrmFitbQfzMVjQ8RiCwDIkqRed6seQIDAQAB";
//
//    public static String CLIENTID = "1003";
//    public static String PUBLICKEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCDD9BJZt2vKcpv8VLYzBY3GNvcHKPI721gfOax41TUu1WTmEZoYuYMkhLypeWeQLQktXsdCbEb9drugnMelwYTpJd4X8Dzu1g5Cr9cri5PTgrqX7RgyghKlbOmdCrKeOUV/qTp9QfOdJ1v2tY79Im0bkMR/rir0zmD7mcBwRHW8wIDAQAB";


    public static String CLIENTID = "100198";
    public static String PUBLICKEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDPCtZE6OH3s9xlPCeYCbLGsbDo1dU7fgkRCRJcGcWWckjKPEHt4yoO/Z00ixyArp78VBouLWFouZntrZ+MjxAXujPoOSKB7MIas7pfMVRdBRZD3FgmDnv+2Xn+zfM6FF/DxCJh6dvfjRbUPffxjDFSD9DgjuaNhM9CnQUYuRTBwwIDAQAB";



    public String checkNetWork()
    {
//        ResourceBundle bundle = ResourceBundle.getBundle("config");
//        String WebRoot = bundle.getString("app.root.path");
//        if(WebRoot.contains("https"))
//            BasePath = "https://open.qnzyz.org.cn";
//        else if(WebRoot.contains("test.dakaqi.cn") || WebRoot.contains("localhost") || WebRoot.contains("192.168.2") || WebRoot.contains("127.0.0.1"))
//            BasePath = "http://192.168.2.16:81";
//        else
//            BasePath = "https://open.qnzyz.org.cn";
        BasePath = "https://open.qnzyz.org.cn";
        return BasePath;
    }
}
