package cn.dakaqi.blank.service.qnzyz;

import java.io.Serializable;

/**
 * Created by chunyang on 2015/9/17.
 */
public class BHUser implements Serializable
{

    /**
     * birthday : null
     * englishName : null
     * userPassword : c4ca4238a0b923820dcc509a6f75849b
     * userStatus : 0
     * faceBookNo : null
     * userMobile : avevfF0DTXo6y3t0WmgSriZdhXjAJmvPIPqYadKMN5t0YpV8gTzfSaKMKpooFMCgeleP569ii/cdBPGTW0srY3CfQzOLSi4Uf/X/0oQ7P6jGmUw/cO+GTJ/M3M7Ndh/SsEoi0LRBow+8ZEQ+G9WgEP0cQlvGjG2H3Z0tRECHXCg=
     * userEmail : null
     * userEduLevel : 09
     * weiboNo : null
     * regAddress : null
     * nativeplaceProvince : 上海
     * wechatNo : null
     * userNation : 01
     * nativeplaceCity : 黄浦区
     * userBloodType : null
     * userHeadPath : null
     * telephone : 55555555
     * userName : 刘栋
     * userId : 421
     * schoolNo : null
     * livingProvince : null
     * userMarital : 0
     * regDistrict :
     * volunteerTag : 1
     * livingCity : null
     * qqNo : null
     * regCity : 长宁区
     * userCertNo : bKANDyoI9jG5DjI+m5K3nzKrgBMrnO5lzcTPe9k6uzMLB2xkIkifgIrFUeg5YQe0dRI2uAdi3W9jBMX8cVJaM6yxVdYkISis478RuGx41KRLGoFeVot6mA2WpQUnLSOGRKj3JNg7hCeW6HEm4GsTuLXh7+BdvIKf2OVefKM389Q=
     * livingAddress : null
     * userPolitical : 4
     * userGender : 1
     * srcSys : null
     * userType : 1
     * regProvince : 上海
     * livingDistrict : null
     */
    private String birthday;
    private String englishName;
    private String userPassword;
    private int userStatus;
    private String faceBookNo;
    private String userMobile;
    private String userEmail;
    private String userEduLevel;
    private String weiboNo;
    private String regAddress;
    private String nativeplaceProvince;
    private String wechatNo;
    private String userNation;
    private String nativeplaceCity;
    private String userBloodType;
    private String userHeadPath;
    private String telephone;
    private String userName;
    private int userId;
    private String schoolNo;
    private String livingProvince;
    private int userMarital;
    private String regDistrict;
    private String volunteerTag;
    private String livingCity;
    private String qqNo;
    private String regCity;
    private String userCertNo;
    private String userCertType;
    private String livingAddress;
    private int userPolitical;
    private int userGender;
    private String srcSys;
    private int userType;
    private String regProvince;
    private String livingDistrict;

    @Override
    public String toString()
    {
        return "BHUser{" +
                "birthday='" + birthday + '\'' +
                ", englishName='" + englishName + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", userStatus='" + userStatus + '\'' +
                ", faceBookNo='" + faceBookNo + '\'' +
                ", userMobile='" + userMobile + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", userEduLevel='" + userEduLevel + '\'' +
                ", weiboNo='" + weiboNo + '\'' +
                ", regAddress='" + regAddress + '\'' +
                ", nativeplaceProvince='" + nativeplaceProvince + '\'' +
                ", wechatNo='" + wechatNo + '\'' +
                ", userNation='" + userNation + '\'' +
                ", nativeplaceCity='" + nativeplaceCity + '\'' +
                ", userBloodType='" + userBloodType + '\'' +
                ", userHeadPath='" + userHeadPath + '\'' +
                ", telephone='" + telephone + '\'' +
                ", userName='" + userName + '\'' +
                ", userId='" + userId + '\'' +
                ", schoolNo='" + schoolNo + '\'' +
                ", livingProvince='" + livingProvince + '\'' +
                ", userMarital='" + userMarital + '\'' +
                ", regDistrict='" + regDistrict + '\'' +
                ", volunteerTag='" + volunteerTag + '\'' +
                ", livingCity='" + livingCity + '\'' +
                ", qqNo='" + qqNo + '\'' +
                ", regCity='" + regCity + '\'' +
                ", userCertNo='" + userCertNo + '\'' +
                ", livingAddress='" + livingAddress + '\'' +
                ", userPolitical='" + userPolitical + '\'' +
                ", userGender='" + userGender + '\'' +
                ", srcSys='" + srcSys + '\'' +
                ", userType='" + userType + '\'' +
                ", regProvince='" + regProvince + '\'' +
                ", livingDistrict='" + livingDistrict + '\'' +
                '}';
    }

    public void setBirthday(String birthday)
    {
        this.birthday = birthday;
    }

    public void setEnglishName(String englishName)
    {
        this.englishName = englishName;
    }

    public void setUserPassword(String userPassword)
    {
        this.userPassword = userPassword;
    }

    public void setUserStatus(int userStatus)
    {
        this.userStatus = userStatus;
    }

    public void setFaceBookNo(String faceBookNo)
    {
        this.faceBookNo = faceBookNo;
    }

    public void setUserMobile(String userMobile)
    {
        this.userMobile = userMobile;
    }

    public void setUserEmail(String userEmail)
    {
        this.userEmail = userEmail;
    }

    public void setUserEduLevel(String userEduLevel)
    {
        this.userEduLevel = userEduLevel;
    }

    public void setWeiboNo(String weiboNo)
    {
        this.weiboNo = weiboNo;
    }

    public void setRegAddress(String regAddress)
    {
        this.regAddress = regAddress;
    }

    public void setNativeplaceProvince(String nativeplaceProvince)
    {
        this.nativeplaceProvince = nativeplaceProvince;
    }

    public void setWechatNo(String wechatNo)
    {
        this.wechatNo = wechatNo;
    }

    public void setUserNation(String userNation)
    {
        this.userNation = userNation;
    }

    public void setNativeplaceCity(String nativeplaceCity)
    {
        this.nativeplaceCity = nativeplaceCity;
    }

    public void setUserBloodType(String userBloodType)
    {
        this.userBloodType = userBloodType;
    }

    public void setUserHeadPath(String userHeadPath)
    {
        this.userHeadPath = userHeadPath;
    }

    public void setTelephone(String telephone)
    {
        this.telephone = telephone;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public void setUserId(int userId)
    {
        this.userId = userId;
    }

    public void setSchoolNo(String schoolNo)
    {
        this.schoolNo = schoolNo;
    }

    public void setLivingProvince(String livingProvince)
    {
        this.livingProvince = livingProvince;
    }

    public void setUserMarital(int userMarital)
    {
        this.userMarital = userMarital;
    }

    public void setRegDistrict(String regDistrict)
    {
        this.regDistrict = regDistrict;
    }

    public void setVolunteerTag(String volunteerTag)
    {
        this.volunteerTag = volunteerTag;
    }

    public void setLivingCity(String livingCity)
    {
        this.livingCity = livingCity;
    }

    public void setQqNo(String qqNo)
    {
        this.qqNo = qqNo;
    }

    public void setRegCity(String regCity)
    {
        this.regCity = regCity;
    }

    public void setUserCertNo(String userCertNo)
    {
        this.userCertNo = userCertNo;
    }

    public void setLivingAddress(String livingAddress)
    {
        this.livingAddress = livingAddress;
    }

    public void setUserPolitical(int userPolitical)
    {
        this.userPolitical = userPolitical;
    }

    public void setUserGender(int userGender)
    {
        this.userGender = userGender;
    }

    public void setSrcSys(String srcSys)
    {
        this.srcSys = srcSys;
    }

    public void setUserType(int userType)
    {
        this.userType = userType;
    }

    public void setRegProvince(String regProvince)
    {
        this.regProvince = regProvince;
    }

    public void setLivingDistrict(String livingDistrict)
    {
        this.livingDistrict = livingDistrict;
    }

    public String getBirthday()
    {
        return birthday;
    }

    public String getEnglishName()
    {
        return englishName;
    }

    public String getUserPassword()
    {
        return userPassword;
    }

    public int getUserStatus()
    {
        return userStatus;
    }

    public String getFaceBookNo()
    {
        return faceBookNo;
    }

    public String getUserMobile()
    {
        return userMobile;
    }

    public String getUserEmail()
    {
        return userEmail;
    }

    public String getUserEduLevel()
    {
        return userEduLevel;
    }

    public String getWeiboNo()
    {
        return weiboNo;
    }

    public String getRegAddress()
    {
        return regAddress;
    }

    public String getNativeplaceProvince()
    {
        return nativeplaceProvince;
    }

    public String getWechatNo()
    {
        return wechatNo;
    }

    public String getUserNation()
    {
        return userNation;
    }

    public String getNativeplaceCity()
    {
        return nativeplaceCity;
    }

    public String getUserBloodType()
    {
        return userBloodType;
    }

    public String getUserHeadPath()
    {
        return userHeadPath;
    }

    public String getTelephone()
    {
        return telephone;
    }

    public String getUserName()
    {
        return userName;
    }

    public int getUserId()
    {
        return userId;
    }

    public String getSchoolNo()
    {
        return schoolNo;
    }

    public String getLivingProvince()
    {
        return livingProvince;
    }

    public int getUserMarital()
    {
        return userMarital;
    }

    public String getRegDistrict()
    {
        return regDistrict;
    }

    public String getVolunteerTag()
    {
        return volunteerTag;
    }

    public String getLivingCity()
    {
        return livingCity;
    }

    public String getQqNo()
    {
        return qqNo;
    }

    public String getRegCity()
    {
        return regCity;
    }

    public String getUserCertNo()
    {
        return userCertNo;
    }

    public String getLivingAddress()
    {
        return livingAddress;
    }

    public int getUserPolitical()
    {
        return userPolitical;
    }

    public int getUserGender()
    {
        return userGender;
    }

    public String getSrcSys()
    {
        return srcSys;
    }

    public int getUserType()
    {
        return userType;
    }

    public String getRegProvince()
    {
        return regProvince;
    }

    public String getLivingDistrict()
    {
        return livingDistrict;
    }

    public String getUserCertType()
    {
        return userCertType;
    }

    public void setUserCertType(String userCertType)
    {
        this.userCertType = userCertType;
    }
}
