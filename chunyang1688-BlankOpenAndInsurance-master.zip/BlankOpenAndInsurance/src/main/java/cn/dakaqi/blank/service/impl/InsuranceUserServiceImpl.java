package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.entity.InsuranceUser;
import cn.dakaqi.blank.mapper.InsuranceUserMapper;
import cn.dakaqi.blank.service.InsuranceUserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-14
 */
@Service
public class InsuranceUserServiceImpl extends ServiceImpl<InsuranceUserMapper, InsuranceUser> implements InsuranceUserService {

}
