package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.InsuranceUser;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-14
 */
public interface InsuranceUserService extends IService<InsuranceUser>
{
	
}
