package cn.dakaqi.blank.enumerate;

/**
 * @author beliveli on 2016/5/12
 */
@SuppressWarnings("unused")
public enum StatusCode {

    OK(0, "请求成功"),

    SERVER_EXCEPTION(1, "服务器通用异常"),

    COMMON_UPLOAD_FILE(2,"文件上传异常"),
    COMMON_CALL_LIMITED(3,"调用次数超限"),
    COMMON_HTTP_ACTION(4,"http请求异常"),
    COMMON_INSUFFICIENT_PERMISSIONS(5,"权限不足"),
    COMMON_INVALID_FORMAT(6,"无效数据格式"),
    COMMON_MISS_SIGN(7,"缺少签名参数"),
    COMMON_INVALID_SIGN(8,"错误的签名参数"),
    COMMON_MISS_CUSTOMER(9,"缺少合作伙伴代码"),
    COMMON_INVALID_CUSTOMER(10,"错误的合作伙伴代码"),
    COMMON_MISS_TIMESTAMP(11,"缺少时间戳参数"),
    COMMON_INVALID_TIMESTAMP(12,"错误的时间戳参数"),
    COMMON_MISS_VERSION(13,"缺少版本参数"),
    COMMON_INVALID_VERSION(14,"错误的版本参数"),
    COMMON_PARAM_ERROR(15,"参数错误"),
    COMMON_INVALID_TOKEN(16,"无效的TOKEN"),
    COMMON_USER_NOT_LOGIN(17,"用户未登录"),
    COMMON_VERIFIER_CODE_ERROR(18,"手机验证码不正确"),
    COMMON_FORMAT_ERROR(19,"格式转换失败"),
    COMMON_SMS_SEND_ERROR(20,"短信发送失败"),
    COMMON_AREA_ERROR(21,"区域获取异常"),
    COMMON_REDIS_ERROR(22,"REDIS服务异常"),
    COMMON_MOBILE_ERROR(23,"手机号位数不正确"),
    COMMON_MOBILE_EXITS(24,"手机号已经存在"),

    USER_NOT_EXISTS(10001,"用户不存在"),
    USER_EXISTS(10002,"用户已存在"),
    USER_INFO_NOT_FULL(10003,"请完善个人资料"),
    USER_IS_FROST(10004,"用户已被冻结"),
    USER_SAVE_ERROR(10005,"用户创建失败"),
    USER_IDCARD_EXISTS(10006,"身份证信息已存在"),
    USER_PASSWORD_ERROR(10007,"账号密码错误"),

    VOLUNTEER_NOT_EXISTS(12001,"志愿者不存在"),
    VOLUNTEER_GROUP_REL_NOT_EXISTS(12002,"志愿者未加入该志愿者团体"),
    VOLUNTEER_IS_FROST(12003,"志愿者已被冻结"),
    VOLUNTEER_IS_CHECKING(12004,"志愿者实名认证目前处于待审核状态"),
    VOLUNTEER_VERIFIED_SUCCESS(12005,"志愿者实名认证已认证通过"),
    VOLUNTEER_VERIFIED_FAIL(12006,"志愿者实名认证认证失败"),
    VOLUNTEER_CODE_CREATE_FAIL(12007,"志愿者一号通获取失败"),

    ORGANIZATION_NOT_EXISTS(14001,"组织不存在"),
    ORGANIZATION_LOCKED(14002, "组织被冻结！"),
    ORGANIZATION_NO_MANAGE(14003,"没有可管理的组织"),
    ORGANIZATION_NAME_EXISTS(14004,"组织名称已存在"),
    ORGANIZATION_PLATFORM_EXISTS(14005,"当前社团已经挂靠到所选平台"),

    GROUP_NOT_EXISTS(16001,"社团不存在"),
    GROUP_JOIN_ERROR(16002,"社团加入失败"),
    GROUP_APPLY_PENDING(16003,"社团加入申请正在审核中"),
    GROUP_WECHART_NOT_EXISTS(16004,"社团微信信息不存在"),
    GROUPVOLUNTEER_NOT_EXISTS(16005,"志愿者尚未加入该社团"),
    GROUPVOLUNTEER_IS_ADMIN(16006,"志愿者已经是该社团的管理员"),
    GROUPVOLUNTEER_IS_NOT_ADMIN(16007,"志愿者已经不是该社团的管理员"),
    GROUPVOLUNTEER_NO_ACCESS(16008,"权限不足，您当前不是社团管理员"),
    GROUPVOLUNTEER_CREATER_ADMIN(16009,"社团的创建者不能被撤除管理员身份"),
    GROUP_WECHART_EXISTS(16010,"社团微信信息已经存在"),



    ACTIVITY_NOT_EXISTS(18001,"活动不存在"),
    ACTIVITY_NOT_OUTSIDE_RECRUIT(18002,"本活动暂未对外招募"),
    ACTIVITY_IS_CLOSE(18003,"活动已被封存"),
    ACTIVITY_NOT_START(18004,"活动尚未开始"),
    ACTIVITY_IS_END(18005,"活动已结束"),
    ACTIVITY_PEOPLE_IS_FULL(18006,"名额已满"),
    ACTIVITY_TIME_ERROR(18007,"当前活动时间和已报名的活动时间上有重叠"),
    ACTIVITY_NOT_APPLY(18008,"没有报名此次活动"),
    ACTIVITY_EXIT_ERROR(18009,"活动退出失败"),
    ACTIVITY_ADMIN_CANT_EXIT(18010,"负责人不可以退出活动"),
    ACTIVITY_CANT_UPDATE(18011,"不可以修改本活动"),
    ACTIVITY_INVALID(18012,"当前活动无效"),
    ACTIVITY_ONLY_ADMIN_CAN_CANCEL(18013,"只有管理员才可以取消活动"),
    ACTIVITY_APPLIED(18014,"已报名过本次活动"),
    ACTIVITY_WAIT_ADMIN_CHECK(18015,"请耐心等待管理员审核"),
    ACTIVITY_STARTED(18016,"活动已经开始"),

    SIGN_NOT_EXISTS(20001,"签到信息不存在"),
    SIGN_NOT_NEARBY(20002,"未到活动现场,不可以打卡"),
    SIGN_NO_TIME_TO(20003,"还未到签到时间"),

    INSURANCE_NOT_EXISTS(22001,"保险不存在"),

    WELFARE_NOT_EXISTS(24001,"福利不存在"),
    WELFARE_IS_FULL(24002,"福利已领完"),
    WELFARE_PER_PERSON(24003,"福利每人只能领取X次"),


    CHANNEL_EXISTS(30001,"该渠道已经存在，不可重复添加！"),

    ;

    private int code;
    private String message;

    StatusCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
