package cn.dakaqi.blank.controller.response;

/**
 * @author belvieli on 15/9/7.
 */
@SuppressWarnings("unused")
public class BaseResponseVo {

    private Integer code;

    private String message;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public BaseResponseVo() {
    }

    public BaseResponseVo(Integer code, String message) {
        this.setCode(code);
        this.setMessage(message);
    }
}