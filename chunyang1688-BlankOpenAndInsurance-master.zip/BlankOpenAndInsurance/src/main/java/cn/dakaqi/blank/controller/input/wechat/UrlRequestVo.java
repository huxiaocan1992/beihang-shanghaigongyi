package cn.dakaqi.blank.controller.input.wechat;

import lombok.Data;
import lombok.ToString;

/**
 * @author beliveli on 2016/8/12/0012
 */
@SuppressWarnings("unused")
@Data
@ToString
public class UrlRequestVo {
    private String url; //URL
}
