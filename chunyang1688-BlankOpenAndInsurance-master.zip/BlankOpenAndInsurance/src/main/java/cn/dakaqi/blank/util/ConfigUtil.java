package cn.dakaqi.blank.util;

import lombok.Data;

import java.util.Objects;
import java.util.ResourceBundle;

/**
 * @author beliveli
 *         Get information from config file
 */
@Data
public class ConfigUtil {

    public static boolean flag = false;
    public static final String CLIENT_ID = "1003";
    public static final Integer BATCH_INSERT_MAX = 1000;

    private static String wxAppId = "0";
    private static String mchId = "0";
    private static String wxSecret = "0";
    private static String baseUrl = ""; //微信基础URL https://api.weixin.qq.com
    private static String rootUrl;//项目根目录
    private static String pubKey;//端公钥
    private static String appRoot;//网站地址
    private static String apiKey;//加密秘钥
    private static String mchUri;

    public static void buildConfig() {
        if (!ConfigUtil.flag) {
            ResourceBundle bundle = ResourceBundle.getBundle("config");

            ConfigUtil.setAppRoot(bundle.getString("app.root.path"));
            ConfigUtil.setBaseUrl(bundle.getString("app.wechat.baseUri"));
            ConfigUtil.setMchId(bundle.getString("app.wechat.mch.id"));
            ConfigUtil.setPubKey(bundle.getString("prod.clientId.pubKey"));
            ConfigUtil.setRootUrl(bundle.getString("app.wx.url"));
            ConfigUtil.setWxAppId(bundle.getString("app.wechat.appId"));
            ConfigUtil.setWxSecret(bundle.getString("app.wechat.secret"));
            ConfigUtil.setApiKey(bundle.getString("app.api.key"));
            ConfigUtil.setMchUri(bundle.getString("app.wechat.mch.uri"));
            ConfigUtil.flag = true;
        }
    }

    public static String getWxAppId() {
        ConfigUtil.buildConfig();
        return wxAppId;
    }

    public static void setWxAppId(String wxAppId) {
        ConfigUtil.wxAppId = wxAppId;
    }

    public static String getMchId() {
        ConfigUtil.buildConfig();
        return mchId;
    }

    public static void setMchId(String mchId) {
        ConfigUtil.mchId = mchId;
    }

    public static String getWxSecret() {
        ConfigUtil.buildConfig();
        return wxSecret;
    }

    public static void setWxSecret(String wxSecret) {

        ConfigUtil.wxSecret = wxSecret;
    }

    public static String getBaseUrl() {
        ConfigUtil.buildConfig();
        return baseUrl;
    }

    public static void setBaseUrl(String baseUrl) {
        ConfigUtil.baseUrl = baseUrl;
    }

    public static String getRootUrl() {
        ConfigUtil.buildConfig();
        return rootUrl;
    }

    public static void setRootUrl(String rootUrl) {
        ConfigUtil.rootUrl = rootUrl;
    }

    public static String getPubKey() {
        ConfigUtil.buildConfig();
        return pubKey;
    }

    public static void setPubKey(String pubKey) {
        ConfigUtil.pubKey = pubKey;
    }

    public static String getAppRoot() {
        ConfigUtil.buildConfig();
        return appRoot;
    }

    public static void setAppRoot(String appRoot) {
        ConfigUtil.appRoot = appRoot;
    }

    public static String getApiKey() {
        ConfigUtil.buildConfig();
        return apiKey;
    }

    public static void setApiKey(String apiKey) {
        ConfigUtil.apiKey = apiKey;
    }

    public static String getMchUri() {
        return mchUri;
    }

    public static void setMchUri(String mchUri) {
        ConfigUtil.mchUri = mchUri;
    }
}
