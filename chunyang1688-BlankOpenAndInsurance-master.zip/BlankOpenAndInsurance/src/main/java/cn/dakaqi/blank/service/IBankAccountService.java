package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.BankAccount;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-02
 */
public interface IBankAccountService extends IService<BankAccount>
{
    BankAccount selectByIdNo(String idNo);
    BankAccount selectByBankAct(String bankAct);
}
