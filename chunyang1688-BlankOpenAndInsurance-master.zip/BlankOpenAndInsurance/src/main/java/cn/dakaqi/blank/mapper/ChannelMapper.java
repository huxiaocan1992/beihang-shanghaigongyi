package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.vo.ChannelRequestVo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
@Repository(value = "channelMapper")
public interface ChannelMapper extends BaseMapper<Channel> {

    List<Channel> queryPage(ChannelRequestVo vo);
    int queryPageCount(ChannelRequestVo vo);

    List<Channel> selectByBusiness(String business);

    List<Channel> selectByCodeDesc();

    Channel selectByMobile(String mobile);
}