package cn.dakaqi.blank.enumerate;

/**
 * @author jayli
 */
public enum SpecialUrl {

    INDEX_PAGE(SpecialUrlType.INDEX_PAGE.getType(), "/index/indexpage", "/index/indexCb", "/static/pay.html"),
    PAY_URL(SpecialUrlType.PAY_URL.getType(), "/index/indexpage", "/index/indexCb", "/static/index.html"),
    INSURANCE_BINDING(SpecialUrlType.INSURANCE_BINDING.getType(), "/index/indexpage", "/index/indexCb", "/static/hyk/bxlp.html");


    private String type; // idendified by param "type" set in request url

    private String requestUrl;

    private String callbackUrl;

    private String redirectUrl;

    SpecialUrl(String type, String requestUrl, String callbackUrl, String redirectUrl) {
        this.type = type;
        this.requestUrl = requestUrl;
        this.callbackUrl = callbackUrl;
        this.redirectUrl = redirectUrl;
    }

    public static boolean isSpecialUrl(String url) {
        for (SpecialUrl spUrl : SpecialUrl.values()) {
            if (url.contains(spUrl.getRequestUrl()) || url.contains(spUrl.getCallbackUrl())) {
                return true;
            }
        }
        return false;
    }

    public static boolean isValidRequestUrl(String url) {
        for (SpecialUrl spUrl : SpecialUrl.values()) {
            if (url.contains(spUrl.getRequestUrl())) {
                return true;
            }
        }
        return false;
    }

    public static boolean isValidCallbackUrl(String url) {
        for (SpecialUrl spUrl : SpecialUrl.values()) {
            if (url.contains(spUrl.getCallbackUrl())) {
                return true;
            }
        }
        return false;
    }

    public static SpecialUrl getByRequestUrl(String requestUrl) {
        for (SpecialUrl spUrl : SpecialUrl.values()) {
            if (requestUrl.contains(spUrl.getRequestUrl())) {
                return spUrl;
            }
        }
        return null;
    }

    public static SpecialUrl getByType(String type) {
        for (SpecialUrl spUrl : SpecialUrl.values()) {
            if (type.equals(spUrl.getType())) {
                return spUrl;
            }
        }
        return null;
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
