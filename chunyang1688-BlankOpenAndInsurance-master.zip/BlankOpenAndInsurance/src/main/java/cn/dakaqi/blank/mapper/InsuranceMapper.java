package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.Insurance;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
@Repository(value = "insuranceMapper")
public interface InsuranceMapper extends BaseMapper<Insurance> {

}