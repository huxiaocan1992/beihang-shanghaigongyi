package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-15
 */
@Data
@ToString
@TableName("orderInfo")
public class OrderInfo implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 订单唯一标识
	 */
	private String uuid;

	/**
	 * 订单编码
	 */
	private String orderCode;

	/**
	 * 订单状态
	 */
	private Integer orderStatus;

	/**
	 * 渠道
	 */
	private String orderChannel;

	/**
	 * 业务
	 */
	private String orderBusiness;

	/**
	 * 受益对象 受益者
	 */
	private String beneficiary;

	/**
	 * 
	 */
	private String sourceOrderCode;

	/**
	 * 
	 */
	private String sourcePayUser;

	/**
	 * 订单创建时间
	 */
	private Date orderTime;

	/**
	 * 订单金额
	 */
	private BigDecimal total;

	/**
	 * 支付状态
	 */
	private Integer payState;

	/**
	 * 支付时间
	 */
	private Date payTime;

	/**
	 * 支付方式
	 */
	private Integer payPattern;

	/**
	 * 支付渠道
	 */
	private String payChannel;

	/**
	 * 用户OpenId
	 */
	private String openId;

	/**
	 * 支付参数
	 */
	private String prepayId;

	/**
	 * 微信支付返回的交易ID
	 */
	private String transactionId;

	/**
	 * 银行类型
	 */
	private String bankType;

	/**
	 * 货币类型，符合ISO4217标准的三位字母代码，默认人民币：CNY
	 */
	private String feeType;

	/**
	 * 交易类型 JSAPI、NATIVE、APP
	 */
	private String tradeType;

	/**
	 * 微信支付分配的商户号
	 */
	private String mchId;

	/**
	 * 订单总金额，单位为分
	 */
	private String totalFee;

	/**
	 * 支付完成时间，格式为yyyyMMddHHmmss
	 */
	private String timeEnd;

	/**
	 * 退款原因
	 */
	private String refundReason;

	/**
	 * 退款状态
	 */
	private String refundStatus;

	/**
	 * 退款时间
	 */
	private String refundTime;

	/**
	 * 
	 */
	private Date createTime;

	/**
	 * 
	 */
	private Date updateTime;

}
