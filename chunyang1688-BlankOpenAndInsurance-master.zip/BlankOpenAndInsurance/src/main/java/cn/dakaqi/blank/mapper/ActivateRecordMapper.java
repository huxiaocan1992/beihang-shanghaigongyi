package cn.dakaqi.blank.mapper;

import cn.dakaqi.blank.entity.ActivateRecord;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * Mapper接口
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-20
 */
public interface ActivateRecordMapper extends BaseMapper<ActivateRecord> {

}