package cn.dakaqi.blank.entity.vo;

/**
 * Created by yangx
 * CreateTime: 2016/12/9 21:32
 */
public class TradeListVo {

    private Integer pageSize = 10;
    private Integer pageNo = 1;
    private String channel;

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
