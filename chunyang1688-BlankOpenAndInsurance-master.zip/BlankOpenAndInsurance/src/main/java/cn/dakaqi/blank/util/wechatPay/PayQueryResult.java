package cn.dakaqi.blank.util.wechatPay;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * @author beliveli
 *         <p>
 *         pay order result from wechat payment
 */
@Data
@XmlRootElement(name = "xml")
@XmlAccessorType(XmlAccessType.FIELD)
public class PayQueryResult extends MchBaseResult {

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String transaction_id;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String out_trade_no;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String trade_type;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String trade_state;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String bank_type;

    private int total_fee;

    private int cash_fee;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String time_end;

    @XmlElement
    @XmlJavaTypeAdapter(value = AdaptorCDATA.class)
    private String openid;

}
