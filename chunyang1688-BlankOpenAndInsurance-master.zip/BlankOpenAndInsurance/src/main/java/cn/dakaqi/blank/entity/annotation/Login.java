package cn.dakaqi.blank.entity.annotation;

import java.lang.annotation.*;

/**
 * @author beliveli
 *         <p>
 *         For all methods that need login, simply add this annotation
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Login {
}