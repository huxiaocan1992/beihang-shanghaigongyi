/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.controller.input;

import cn.dakaqi.blank.entity.TradeList;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 类名称：TradListVO <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/12 21:54
 * @version: 1.0.0
 */
@Data
@ToString
@Slf4j
public class TradListVO implements Serializable
{
    private static final long serialVersionUID = -9095741754540339691L;
    /**
     * 商户编号
     */
    private String channel;

    /**
     *业务编号
     */
    private String business;

    /**
     *订单号
     */
    private String orderCode;

    /**
     *
     */
    private Date finishDate;

    /**
     *手机
     */
    private String phone;

    /**
     *姓名
     */
    private String name;

    /**
     *微信OPENID
     */
    private String openId;

    /**
     *护照编号
     */
    private String passportCode;

    /**
     *证件号
     */
    private String cardNo;

    /**
     *证件类型
     */
    private String cardType;

    /**
     *交易金额
     */
    private BigDecimal money;

    /**
     *平安老账户
     */
    private String pingAnOld;

    /**
     *平安新账户
     */
    private String pingAnNew;


    public static TradeList buildTradList(TradListVO vo)
    {
        TradeList tradList = new TradeList();
        tradList.setChannel(vo.getChannel());
        tradList.setBusiness(vo.getBusiness());
        tradList.setPingAnNew(vo.getPingAnNew());
        tradList.setPingAnOld(vo.getPingAnOld());
        tradList.setPhone(vo.getPhone());
        tradList.setMoney(vo.getMoney());
        tradList.setCardNo(vo.getCardNo());
        tradList.setCardType(vo.getCardType());
        tradList.setName(vo.getName());
        tradList.setOpenId(vo.getOpenId());
        tradList.setOrderCode(vo.getOrderCode());
        tradList.setPassportCode(vo.getPassportCode());
        tradList.setFinishDate(vo.getFinishDate());
        return tradList;
    }

}
 
 