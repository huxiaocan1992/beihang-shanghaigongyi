package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-09
 */
@TableName("tradeList")
@ToString
public class TradeList implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 渠道id
	 */
	private String channel;

	/**
	 * 业务
	 */
	private String business;

	/**
	 * 订单code
	 */
	private String orderCode;

	/**
	 * 完成日期
	 */
	private Date finishDate;

	/**
	 * 手机
	 */
	private String phone;

	/**
	 * 名称
	 */
	private String name;

	/**
	 * 
	 */
	private String openId;

	/**
	 * 护照-一号通
	 */
	private String passportCode;

	/**
	 * 身份证
	 */
	private String cardNo;

	/**
	 * 身份证类型
	 */
	private String cardType;

	/**
	 * 钱
	 */
	private BigDecimal money;

	/**
	 * 平安old
	 */
	private String pingAnOld;

	/**
	 * 平安新
	 */
	private String pingAnNew;

	/**
	 * 创建时间
	 */
	private Date createTime;



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public Date getFinishDate() {
		return finishDate;
	}

	public void setFinishDate(Date finishDate) {
		this.finishDate = finishDate;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getPassportCode() {
		return passportCode;
	}

	public void setPassportCode(String passportCode) {
		this.passportCode = passportCode;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getPingAnOld() {
		return pingAnOld;
	}

	public void setPingAnOld(String pingAnOld) {
		this.pingAnOld = pingAnOld;
	}

	public String getPingAnNew() {
		return pingAnNew;
	}

	public void setPingAnNew(String pingAnNew) {
		this.pingAnNew = pingAnNew;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
