package cn.dakaqi.blank.controller.admin;

import cn.dakaqi.blank.controller.response.DataResponseVo;
import cn.dakaqi.blank.entity.AdminUser;
import cn.dakaqi.blank.entity.Channel;
import cn.dakaqi.blank.entity.ChannelExplain;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.entity.vo.ChPasswordVo;
import cn.dakaqi.blank.entity.vo.ChannelRequestVo;
import cn.dakaqi.blank.entity.vo.ChannelResponseVo;
import cn.dakaqi.blank.entity.vo.TradeListVo;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.service.IAdminUserService;
import cn.dakaqi.blank.service.IChannelExplainService;
import cn.dakaqi.blank.service.IChannelService;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.util.Constant;
import cn.dakaqi.blank.util.Identities;
import cn.dakaqi.blank.util.MD5Util;
import cn.dakaqi.blank.util.PageData;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by yangx
 * CreateTime: 2016/12/7 15:50
 */

@Controller
@RequestMapping("/channelAdmin")
@Api(value = "平台管理", description = "平台管理", hidden = false)
@Slf4j
public class ChannelAdminController {

    @Autowired
    private IChannelService channelService;
    @Autowired
    private IAdminUserService adminUserService;
    @Autowired
    private IChannelExplainService channelExplainService;
    @Autowired
    private ITradeListService tradeListService;


    /**
     * 新增，
     * 状态删除、未批准
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public DataResponseVo<Object> create(@RequestBody Channel channel) throws Exception {
        log.info(channel.toString());
        if (channel.getMobile() == null || channel.getMobile().length() < 6 || channel.getName() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel1 = channelService.selectByMobile(channel.getMobile());
        if (channel1 != null) {
            return new DataResponseVo<>(StatusCode.COMMON_MOBILE_EXITS.getCode(), StatusCode.COMMON_MOBILE_EXITS.getMessage());
        }
        channel.setCreateTime(new Date());
        channel.setDelStatus(Constant.DEL_STATUS_YES);
        channel.setApproval(Constant.APPROVAL_STATUS_NO);
        channel.setPassWord(MD5Util.MD5(channel.getMobile().substring(channel.getMobile().length() - 6)));
        Boolean i = channelService.insert(channel);
        if (i) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }

    /**
     * 管理员验证、审核通过
     * 管理员执行
     */
    @RequestMapping(value = "/approve", method = RequestMethod.POST)
    @ResponseBody
//    @Login
    public DataResponseVo<Object> approve(@RequestBody Channel param, HttpSession session) throws Exception {
//        AdminUser adminUser = (AdminUser) session.getAttribute("user");
//        //判断管理员权限
//        if (adminUser.getRole() != 10) {
//            return new DataResponseVo<>(StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getCode(), StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getMessage());
//        }
        if (param.getId() == null || param.getId() == 0) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channelPo = channelService.selectById(param.getId());
        //手机号不重复
        Channel channel2 = channelService.selectByMobile(param.getMobile());
        if (channel2 != null) {
            return new DataResponseVo<>(StatusCode.COMMON_MOBILE_EXITS.getCode(), StatusCode.COMMON_MOBILE_EXITS.getMessage());
        }
        //shopType验证
        if (param.getShopType() == null || (param.getShopType() != 10 && param.getShopType() != 20)) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), "团体/个人类型信息错误！");
        }
        //business验证
//        if (param.getBusiness() == null || (!param.getBusiness().equals("A") && !param.getBusiness().equals("B") &&
//                !param.getBusiness().equals("C") && !param.getBusiness().equals("D") && !param.getBusiness().equals("E")) && !param.getBusiness().equals("F")) {
//            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
//        }
        //渠道是否重复s
        ChannelRequestVo channel1 = new ChannelRequestVo();
        channel1.setName(channelPo.getName());
        channel1.setBusiness(param.getBusiness());
        PageData<Channel> pageData = channelService.queryPage(channel1);
        if (pageData.getList().size() > 0) {
            return new DataResponseVo<>(StatusCode.CHANNEL_EXISTS.getCode(), StatusCode.CHANNEL_EXISTS.getMessage());
        }
        channelPo.setBaseAddress(param.getBaseAddress());
        channelPo.setShopType(param.getShopType());
        channelPo.setBusiness(param.getBusiness());
        channelPo.setUpdateTime(new Date());
        channelPo.setRetUrl("#");
        channelPo.setDelStatus(Constant.DEL_STATUS_NO);
        channelPo.setFrozen(Constant.FROZEN_STATUS_NO);
        channelPo.setApproval(Constant.APPROVAL_STATUS_YES);
        //渠道code
        channelPo.setCode(Identities.randomBase62(5));
        channelPo.setHasInsurance(Constant.HAS_INSURANCE_NO);
        //渠道-业务code
        List<Channel> list = channelService.selectByBusiness(channelPo.getBusiness());
        if (list.size() > 0) {
            String lastBusiness = list.get(0).getBusinessCode();
            int num = Integer.valueOf(lastBusiness.substring(1));
            String result = String.format("%0" + 5 + "d", num + 1);
            channelPo.setBusinessCode(channelPo.getBusiness() + result);
        } else {
            channelPo.setBusinessCode(channelPo.getBusiness() + "00001");
        }

        //微信二维码
//            https://pab.cvssp.cn/pingan/activateInfo
//            <option value="A">保险业务</option>   buyInsurance
//            <option value="B">平安银行</option>   onlyPinganOpen
//            <option value="C">护照申请</option>   applyPassport
//            <option value="D">护照激活</option>   activatePassport
//            <option value="E">其他捐赠</option>   donate
//            <option value="F">基地护照申请激活</option>   applyAndActivatePassport

        String qrUrl = "";
        if (channelPo.getBusiness().equals("A")) {
            qrUrl = "/buyInsurance/" + channelPo.getCode() + "/" + channelPo.getBusinessCode();
        } else if (channelPo.getBusiness().equals("B")) {
            qrUrl = "/onlyPinganOpen/" + channelPo.getCode() + "/" + channelPo.getBusinessCode();
        } else if (channelPo.getBusiness().equals("C")) {
            qrUrl = "/applyPassport/" + channelPo.getCode() + "/" + channelPo.getBusinessCode();
        } else if (channelPo.getBusiness().equals("D")) {
            qrUrl = "/activatePassport/" + channelPo.getCode() + "/" + channelPo.getBusinessCode();
        } else if (channelPo.getBusiness().equals("E")) {
            qrUrl = "/donate/" + channelPo.getCode() + "/" + channelPo.getBusinessCode();
        } else if (channelPo.getBusiness().equals("F")) {
            qrUrl = "/applyAndActivatePassport/" + channelPo.getCode() + "/" + channelPo.getBusinessCode() + "/" + channelPo.getBaseAddress();
        }else if (channelPo.getBusiness().equals("G")) {
            qrUrl = "/applyActivate418Passport/" + channelPo.getCode() + "/" + channelPo.getBusinessCode() + "/" + channelPo.getBaseAddress();
        }

        channelPo.setORCode(Constant.getQRUrl() + qrUrl);

        Boolean i = channelService.updateById(channelPo);
        if (i) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }


    /**
     * 冻结、解冻
     */
    @RequestMapping(value = "/froze", method = RequestMethod.POST)
    @ResponseBody
//    @Login
    public Object froze(@RequestBody Channel param, HttpSession session) throws Exception {
//        AdminUser adminUser = (AdminUser) session.getAttribute("user");
//        //判断管理员权限
//        if (adminUser.getRole() != 10) {
//            return new DataResponseVo<>(StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getCode(), StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getMessage());
//        }
        if (param.getId() == null || param.getId() == 0 || (param.getFrozen() != 10 && param.getFrozen() != -10)) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel1 = channelService.selectById(param.getId());
        channel1.setFrozen(param.getFrozen());
        channel1.setUpdateTime(new Date());
        Boolean i = channelService.updateById(channel1);
        if (i) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }

    /**
     * 重置密码
     */
    @RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
    @ResponseBody
//    @Login
    public Object resetPassword(@RequestBody Channel param, HttpSession session) throws Exception {
//        AdminUser adminUser = (AdminUser) session.getAttribute("user");
//        //判断管理员权限
//        if (adminUser.getRole() != 10) {
//            return new DataResponseVo<>(StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getCode(), StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getMessage());
//        }
        if (param.getId() == null || param.getId() == 0) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel = channelService.selectById(param.getId());
        if (param.getPassWord() != null) {
            channel.setPassWord(MD5Util.MD5(param.getPassWord()));
        } else {
            if (channel.getMobile().length() < 6) {
                return new DataResponseVo<>(StatusCode.COMMON_MOBILE_ERROR.getCode(), StatusCode.COMMON_MOBILE_ERROR.getMessage());
            }
            channel.setPassWord(MD5Util.MD5(channel.getMobile().substring(channel.getMobile().length() - 6)));
        }
        Boolean i = channelService.updateById(channel);
        if (i) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }

    /**
     * 渠道列表
     */
    @RequestMapping(value = "/queryList", method = RequestMethod.POST)
    @ResponseBody
    public Object queryList(@RequestBody ChannelRequestVo vo, HttpSession session) throws Exception {
        PageData<Channel> pageData = channelService.queryPage(vo);
        PageData<ChannelResponseVo> pageData1 = new PageData<>();
        List<ChannelResponseVo> list1 = new ArrayList<>();
        if (pageData.getList().size() > 0) {
            for (Channel ch : pageData.getList()) {
                list1.add(ChannelResponseVo.build(ch));
            }
        }
        pageData1.setList(list1);
        pageData1.setTotal(pageData.getTotal());
        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), pageData1);
    }


    /**
     * 管理员登录
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public Object login(@RequestBody AdminUser param, HttpSession session) throws Exception {
        if (param.getMobile() == null || param.getPassWord() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        AdminUser adminUser = adminUserService.selectByMobile(param.getMobile());
        if (!adminUser.getPassWord().equalsIgnoreCase(MD5Util.MD5(param.getPassWord()))) {
            return new DataResponseVo<>(StatusCode.USER_PASSWORD_ERROR.getCode(), StatusCode.USER_PASSWORD_ERROR.getMessage());
        }
        session.setAttribute("user", adminUser);
        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
    }


    /**
     * 商户登录
     */
    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
    @ResponseBody
    public Object userLogin(@RequestBody Channel param, HttpSession session) throws Exception {
        if (param.getMobile() == null || param.getPassWord() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel = channelService.selectByMobile(param.getMobile());
        if (!channel.getPassWord().equalsIgnoreCase(MD5Util.MD5(param.getPassWord()))) {
            return new DataResponseVo<>(StatusCode.USER_PASSWORD_ERROR.getCode(), StatusCode.USER_PASSWORD_ERROR.getMessage());
        }
        if (channel.getCode() == null) {
            return new DataResponseVo<>(StatusCode.USER_PASSWORD_ERROR.getCode(), "您的渠道尚未审核，请联系管理员！");
        }
        if (channel.getFrozen() == null || channel.getFrozen() == Constant.FROZEN_STATUS_YES) {
            return new DataResponseVo<>(StatusCode.USER_PASSWORD_ERROR.getCode(), "权限被冻结，请联系管理员！");
        }
        session.setAttribute("channel", channel);
        if (MD5Util.MD5(param.getPassWord()).equalsIgnoreCase(MD5Util.MD5(channel.getMobile().substring(channel.getMobile().length() - 6)))) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), "defaultPassword", channel);
        }
        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), channel);
    }

    /**
     * 商户修改密码
     */
    @RequestMapping(value = "/updatePassword", method = RequestMethod.POST)
    @ResponseBody
    public Object updatePassword(@RequestBody ChPasswordVo param, HttpSession session) throws Exception {
        if (param.getMobile() == null || param.getPasswordOld() == null || param.getPasswordNew() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel = channelService.selectByMobile(param.getMobile());
        if (!channel.getPassWord().equalsIgnoreCase(MD5Util.MD5(param.getPasswordOld()))) {
            return new DataResponseVo<>(StatusCode.USER_PASSWORD_ERROR.getCode(), StatusCode.USER_PASSWORD_ERROR.getMessage());
        }
        if (MD5Util.MD5(param.getPasswordNew()).equalsIgnoreCase(MD5Util.MD5(channel.getMobile().substring(channel.getMobile().length() - 6)))) {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), "请不要使用初始密码作为登录密码！");
        }
        channel.setPassWord(MD5Util.MD5(param.getPasswordNew()));
        boolean a = channelService.updateById(channel);
        if (a) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), channel);
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }

    /**
     * 商户修改\补充资料
     */
    @RequestMapping(value = "/updateChannel", method = RequestMethod.POST)
    @ResponseBody
    public Object updateChannel(@RequestBody Channel param) throws Exception {
        if (param.getMobile() == null) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        Channel channel = channelService.selectByMobile(param.getMobile());
        if (param.getPicture() != null) {
            channel.setPicture(param.getPicture());
        }
        if (param.getOrgName() != null) {
            channel.setOrgName(param.getOrgName());
        }
        if (param.getBankName() != null) {
            channel.setBankName(param.getBankName());
        }
        if (param.getCardNo() != null) {
            channel.setCardNo(param.getCardNo());
        }
        boolean a = channelService.updateById(channel);
        if (a) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), channel);
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }


    /**
     * 订单
     */
    @RequestMapping(value = "/queryOrderList", method = RequestMethod.POST)
    @ResponseBody
    public Object queryOrderList(@RequestBody TradeListVo param, HttpSession session) throws Exception {
        PageData<TradeList> pageData = tradeListService.queryPage(param);
        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), pageData);
    }

    /**
     * 查询配置
     */
    @RequestMapping(value = "/queryChannelExplain", method = RequestMethod.POST)
    @ResponseBody
    public Object queryChannelExplain(@RequestBody ChannelExplain param) throws Exception {
        if (param.getChannel() == null || param.getChannel() == 0) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        ChannelExplain channelExplain = channelExplainService.selectByChanel(param.getChannel());
        return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage(), channelExplain);
    }

    /**
     * channelExplain
     */
    @RequestMapping(value = "/channelExplain", method = RequestMethod.POST)
    @ResponseBody
    public Object channelExplain(@RequestBody ChannelExplain param, HttpSession session) throws Exception {
//        AdminUser adminUser = (AdminUser) session.getAttribute("user");
//        //判断管理员权限
//        if (adminUser.getRole() != 10) {
//            return new DataResponseVo<>(StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getCode(), StatusCode.COMMON_INSUFFICIENT_PERMISSIONS.getMessage());
//        }
        if (param.getChannel() == null || param.getChannel() == 0) {
            return new DataResponseVo<>(StatusCode.COMMON_PARAM_ERROR.getCode(), StatusCode.COMMON_PARAM_ERROR.getMessage());
        }
        param.setCreateTime(new Date());
        ChannelExplain channelExplain = channelExplainService.selectByChanel(param.getChannel());
        if (channelExplain == null) {
            boolean a = channelExplainService.insert(param);
            if (a) {
                return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
            } else {
                return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
            }
        }
        if (param.getTitle() != null) {
            channelExplain.setTitle(param.getTitle());
        }
        if (param.getAdsImg() != null) {
            channelExplain.setAdsImg(param.getAdsImg());
        }
        if (param.getDemo() != null) {
            channelExplain.setDemo(param.getDemo());
        }
        if (param.getDetailTitle() != null) {
            channelExplain.setDetailTitle(param.getDetailTitle());
        }
        if (param.getDetailUrl() != null) {
            channelExplain.setDetailUrl(param.getDetailUrl());
        }
        boolean a = channelExplainService.updateById(channelExplain);
        if (a) {
            return new DataResponseVo<>(StatusCode.OK.getCode(), StatusCode.OK.getMessage());
        } else {
            return new DataResponseVo<>(StatusCode.SERVER_EXCEPTION.getCode(), StatusCode.SERVER_EXCEPTION.getMessage());
        }
    }


}


