package cn.dakaqi.blank.controller.response;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * 项目名称：forum
 * 
 * @description 前台基础vo对象
 * 
 * @author Wind-spg
 * 
 * @create_time 2014年10月8日 下午4:08:44
 * 
 * @version V1.0.0
 * 
 */
@Data
@ToString
@ApiModel
@NoArgsConstructor
@AllArgsConstructor
public class BaseResultVo implements Serializable
{

    /**
     * {变量说明}
     */
    private static final long serialVersionUID = -7978635757653362784L;

    // private static final Log LOGGER = LogFactory.getLog(BaseResultVo.class);

    // 返回码，0表示成功，非0表示失败
    @ApiModelProperty(value = "返回码，0表示成功，非0表示失败")
    private int resultCode;

    // 返回消息，成功为“success”，失败为具体失败信息
    @ApiModelProperty(value = "返回消息，成功为“success”，失败为具体失败信息")
    private String resultMessage;

    // 返回数据
    @ApiModelProperty(value = "返回数据")
    private Object resultData;
    
    public BaseResultVo(String resultMessage, Object resultData)
    {
        this.resultMessage = resultMessage;
        this.resultData = resultData;
    }
    
    public BaseResultVo(int resultCode, String resultMessage)
    {
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
    }

}
