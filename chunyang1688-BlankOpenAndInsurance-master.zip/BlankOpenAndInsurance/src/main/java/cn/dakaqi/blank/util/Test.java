/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.blank.util;

/**
 * 类名称：Test <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/13 10:13
 * @version: 1.0.0
 */

public class Test {
    public static void main(String[] args)
    {

        IdcardInfoExtractor idcardInfo=new IdcardInfoExtractor("330219195204167866");
        System.out.println("出生日期:"+idcardInfo.getYear()+"-"+idcardInfo.getMonth()+"-"+idcardInfo.getDay());
        System.out.println("出生日期:"+idcardInfo.getBirthday());
        System.out.println("性别:"+idcardInfo.getGender());
        System.out.println("年龄:"+idcardInfo.getAge());
        System.out.println("省份:"+idcardInfo.getProvince());

    }
}
 