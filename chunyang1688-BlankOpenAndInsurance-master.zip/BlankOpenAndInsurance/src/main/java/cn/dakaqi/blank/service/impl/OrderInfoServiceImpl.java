package cn.dakaqi.blank.service.impl;

import cn.dakaqi.blank.controller.response.SubmitSuccessResponseItem;
import cn.dakaqi.blank.entity.OrderInfo;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.exception.ServiceRuntimeException;
import cn.dakaqi.blank.mapper.OrderInfoMapper;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.service.OrderInfoService;
import cn.dakaqi.blank.util.ConfigUtil;
import cn.dakaqi.blank.util.DateUtil;
import cn.dakaqi.blank.util.OrderStatus;
import cn.dakaqi.blank.util.wechatPay.PayJsWithAppId;
import cn.dakaqi.blank.util.wechatPay.UnifiedOrderResult;
import cn.dakaqi.blank.util.wechatPay.WechatPaymentUtil;
import cn.dakaqi.blank.util.wechatPay.XMLUtil;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-06
 */
@Service
@Slf4j
public class OrderInfoServiceImpl extends ServiceImpl<OrderInfoMapper, OrderInfo> implements OrderInfoService {

    @Resource
    private ITradeListService tradeListService;

    @Override
    public String wxCallback(InputStream inputStream) {
        //读取微信回调信息
        InputStream inStream;
        String result = "";
        try {
            inStream = inputStream;

            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;

            while ((len = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            result = new String(outStream.toByteArray(), "utf-8");
            outStream.close();
            inStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        //如果微信回调信息存在
        if (StringUtils.isNotEmpty(result.trim())) {
            Map map = XMLUtil.doXMLParse(result);

            //并且返回支付成功
            if (map != null && map.get("result_code").toString().equalsIgnoreCase("SUCCESS")) {
                //解析支付成功数据
                String orderCode = (map.get("out_trade_no") != null) ? map.get("out_trade_no").toString() : "1212321211201407033568112322";
                String timePayed = (map.get("time_end") != null) ? map.get("time_end").toString() : "20141030133525";
                Date payTime = DateUtil.str2Date(timePayed, "yyyyMMddHHmmss");
                String transactionId = (map.get("transaction_id") != null) ? map.get("transaction_id").toString() : "1217752501201407033233368018";
                String bankType = (map.get("bank_type") != null) ? map.get("bank_type").toString() : "CMC";
                String feeType = (map.get("fee_type") != null) ? map.get("fee_type").toString() : "CNY";
                String tradeType = (map.get("trade_type") != null) ? map.get("trade_type").toString() : "JSAPI";
                String totalFee = (map.get("total_fee") != null) ? map.get("total_fee").toString() : "1";
                String mchId = (map.get("mch_id") != null) ? map.get("mch_id").toString() : "1";
                String openid = (map.get("openid") != null) ? map.get("openid").toString() : "1";

                //获取订单编号   五位渠道编号+六位业务编号+六位订单时间+8位经过偏移的UUID+六位提交订单时时间戳
//                String chanelCode = orderCode.substring(0, 4);
                orderCode = orderCode.substring(0,25);

                Map<String, Object> mapParam = new HashMap<>();
                mapParam.put("orderCode", orderCode);
                List<OrderInfo> orderInfoList = super.selectByMap(mapParam);
                if (orderInfoList.size() == 1) {
                    OrderInfo orderInfo = orderInfoList.get(0);

                    orderInfo.setUpdateTime(new Date());
                    orderInfo.setOpenId(openid);
                    orderInfo.setOrderStatus(OrderStatus.FINISHED.getSequenceId());
                    orderInfo.setPayState(2); //1 待支付 2 支付成功
                    orderInfo.setPayPattern(1);//默认1网页支付

                    orderInfo.setPayTime(payTime);
                    orderInfo.setTransactionId(transactionId);
                    orderInfo.setBankType(bankType);
                    orderInfo.setFeeType(feeType);
                    orderInfo.setTradeType(tradeType);
                    orderInfo.setMchId(mchId);
                    orderInfo.setTotalFee(totalFee);
                    orderInfo.setTimeEnd(timePayed);

                    boolean resultBoolean = super.updateById(orderInfo);

                    if (resultBoolean) {
                        TradeList tradeList = new TradeList();
                        tradeList.setOpenId(orderInfo.getOpenId());
                        tradeList.setBusiness(orderInfo.getOrderBusiness());
                        tradeList.setChannel(orderInfo.getOrderChannel());
                        tradeList.setFinishDate(orderInfo.getPayTime());
                        tradeList.setMoney(orderInfo.getTotal());
                        tradeList.setOrderCode(orderInfo.getOrderCode());
                        tradeListService.insert(tradeList);

                        return "SUCCESS";
                    } else {
                        log.error("update OrderInfo Error , Id ： " + orderInfo.getId());
                    }

                } else {
                    log.error("orderInfo exists error Number by : " + orderCode);
                }

            }
        }
        return "FAIL";
    }

    @Override
    public SubmitSuccessResponseItem unifiedOrder(String ipStr, String orderCode, String openId) {

        HashMap param = new HashMap();
        param.put("orderCode", orderCode);
        List<OrderInfo> orderInfoList = super.selectByMap(param);
        OrderInfo orderInfo;

        if (orderInfoList.size() == 1) {
            orderInfo = orderInfoList.get(0);
        } else {
            throw new ServiceRuntimeException(StatusCode.SERVER_EXCEPTION.getCode(), "订单查询异常");
        }

        UnifiedOrderResult orderResult = WechatPaymentUtil.getUnifiedorderResult("志趣基金-公益", orderCode, orderInfo.getTotal().intValue(), ipStr, openId);
        if (orderResult == null || null == orderResult.getResult_code() || "FAIL".equalsIgnoreCase(orderResult.getResult_code())) {
            throw new ServiceRuntimeException(StatusCode.SERVER_EXCEPTION.getCode(), "微信支付参数获取失败");
        }
//        String json = WechatPaymentUtil.generateMchPayJsRequestJson(orderResult.getPrepay_id(), ConfigUtil.getWxAppId(), ConfigUtil.getApiKey());
        PayJsWithAppId payJsWithAppId = WechatPaymentUtil.generateMchPayJsRequestObject(orderResult.getPrepay_id(), ConfigUtil.getWxAppId(), ConfigUtil.getApiKey());

        String prePayId = orderResult.getPrepay_id();
        if (prePayId != null && !Objects.equals("", prePayId)) {
            orderInfo.setPrepayId(prePayId);
        }

//        super.insertOrUpdate(orderInfo);

        return SubmitSuccessResponseItem.build(
                orderInfo.getId() == null ? "" : orderInfo.getId().toString(),
                orderInfo.getOrderCode(), orderInfo.getPrepayId(), payJsWithAppId);
    }

}
