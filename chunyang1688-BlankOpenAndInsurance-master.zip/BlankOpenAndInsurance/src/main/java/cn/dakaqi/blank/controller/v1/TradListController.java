package cn.dakaqi.blank.controller.v1;

import cn.dakaqi.blank.controller.BaseController;
import cn.dakaqi.blank.controller.input.TradListVO;
import cn.dakaqi.blank.entity.TradeList;
import cn.dakaqi.blank.service.ITradeListService;
import cn.dakaqi.blank.util.JsonResult;
import com.alibaba.fastjson.JSON;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * 类名称：TradListController <br>
 * 类描述：<br>
 *
 * @author chunyang.Zhang
 * @since 2016/12/12 21:53
 * @version 1.0.0
 */
@RestController
@RequestMapping(value = "/tradList")
@Slf4j
@Api(value = "交易记录", description = "交易记录", hidden = false)


public class TradListController extends BaseController {
    @Autowired
    ITradeListService tradeListService;

    @RequestMapping(value = "/addTrad", method = RequestMethod.POST)
    @ApiOperation(value = "第三方完成后，将信息回传到大平台", notes = "第三方完成后，将信息回传到大平台")
    public JsonResult addTrad(@RequestParam("jsonData") String jsonData) {
        log.info("1第三方完成后，将信息回传到大平台:" + jsonData);
        TradListVO vo = JSON.toJavaObject(JSON.parseObject(jsonData), TradListVO.class);
        TradeList tradeList = TradListVO.buildTradList(vo);
        tradeList.setCreateTime(new Date());
        log.info("2第三方完成后，将信息回传到大平台:" + tradeList.toString());
        tradeListService.insert(tradeList);
        return renderSuccess();
    }
}
 
 