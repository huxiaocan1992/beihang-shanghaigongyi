package cn.dakaqi.blank.qiniu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.qiniu.api.auth.AuthException;
import com.qiniu.api.auth.digest.Mac;
import com.qiniu.api.fop.ImageInfo;
import com.qiniu.api.fop.ImageInfoRet;
import com.qiniu.api.io.IoApi;
import com.qiniu.api.io.PutExtra;
import com.qiniu.api.io.PutRet;
import com.qiniu.api.rs.PutPolicy;
import com.qiniu.api.rs.RSClient;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.InputStream;


public class QNiuToken
{
    static Logger log = LoggerFactory.getLogger(QNiuToken.class);
    public static final String SCOPE = "dakaqi";

    public static final String QINIU_DOMAIN = "http://img.dakaqi.cn";

    public static final String SIZE_180 = "?imageView2/1/w/180/h/180";
    public static final String SIZE_50 = "?imageView2/1/w/50/h/50";
    public static final String SIZE_30 = "?imageView2/1/w/30/h/30";
    public static final String SIZE_225_300 = "?imageView2/1/w/225/h/300";


    private static final String ACCESS_KEY = "q9Z2omvM-8jgwetBmiqBwJcjcL7dYf4Tdj-vRZIa";
    private static final String SECRET_KEY = "tS4BL5gXNkC1Y09IE_XgmYTjwC6pAeZqgeo9-l5k";
    private static Mac mac = null;

    static
    {
        mac = new Mac(ACCESS_KEY, SECRET_KEY);
    }

    public static String token(String scope)
    {

        if (scope == null || scope.trim().equals(""))
        {
            scope = SCOPE;
        }
        PutPolicy putPolicy = new PutPolicy(scope);
        putPolicy.returnBody = "{\"bucket\":${bucket},\"key\": $(key),\"name\": $(fname),\"size\": $(fsize),\"type\": $(mimeType),\"hash\": $(etag)}";

        try
        {
            return putPolicy.token(mac);
        } catch (AuthException e)
        {
            e.printStackTrace();
            log.error(e.getMessage());

        } catch (JSONException e)
        {
            e.printStackTrace();
            log.error(e.getMessage());

        } catch (Exception e)
        {
            e.printStackTrace();
            log.error(e.getMessage());

        }
        return null;
    }

    public static String uploadQiniu(File tempFile, String fileName)
    {
        try
        {

            PutExtra extra = new PutExtra();
            PutRet ret = IoApi.putFile(QNiuToken.token(null), fileName, tempFile.getAbsolutePath(), extra);

            String json = ret.response;
            JSONObject obj = JSON.parseObject(json);

            return obj.get("key").toString();//key指七牛返回的文件名
        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
            log.error(e.getMessage());

        }

        return null;

    }

    public static String uploadQiniu(InputStream inputStream, String fileName)
    {
        try
        {

            PutExtra extra = new PutExtra();
            PutRet ret = IoApi.Put(QNiuToken.token(null), fileName, inputStream, extra);

            String json = ret.response;
            JSONObject obj = JSON.parseObject(json);

            return obj.get("key").toString();//key指七牛返回的文件名
        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
            log.error(e.getMessage());

        }

        return null;

    }

    public static boolean delFromQiNiu(String fileName)
    {
        try
        {

            RSClient client = new RSClient(mac);
            client.delete(SCOPE, fileName);

        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
            log.error(e.getMessage());

        }

        return false;

    }

    public static int[] getImgAttr(String imgUrl)
    {
        int size[] = new int[2];
        ImageInfoRet ret = ImageInfo.call(imgUrl);
        int height = ret.height;
        int width = ret.width;
        size[0] = width;
        size[1] = height;

        return size;
    }

}