package cn.dakaqi.blank.service;

import cn.dakaqi.blank.entity.ActivateRecord;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-20
 */
public interface IActivateRecordService extends IService<ActivateRecord>
{
	ActivateRecord selectByIdNO(String idNo);
	boolean insertRecord(String idNo,String passportNo);
	boolean updateActivateRecord7(String realName,String mobile,String idNo,String passportNo);
	boolean updateActivateRecord18(String realName,String idNo,String guardianCardNo,String passportNo);
}
