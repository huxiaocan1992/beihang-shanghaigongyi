package cn.dakaqi.blank.util;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

/** */

/**
 * <p>
 * RSA公钥/私钥/签名工具包
 * </p>
 *
 * <p>
 * 字符串格式的密钥在未在特殊说明情况下都为BASE64编码格式<br/>
 * 由于非对称加密速度极其缓慢，一般文件不使用它来加密而是使用对称加密，<br/>
 * 非对称加密算法可以用来对对称加密的密钥加密，这样保证密钥的安全也就保证了数据的安全
 * </p>
 *
 * @date 2012-4-26
 * @version 1.0
 */
public class RSAUtils {

    /** *//**
     * 加密算法RSA
     */
    public static final String KEY_ALGORITHM = "RSA";

    /** *//**
     * 签名算法
     */
    public static final String SIGNATURE_ALGORITHM = "MD5withRSA";

    /** *//**
     * 获取公钥的key
     */
    public static final String PUBLIC_KEY = "RSAPublicKey";

    /** *//**
     * 获取私钥的key
     */
    public static final String PRIVATE_KEY = "RSAPrivateKey";

    /** *//**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;

    /** *//**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;

    /** *//**
     * <p>
     * 生成密钥对(公钥和私钥)
     * </p>
     *
     * @return
     * @throws Exception
     */
    private static Map<String, Object> genKeyPair() throws Exception {
        //KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
        keyPairGen.initialize(1024);
        KeyPair keyPair = keyPairGen.generateKeyPair();
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        Map<String, Object> keyMap = new HashMap<String, Object>(2);
        keyMap.put(PUBLIC_KEY, publicKey);
        keyMap.put(PRIVATE_KEY, privateKey);
        return keyMap;
    }

    public static Map<String, Object> genKeyPairByString(String content) throws Exception {
        if(null == content || "".equals(content) || content.trim().length() == 0)
            return genKeyPair();

        //KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
        SecureRandom secrand = new SecureRandom();
        secrand.setSeed(content.getBytes()); // 初始化随机产生器
        keyPairGen.initialize(1024,secrand);
        KeyPair keyPair = keyPairGen.generateKeyPair();
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        Map<String, Object> keyMap = new HashMap<String, Object>(2);
        keyMap.put(PUBLIC_KEY, publicKey);
        keyMap.put(PRIVATE_KEY, privateKey);
        return keyMap;
    }
    /** *//**
     * <p>
     * 用私钥对信息生成数字签名
     * </p>
     *
     * @param data 已加密数据
     * @param privateKey 私钥(BASE64编码)
     *
     * @return
     * @throws Exception
     */
    public static String sign(byte[] data, String privateKey) throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initSign(privateK);
        signature.update(data);
        return Base64Utils.encode(signature.sign());
    }

    /** *//**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data 已加密数据
     * @param publicKey 公钥(BASE64编码)
     * @param sign 数字签名
     *
     * @return
     * @throws Exception
     *
     */
    public static boolean verify(byte[] data, String publicKey, String sign)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        PublicKey publicK = keyFactory.generatePublic(keySpec);
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initVerify(publicK);
        signature.update(data);
        return signature.verify(Base64Utils.decode(sign));
    }

    /** *//**
     * <P>
     * 私钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param privateKey 私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPrivateKey(byte[] encryptedData, String privateKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, privateK);
        int inputLen = encryptedData.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        return decryptedData;
    }

    /** *//**
     * <p>
     * 公钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param publicKey 公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] decryptByPublicKey(byte[] encryptedData, String publicKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key publicK = keyFactory.generatePublic(x509KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, publicK);
        int inputLen = encryptedData.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        return decryptedData;
    }

    /** *//**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param data 源数据
     * @param publicKey 公钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPublicKey(byte[] data, String publicKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(publicKey);
        X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key publicK = keyFactory.generatePublic(x509KeySpec);
        // 对数据加密
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, publicK);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段加密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_ENCRYPT_BLOCK;
        }
        byte[] encryptedData = out.toByteArray();
        out.close();
        return encryptedData;
    }

    /** *//**
     * <p>
     * 私钥加密
     * </p>
     *
     * @param data 源数据
     * @param privateKey 私钥(BASE64编码)
     * @return
     * @throws Exception
     */
    public static byte[] encryptByPrivateKey(byte[] data, String privateKey)
            throws Exception {
        byte[] keyBytes = Base64Utils.decode(privateKey);
        PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
        //KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM,new BouncyCastleProvider());
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
        Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE, privateK);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段加密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * MAX_ENCRYPT_BLOCK;
        }
        byte[] encryptedData = out.toByteArray();
        out.close();
        return encryptedData;
    }

    /** *//**
     * <p>
     * 获取私钥
     * </p>
     *
     * @param keyMap 密钥对
     * @return
     * @throws Exception
     */
    public static String getPrivateKey(Map<String, Object> keyMap)
            throws Exception {
        Key key = (Key) keyMap.get(PRIVATE_KEY);
        return Base64Utils.encode(key.getEncoded());
    }

    /** *//**
     * <p>
     * 获取公钥
     * </p>
     *
     * @param keyMap 密钥对
     * @return
     * @throws Exception
     */
    public static String getPublicKey(Map<String, Object> keyMap)
            throws Exception {
        Key key = (Key) keyMap.get(PUBLIC_KEY);
        return Base64Utils.encode(key.getEncoded());
    }

    public static void main(String[] args)
    {
        try
        {
            String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAIwwlYLtylarTYcu1746MH3z0+OBo5wMDAs7fG5+2Pmb+Q99R+2Cjtkb60AWR8WrGa/9cuBaRIIhskNtD3oJ4J4rg2Q4jda6ytCcc4h0Dx8jZ2qhrwLwZaK4efG4bltxqFB28iQWMoDIbIia5wsFYdfqWd1ji75caCZKGxhH+BgFAgMBAAECgYEAhp+1RClEMJyKc/Ho3lWU8a8v4H9C9XygKD00zgtkI7fDojtF0nCY6ycjb8S1ob4gid/S7F3jAjCHtrZJsYFAwE1kcxisUP8plb/A1XUS3b+Pv3SUGtWAn/eQ5pxCWKkuDTyad9+DQIR9/Fug545/p4/DGdIXTOrNnN18Z27wSaECQQDwuIfvxrAI1t7e8HKw9Hhok1Nupdf5Dgf/kfZdJK+i1s8vnAnzHmBmyY4uPm+K2tlqIgfZZ7GChdUeWoM81nV9AkEAlRaGkLzcemsftkC/j16zTBZzaZwWRoOKqYsFsi2H+0qlr5WSh0sz75GGPZk00Q/+YItcnEpUyKBzSUU4wzMTKQJARhbUrcICO3Ckz/De1Bs6e+h5oHv1WHT3aziKrTAjW5yEEu6yDvHHS+Zf2aMgQyPZrgdelbSVgNWK6h2cnLgs2QJAEJhcTDoplJreAcx9Rjk1Xg/VsvjD5f94bNzjumylCUzK2pucnuC5HD6noa2vGmJcX2TD30XK4DYz/wDsi5Xg2QJAM7wpfbCbsARCgjUB5j+3LRoYUW9J29q42JvTXIMUaAsGJ/8n/mgniJCVFHd605ZrMu9umXhglyzaGZpeCZ6fqA==";
            String publickKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCMMJWC7cpWq02HLte+OjB989PjgaOcDAwLO3xuftj5m/kPfUftgo7ZG+tAFkfFqxmv/XLgWkSCIbJDbQ96CeCeK4NkOI3WusrQnHOIdA8fI2dqoa8C8GWiuHnxuG5bcahQdvIkFjKAyGyImucLBWHX6lndY4u+XGgmShsYR/gYBQIDAQAB";
            //Map<String, Object> map = RSAUtils.genKeyPairByString("中华人民共和国");
            //publickKey = getPublicKey(map);
            //privateKey = getPrivateKey(map);

            //公钥加密，私钥解密
            //String name="100009|"+DateUtil.currentDateTimeStringTrim();
            String name="100009|"+ System.currentTimeMillis()+"|中华人民共和国";
            System.out.println(System.currentTimeMillis()+ "-1--加密前："+name);

            byte[] encodedData = encryptByPublicKey(name.getBytes(),publickKey);
            encodedData = Base64.encodeBase64(encodedData, false, true);
            System.out.println(System.currentTimeMillis()+ "-2--加密后："+new String(encodedData, "UTF-8"));


            //encodedData = "QwZFTlz8X8ldC/CPcYw98zRQHvIs4CZGUJfQg6uy5IdjvP3joIrnYH4ymnLHAnkwx2SsEoMVQ50eHpSEVZgxIl8pivq3kC92FAHkJ2lQuXZLZyPUX5SiDCjTt8sdUxxlL+YY2neXpBl4KqJ5ajkZdPt03D13al2Iwxn7DTK6cx8=".getBytes();
            encodedData = Base64.decodeBase64(encodedData);
            encodedData = RSAUtils.decryptByPrivateKey(encodedData, privateKey);

            System.out.println(System.currentTimeMillis()+  "-3--解密后："+new String(encodedData, "UTF-8"));
            System.out.println("************************************************************************\r\n");

/*            //私钥加密，公钥解密
            String name2 = new StringBuffer("上海金融中心").reverse().toString();
            System.out.println("1------>"+name2);
            byte[] encodedData2 = encryptByPrivateKey(name2.getBytes(), getPrivateKey(map));
            encodedData2 = Base64.encodeBase64(encodedData2, false, true);
            System.out.println("2------>"+new String(encodedData2, "UTF-8"));

            encodedData2 = Base64.decodeBase64(encodedData2);
            encodedData2 = decryptByPublicKey(encodedData2, getPublicKey(map));
            System.out.println("3------>"+new String(encodedData2, "UTF-8"));

            String sign = RSAUtils.sign(encodedData2, getPrivateKey(map));
            System.out.println("4------>"+"签名:" + sign);
            boolean status = RSAUtils.verify(encodedData2, getPublicKey(map), sign);
            System.out.println("5------>"+"验证结果:" + status);*/

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
