package cn.dakaqi.blank.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;
import lombok.ToString;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Chunyang.Zhang
 * @since 2016-12-08
 */
@TableName(value = "insurance")
@ToString
public class Insurance implements Serializable {

    private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId(type = IdType.AUTO)
	private Long id;

	/**
	 * 志愿者一号通
	 */
	private String volunteerCode;

	/**
	 * 保单号
	 */
	private String insuranceNo;

	/**
	 * 生效日期
	 */
	private String periodStart;

	/**
	 * 失败日期
	 */
	private String periodEnd;

	/**
	 * 
	 */
	private String insuranceProcessDate;

	/**
	 * 
	 */
	private String premium;

	/**
	 * 
	 */
	private String serviceProvider;

	/**
	 * 
	 */
	private String serviceProviderUrl;

	/**
	 * 
	 */
	private String transactionBatch;

	/**
	 * 
	 */
	private String payId;

	/**
	 * 是否激活 -10 未 10已
	 */
	private Integer status;

	/**
	 * 
	 */
	private String createTime;



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVolunteerCode() {
		return volunteerCode;
	}

	public void setVolunteerCode(String volunteerCode) {
		this.volunteerCode = volunteerCode;
	}

	public String getInsuranceNo() {
		return insuranceNo;
	}

	public void setInsuranceNo(String insuranceNo) {
		this.insuranceNo = insuranceNo;
	}

	public String getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(String periodStart) {
		this.periodStart = periodStart;
	}

	public String getPeriodEnd() {
		return periodEnd;
	}

	public void setPeriodEnd(String periodEnd) {
		this.periodEnd = periodEnd;
	}

	public String getInsuranceProcessDate() {
		return insuranceProcessDate;
	}

	public void setInsuranceProcessDate(String insuranceProcessDate) {
		this.insuranceProcessDate = insuranceProcessDate;
	}

	public String getPremium() {
		return premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getServiceProviderUrl() {
		return serviceProviderUrl;
	}

	public void setServiceProviderUrl(String serviceProviderUrl) {
		this.serviceProviderUrl = serviceProviderUrl;
	}

	public String getTransactionBatch() {
		return transactionBatch;
	}

	public void setTransactionBatch(String transactionBatch) {
		this.transactionBatch = transactionBatch;
	}

	public String getPayId() {
		return payId;
	}

	public void setPayId(String payId) {
		this.payId = payId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

}
