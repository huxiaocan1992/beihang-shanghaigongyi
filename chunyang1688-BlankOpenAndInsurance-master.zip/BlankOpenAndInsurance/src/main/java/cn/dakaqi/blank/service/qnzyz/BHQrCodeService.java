package cn.dakaqi.blank.service.qnzyz;

import cn.dakaqi.blank.util.HttpsUtil;
import cn.dakaqi.blank.util.Img2Base64Util;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2015/9/8.
 */
@Service
public class BHQrCodeService
{
    @Autowired
    BHConstant bhConstant;
    @Autowired
    BHAccesssToken bhAccesssToken;
    @Autowired
    BHEncrytByPublicKey bhEncrytByPublicKey;
    private ValueFilter filter = new ValueFilter() {
        @Override
        public Object process(Object obj, String s, Object v) {
            if(v==null)
                return "";
            return v;
        }
    };
    private static SerializerFeature[] features = {SerializerFeature.WriteNullNumberAsZero, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.DisableCircularReferenceDetect};


    /**
     * 生成志愿者个人二维码
     * @return
     * @throws Exception
     */
    public String createVolunteerQR(String volunteerCode)throws Exception
    {
        String qcImg = null;
        String imgFile = Img2Base64Util.createQRImage("volunteer", volunteerCode);
        qcImg = Img2Base64Util.getImgStr(imgFile);
        File file = new File(imgFile);
        if(file.exists())
            file.delete();

//        String postUrl = BHConstant.checkNetWork()+"/api/v1/qrcode/volunteer?client="+ Constant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(Constant.CLIENTID);
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("code",volunteerCode);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code ==0)
//                {
//                    JSONObject resultJson = jsonObject.getJSONObject("result");
//                    qcImg = resultJson.getString("qcImg");
//                }
//                else
//                    throw new Exception(msg);
//            }
//        }

        return qcImg;
    }

    /**
     * 生成社团二维码
     * @return
     * @throws Exception
     */
    public String createGroupQR(String groupCode)throws Exception
    {

        String qcImg = null;
        String imgFile = Img2Base64Util.createQRImage("group", groupCode);
        qcImg = Img2Base64Util.getImgStr(imgFile);
        File file = new File(imgFile);
        if(file.exists())
            file.delete();

//        String qcImg = null;
//        String postUrl = BHConstant.checkNetWork()+"/api/v1/qrcode/group?client="+ Constant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(Constant.CLIENTID);
//
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("code",groupCode);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//
//        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code ==0)
//                {
//                    JSONObject resultJson = jsonObject.getJSONObject("result");
//                    qcImg = resultJson.getString("qcImg");
//                }
//                else
//                    throw new Exception(msg);
//            }
//        }

        return qcImg;
    }

    /**
     * 生成活动二维码
     * @return
     * @throws Exception
     */
    public String createActivityQR(String activityCode)throws Exception
    {
        String qcImg = null;
        String imgFile = Img2Base64Util.createQRImage("activity", activityCode);
        qcImg = Img2Base64Util.getImgStr(imgFile);
        File file = new File(imgFile);
        if(file.exists())
            file.delete();

//        String postUrl = BHConstant.checkNetWork()+"/api/v1/qrcode/activity?client="+ Constant.CLIENTID
//                + "&token=" + bhAccesssToken.getAccessToken(Constant.CLIENTID);
//
//        Map<String,String> map = new HashMap<String,String>();
//        map.put("code",activityCode);
//        String postEntity = JSON.toJSONString(map,filter);
//        String result = HttpsUtil.post(postUrl, postEntity);
//
//        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
//        {
//            JSONObject jsonObject = JSON.parseObject(result);
//            if(jsonObject != null)
//            {
//                int res_code = jsonObject.getInteger("ret");
//                String msg = jsonObject.getString("msg");
//                if(res_code ==0)
//                {
//                    JSONObject resultJson = jsonObject.getJSONObject("result");
//                    qcImg = resultJson.getString("qcImg");
//                }
//                else
//                    throw new Exception(msg);
//            }
//        }

        return qcImg;
    }

    /**
     * 扫描个人二维码
     * @return
     * @throws Exception
     */
    public JSONObject scanVolunteerInfo(String volunteerCode)throws Exception
    {
        JSONObject resultJson = null;
        String postUrl = bhConstant.checkNetWork()+"/api/v1/qrcode/volunteerInfo?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);

        Map<String,String> map = new HashMap<String,String>();
        map.put("volunteerCode",volunteerCode);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(res_code ==0)
                {
                    resultJson = jsonObject.getJSONObject("result");
                }
                else
                    throw new Exception(msg);
            }
        }

        return resultJson;
    }

    /**
     * 扫描社团二维码
     * @return
     * @throws Exception
     */
    public JSONObject scanGroupInfo(String groupCode)throws Exception
    {
        JSONObject resultJson = null;
        String postUrl = bhConstant.checkNetWork()+"/api/v1/qrcode/groupInfo?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);

        Map<String,String> map = new HashMap<String,String>();
        map.put("groupCode",groupCode);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(res_code ==0)
                {
                    resultJson = jsonObject.getJSONObject("result");
                }
                else
                    throw new Exception(msg);
            }
        }

        return resultJson;
    }

    /**
     * 扫描活动二维码
     * @return
     * @throws Exception
     */
    public JSONObject scanActivityInfo(String activityCode)throws Exception
    {
        JSONObject resultJson = null;
        String postUrl = bhConstant.checkNetWork()+"/api/v1/qrcode/activityInfo?client="+ BHConstant.CLIENTID
                + "&token=" + bhAccesssToken.getAccessToken(BHConstant.CLIENTID);

        Map<String,String> map = new HashMap<String,String>();
        map.put("activityCode",activityCode);
        String postEntity = JSON.toJSONString(map,filter);
        String result = HttpsUtil.post(postUrl, postEntity);

        if(StringUtils.isNotEmpty(result)&& !result.trim().equals("[]"))
        {
            JSONObject jsonObject = JSON.parseObject(result);
            if(jsonObject != null)
            {
                int res_code = jsonObject.getInteger("ret");
                String msg = jsonObject.getString("msg");
                if(res_code ==0)
                {
                    resultJson = jsonObject.getJSONObject("result");
                }
                else
                    throw new Exception(msg);
            }
        }

        return resultJson;
    }
}
