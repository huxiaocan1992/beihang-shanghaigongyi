package cn.dakaqi.blank.exceptionhandler;

import cn.dakaqi.blank.controller.response.BaseResponseVo;
import cn.dakaqi.blank.enumerate.StatusCode;
import cn.dakaqi.blank.exception.EncryptionException;
import cn.dakaqi.blank.exception.LoginRequiredException;
import cn.dakaqi.blank.exception.ServiceRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.util.List;


/**
 * @author Jay
 *         <p>
 *         Handle different kinds of exceptions being thrown from controllers
 *         <p>
 *         Transalate those exceptions into well formatted json string
 */
@ControllerAdvice
public class RestErrorHandler {

    @Resource
    private MessageSource messageSource;

    @Autowired
    public RestErrorHandler(MessageSource messageSource) {
        this.messageSource = messageSource;
    }


    @ExceptionHandler(ServiceRuntimeException.class)
    @ResponseBody
    public BaseResponseVo processServiceRuntimeException(ServiceRuntimeException e) {
        return new BaseResponseVo(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public ResponseEntity<BaseResponseVo> processMethodArgumentNotValid(MethodArgumentNotValidException e) {
        return new ResponseEntity<>(new BaseResponseVo(StatusCode.COMMON_PARAM_ERROR.getCode(),
                message(e.getBindingResult())),
                HttpStatus.OK);
    }

    @ExceptionHandler(LoginRequiredException.class)
    @ResponseBody
    public ResponseEntity<BaseResponseVo> processLoginRequired() {
        return new ResponseEntity<>(
                new BaseResponseVo(StatusCode.COMMON_USER_NOT_LOGIN.getCode(), StatusCode.COMMON_USER_NOT_LOGIN.getMessage()), HttpStatus.NETWORK_AUTHENTICATION_REQUIRED);
    }

    @ExceptionHandler(EncryptionException.class)
    @ResponseBody
    public ResponseEntity<BaseResponseVo> processEncryption(EncryptionException e) {
        e.getField();//错误字段
        e.getErrorCode();//错误代码
        return new ResponseEntity<>(new BaseResponseVo(StatusCode.COMMON_INVALID_SIGN.getCode(), StatusCode.COMMON_INVALID_SIGN.getMessage()),
                HttpStatus.OK);
    }

    @ExceptionHandler(value = {IllegalArgumentException.class, IllegalStateException.class})
    @ResponseBody
    protected ResponseEntity<BaseResponseVo> handleConflict(RuntimeException e) {
        return new ResponseEntity<>(new BaseResponseVo(StatusCode.COMMON_PARAM_ERROR.getCode(), message(e.getMessage())), HttpStatus.OK);
    }

    @ExceptionHandler(value = {DataIntegrityViolationException.class})
    @ResponseBody
    protected ResponseEntity<BaseResponseVo> handleConflict(DataIntegrityViolationException e) {
        if (e.getCause() instanceof ConstraintViolationException) {
            ConstraintViolationException ex = (ConstraintViolationException) e.getCause();
            if (ex.getCause() instanceof SQLException) {
                SQLException exx = (SQLException) ex.getCause();
                return new ResponseEntity<>(new BaseResponseVo(-1, exx.getMessage()), HttpStatus.OK);
            }
            return new ResponseEntity<>(new BaseResponseVo(-1, ex.getMessage()), HttpStatus.OK);
        }
        return new ResponseEntity<>(new BaseResponseVo(-1, e.getMessage()), HttpStatus.OK);
    }

    private String message(String code) {
        return messageSource.getMessage(code, null, LocaleContextHolder.getLocale());
    }

    private String message(BindingResult result) {
        StringBuilder sb = new StringBuilder();
        List<FieldError> fieldErrors = result.getFieldErrors();
        //读取读取国际化配置 通过messageSource
//        for (FieldError fieldError : fieldErrors) {
//            sb.append(messageSource.getMessage(fieldError, LocaleContextHolder.getLocale()));
//        }

        //暂时没有国际化的需求，自己拼接错误信息
        for (FieldError fieldError : fieldErrors) {
            sb.append(fieldError.getDefaultMessage()).append("|");
        }
        return sb.toString().substring(0, sb.toString().length() - 1);
    }

}