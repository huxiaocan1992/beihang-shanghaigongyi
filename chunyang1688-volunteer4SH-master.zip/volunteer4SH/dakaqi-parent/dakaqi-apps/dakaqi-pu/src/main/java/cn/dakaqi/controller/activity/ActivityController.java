package cn.dakaqi.controller.activity;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivityApply;
import cn.dakaqi.entities.ActivityRecruit;
import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.enumerate.CommonStatusCode;
import cn.dakaqi.services.*;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.DateUtil;
import cn.dakaqi.vo.request.pu.ActivityRecordRequestVo;
import cn.dakaqi.vo.request.pu.ActivityRequestVo;
import cn.dakaqi.vo.response.ActivityAndApplyVO;
import cn.dakaqi.vo.response.ActivityApplyVO;
import cn.dakaqi.vo.response.DataResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author beliveli on 2016/4/7.
 *         活动
 */
@RestController
@RequestMapping(value = "/api/v1/activity")
@Slf4j
public class ActivityController {

    @Resource
    private ActivityApplyService activityApplyService;

    @Resource
    private ActivityRecruitVolunteerService activityRecruitVolunteerService;

    @Resource
    private ActivitySignRecordService activitySignRecordService;

    @Resource
    private ActivityService activityService;

    @Resource
    private ActivityRecruitService activityRecruitService;

    @ResponseBody
    @RequestMapping(value = "/getMyActivity", method = RequestMethod.POST, consumes = "application/json")
    public DataResponseVo<Page<ActivityApply>> getMyActivity(@RequestBody ActivityRequestVo activityRequestVo) {
        Page<ActivityApply> page = activityApplyService.queryByMemberAndActivityNotEND(activityRequestVo.getMemberCode(),
                activityRequestVo.getPageNumber());
        return new DataResponseVo<>(0, "", page);
    }

    @ResponseBody
    @RequestMapping(value = "/getCityActivity", method = RequestMethod.POST, consumes = "application/json")
    public DataResponseVo<Page<Activity>> getCityActivity(@RequestBody ActivityRequestVo activityRequestVo) {
        Page<Activity> activityPage = activityService.findByCityAndDelStatusAnd(activityRequestVo.getPageNumber(), activityRequestVo.getCity(),
                DateUtil.date2Str(new Date(), DateUtil.DATETIME_YYYY_MM_DD_HH_MM_SS));
        return new DataResponseVo<>(0, "", activityPage);
    }

    @ResponseBody
    @RequestMapping(value = "/joinActivity", method = RequestMethod.POST, consumes = "application/json")
    public DataResponseVo<ActivityApply> joinActivity(@Valid @RequestBody ActivityRequestVo activityRequestVo) {
        ActivityApply activityApply = activityRecruitVolunteerService.apply(activityRequestVo.getMemberCode(),
                activityRequestVo.getActivityCode(), activityRequestVo.getAnswer());
        return new DataResponseVo<>(0, "", activityApply);
    }

    @ResponseBody
    @RequestMapping(value = "/activityRecord", method = RequestMethod.POST, consumes = "application/json")
    public DataResponseVo<ActivitySign> activityRecord(@Valid @RequestBody ActivityRecordRequestVo activityRecordRequestVo) {

        ActivitySign activitySign = activitySignRecordService.save(activityRecordRequestVo.getMemberCode(), activityRecordRequestVo.getActivityCode(),
                activityRecordRequestVo.getLng(), activityRecordRequestVo.getLat());

        return new DataResponseVo<>(0, "", activitySign);
    }

    /**
     * 活动详情
     */
    @RequestMapping(value = "/info", method = RequestMethod.POST, consumes = "application/json")
    public DataResponseVo<ActivityAndApplyVO> info(@Valid @RequestBody ActivityRecordRequestVo activityRecordRequestVo) {
        Activity activity = activityService.findOne(activityRecordRequestVo.getActivityId());
        if (null == activity) {
            return new DataResponseVo<>(CommonStatusCode.ACTIVITY_NOT_EXISTS.getStatusCode(), CommonStatusCode.ACTIVITY_NOT_EXISTS.getStatusMessage());
        }

        //查询本次活动的20个报名名单
        List<ActivityApplyVO> vos = new ArrayList<>();
        Page<ActivityApply> applies = this.activityApplyService.queryByActivity(activity.getActivityCode(), DKQConstant.APPLY_STATUS_OK, 1);
        if (null != applies && null != applies.getContent() && applies.getContent().size() > 0) {
            vos.addAll(applies.getContent().stream().map(ActivityApplyVO::buildVO).collect(Collectors.toList()));
        }
        ActivityRecruit activityRecruit = activityRecruitService.findByActivity(activity.getId());
        ActivityAndApplyVO activityVO = ActivityAndApplyVO.buildVO(activity, activityRecruit, ConfigUtil.getClientId(), vos);
        //ActivityRecruit activityRecruit = activityRecruitService.findByActivityCode(activity.getActivityCode());
        if (null != activityRecruit)
            activityVO.setIsRecruit(1);

        return new DataResponseVo<>(CommonStatusCode.OK.getStatusCode(), CommonStatusCode.OK.getStatusMessage(), activityVO);
    }
}








