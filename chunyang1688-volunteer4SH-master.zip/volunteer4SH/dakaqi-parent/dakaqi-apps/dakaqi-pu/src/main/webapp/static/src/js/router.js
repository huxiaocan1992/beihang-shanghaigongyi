puApp.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider
        .when('', '/user')
    $stateProvider
        .state('activity', {
            title: '最新公益活动',
            url: '/activity',
            views: {
                'mainView': {
                    templateUrl: 'components/detail/detail.html',
                    controller: 'detailCtrl'
                }
            }
        })
        .state('enroll', {
            url: '/enroll',
            views: {
                'mainView': {
                    templateUrl: 'components/enroll/enroll.html',
                    controller: 'enrollCtrl'
                }
            }
        })
        .state('user', {
            title: 'PU',
            url: '/user',
            views: {
                'mainView': {
                    templateUrl: 'components/user/user.html',
                    controller: 'userCtrl'
                }
            }
        })
        .state('sign', {
            title: '签到',
            url: '/sign',
            views: {
                'mainView': {
                    templateUrl: 'components/sign/sign.html',
                    controller: 'signCtrl'
                }
            }
        })
        .state('insure', {
            title: '活动保障',
            url: '/insure',
            views: {
                'mainView': {
                    templateUrl: 'components/insure/insure.html',
                    controller: 'insureCtrl'
                }
            }
        })
        .state('insureSuccess', {
            title: '活动保障',
            url: '/insure-success',
            views: {
                'mainView': {
                    templateUrl: 'components/insure/insure-success.html',
                    controller: 'insureCtrl'
                }
            }
        })
        .state('download', {
            title: 'UP·公益APP下载',
            url: '/download',
            views: {
                'mainView': {
                    templateUrl: 'components/download/download.html',
                    controller: 'downloadCtrl'
                }
            }
        })
        .state('myActivity', {
            title: '我的活动',
            url: '/my-activity',
            views: {
                'mainView': {
                    templateUrl: 'components/my-activity/list.html',
                    controller: 'myActivityCtrl'
                }
            }
        })
})