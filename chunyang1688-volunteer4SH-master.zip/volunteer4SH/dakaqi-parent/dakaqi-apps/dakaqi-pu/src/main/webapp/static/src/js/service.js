puApp
    .factory('User', ['$rootScope', '$resource', function ($rootScope, $resource) {
        return $resource("", {}, {
            userJoin: {
                cache: false,
                method: 'POST',
                headers: $rootScope.head,
                url: $rootScope.api + 'api/v1/user/userJoin',
                isArray: false
            }
        })
    }])
    .factory('Activity', ['$rootScope', '$resource', function ($rootScope, $resource) {
        return $resource("", {}, {
            getMyActivity: {
                cache: false,
                method: 'POST',
                headers: $rootScope.head,
                url: $rootScope.api + 'api/v1/activity/getMyActivity',
                isArray: false
            }
        })
    }])