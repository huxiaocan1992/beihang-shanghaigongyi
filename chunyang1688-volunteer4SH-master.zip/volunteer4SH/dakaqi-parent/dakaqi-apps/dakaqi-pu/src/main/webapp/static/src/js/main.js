var puApp = angular.module('puApp', ['ui.router', 'ngResource'])
puApp.run(['$location', '$rootScope', function($location, $rootScope){
    $rootScope.$on('$stateChangeSuccess', function (event, toState) {
        $rootScope.title = toState.title
    })
    $rootScope.api = '/'
    $rootScope.head = {
        'content-type': 'application/json'
    }
}])