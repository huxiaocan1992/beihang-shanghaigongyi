puApp.controller('downloadCtrl', ['$scope', '$state', '$rootScope', function ($scope, $state, $rootScope) {
}])