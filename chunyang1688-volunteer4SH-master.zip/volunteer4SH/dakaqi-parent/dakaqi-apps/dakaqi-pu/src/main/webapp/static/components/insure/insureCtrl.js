puApp.controller('insureCtrl', ['$scope', '$state', '$rootScope', function ($scope, $state, $rootScope) {
}])