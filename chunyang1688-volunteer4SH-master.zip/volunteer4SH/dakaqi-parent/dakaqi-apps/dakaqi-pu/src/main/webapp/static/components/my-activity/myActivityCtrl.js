puApp.controller('myActivityCtrl', ['$scope', '$state', '$rootScope', 'Activity', function ($scope, $state, $rootScope, Activity)  {
    var postData = {
        "otherUserId": 1001,
        "school": "中国人民解放军防化指挥工程学院",
        "faculty": "野生动物与自然保护区管理专业",
        "classes": "工程102班",
        "realName": "张三",
        "phone": "12345678910",
        "IDCard": "610124199210210358",
        "province": "上海",
        "city": "上海市",
        "district": "长宁区"
    }
    //Activity.getMyActivity({}, postData, function (data) {
    //    $scope.myActivityInfo = data.data
    //})
}])