puApp.controller('userCtrl', ['$scope', '$state', '$rootScope', 'User', function ($scope, $state, $rootScope, User) {
    if(true){
        //$state.go('')
    }
    var postData = {
        "otherUserId": 1001,
        "school": "中国人民解放军防化指挥工程学院",
        "faculty": "野生动物与自然保护区管理专业",
        "classes": "工程102班",
        "realName": "张三",
        "phone": "12345678910",
        "idCard": "610124199210210358",
        "province": "上海",
        "city": "上海市",
        "district": "长宁区"
    }
    User.userJoin({}, postData, function (data) {
        $scope.userInfo = data.data
        $rootScope.title = $scope.userInfo.realName
    })
}])