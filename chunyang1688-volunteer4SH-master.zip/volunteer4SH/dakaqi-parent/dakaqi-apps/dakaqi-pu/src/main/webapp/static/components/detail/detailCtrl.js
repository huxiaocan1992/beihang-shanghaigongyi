puApp.controller('detailCtrl', ['$scope', function ($scope) {
    console.log(1)
}])