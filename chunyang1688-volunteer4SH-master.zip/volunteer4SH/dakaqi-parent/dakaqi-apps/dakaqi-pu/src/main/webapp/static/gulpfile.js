'use strict'
var gulp = require('gulp'),
    autoprefixer = require('gulp-autoprefixer'),
    rename = require('gulp-rename'),
    sass = require('gulp-sass'),
    minifycss = require('gulp-minify-css'),
    uglify = require('gulp-uglify'),
    concat = require('gulp-concat'),
    rev = require('gulp-rev'),
    revCollector = require('gulp-rev-collector'),
    clean = require('gulp-clean'),
    ngmin = require('gulp-ngmin'),
    imagemin = require('gulp-imagemin'),
    sourcemaps = require('gulp-sourcemaps'),
    gulpif = require('gulp-if'),
    watch = require('gulp-watch'),
    spritesmith = require('gulp.spritesmith'),
    buffer = require('vinyl-buffer'),
    csso = require('gulp-csso'),
    merge = require('merge-stream'),
    htmlmin = require('gulp-htmlmin'),
    runSequence = require('run-sequence')
var paths = {
    js: ['src/**/*.js', 'components/**/*.js'],
    css: ['dist/css/app.css'],
    scss: ['src/scss/app.scss'],
    image: ['src/images/*.{png,jpg,gif,ico}'],
    imageSprite: ['src/images/sprite/*.png'],
    imageRetina: ['src/images/sprite/*@2x.png'],
    html: ['./*.html']
}
gulp.task('outCss', function() {
    return gulp.src(paths.scss)
        .pipe(sourcemaps.init())
        .pipe(sass().on('error', sass.logError))
        .pipe(autoprefixer({
            browsers: ['last 2 versions', 'Android >= 4.0'],
            cascade: true,
            remove: true
        }))
        .pipe(sourcemaps.write('./maps'))
        .pipe(gulp.dest('dist/css/'))
})
gulp.task('revCss',['outCss'], function() {
    return gulp.src(paths.css)
        .pipe(minifycss())
        .pipe(rev())
        .pipe(gulp.dest('dist/css/'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/css/'))
})
gulp.task('revJs', function() {
    return gulp.src(paths.js)
        .pipe(concat('app.js'))
        .pipe(gulp.dest('dist/js'))
        .pipe(ngmin({
            dynamic: true
        }))
        .pipe(gulp.dest('dist/js'))
        .pipe(uglify())
        .pipe(rev())
        .pipe(gulp.dest('dist/js'))
        .pipe(rev.manifest())
        .pipe(gulp.dest('dist/js'))
})
gulp.task('collectorCssjs',['revCss','revJs'], function () {
    return gulp.src(['dist/**/*.json','index.html'])
        .pipe(revCollector({replaceReved: true}))
        .pipe(gulp.dest(''))
})
gulp.task('cleanCssjs', function() {
    return gulp.src(['dist/css/*.css','dist/js/*.js'], {read: false})
        .pipe(clean())
})
gulp.task('sprite', function () {
    var spriteData = gulp.src(paths.imageSprite).pipe(spritesmith({
        imgName: 'sprite.png',
        cssName: '_Sprite.scss',
        cssFormat: 'scss',
        padding: 10,
        retinaSrcFilter: paths.imageRetina,
        retinaImgName: 'sprite@2x.png',
        cssTemplate: 'src/scss/template/scss.template.handlebars',
        cssVarMap: function(sprite) {
            sprite.name = 'icon-' + sprite.name
        }
    }))
    var imgStream = spriteData.img
        .pipe(gulp.dest('src/images/'))
    var cssStream = spriteData.css
        .pipe(gulp.dest('src/scss/sprite/'))
    return merge(imgStream, cssStream)
})
gulp.task('miniImg', ['sprite'], function () {
    gulp.src(paths.image)
        .pipe(imagemin({
            optimizationLevel: 5, //类型：Number  默认：3  取值范围：0-7（优化等级）
            progressive: true, //类型：Boolean 默认：false 无损压缩jpg图片
            interlaced: true, //类型：Boolean 默认：false 隔行扫描gif进行渲染
            multipass: true //类型：Boolean 默认：false 多次优化svg直到完全优化
        }))
        .pipe(gulp.dest('dist/images/'))
})
gulp.task('miniHtml', function() {
    var options = {
        collapseWhitespace: true,
        collapseBooleanAttributes: true,
        removeComments: true,
        removeEmptyAttributes: true,
        removeScriptTypeAttributes: true,
        removeStyleLinkTypeAttributes: true,
        minifyJS: true,
        minifyCSS: true
    }
    gulp.src(paths.html)
        .pipe(htmlmin(options))
        .pipe(gulp.dest('./'))
})
gulp.task('default', ['cleanCssjs'], function() {
    gulp.start('collectorCssjs')
})