function searchByName()
{
    var name = $('#name').val();
    window.location = ROOT_URL+"/volunteer/searchByName?name="+name;
}
function searchByServiceFiled(serviceFiled)
{
    window.location = ROOT_URL+"/volunteer/searchByServiceField?serviceField="+serviceFiled;
}
function searchBySkill(skill)
{
    window.location = ROOT_URL+"/volunteer/searchBySkill?skill="+skill;
}

function searchByJob(job)
{
    window.location = ROOT_URL+"/volunteer/searchByJob?job="+job;
}
function searchByStatus(status)
{
    window.location = ROOT_URL+"/volunteer/searchByStatus?status="+status;
}
function create()
{
    window.location = ROOT_URL+"/volunteer/reg";
}
function importVolunteer()
{
    window.location = ROOT_URL+"/volunteer/importPage";
}
function exportVolunteer()
{
    var status = $("input[name='status']:checked").val();
    if(status == "undefined")
        status = 2;
    window.location = ROOT_URL+"/volunteer/excel?status="+status;
}

function freeze(id,status)
{
    var message = "";
    if(status ==2)
        message = "确定要解冻吗?";
    else
        message = "确定要冻结吗?";

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/volunteer/freeze";
        $.post(url,{"id":id,"status":status},function(data){
            alert(data.message);
            window.location.reload();
        },"json");
    }
}