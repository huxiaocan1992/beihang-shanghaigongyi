function searchByName()
{
    var name = $('#name').val();
    var url = ROOT_URL+"/group/searchVolunteer?name="+name;
    window.location=url;
}

function setAdmin(id,role)
{
    var message = "";
    if(role >0 )
        message = "确认要设为管理员吗?";
    else
        message = "确认要取消管理员吗?";

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/group/setAdmin";
        $.post(url,{"id":id,"role":role},function(data){
            alert(data.message);
            if(data.code == 0)
                $('#groupVolunteer_'+id).remove();
        },"json");
    }
}

function del(id)
{
    var message = "确认要取消挂靠吗?";

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/group/cancelJoinOrg";
        $.post(url,{"id":id},function(data){
            alert(data.message);
            $('#platformGroups_'+id).remove();
        },"json");
    }
}

function join()
{
    var message =  "确认要挂靠吗?";

    var platform = $('#platform').val();
    var parentCode = $('#parentCode').val();
    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/group/joinOrg";
        $.post(url,{"platform":platform,"parentCode":parentCode},function(data){
            alert(data.message);
            $('#myModal').modal('hide');
            window.location.reload();
        },"json");
    }
}


