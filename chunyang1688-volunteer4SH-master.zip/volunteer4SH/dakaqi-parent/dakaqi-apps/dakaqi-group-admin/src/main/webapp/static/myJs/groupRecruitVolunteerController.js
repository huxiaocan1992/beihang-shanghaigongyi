function verfier(id,status)
{
    var message = "确认要通过吗?";
    var cause = $('#cause').val();
    if(status == -1)
    {
        message = "确认要拒绝吗?";
        if(cause == null || ""==cause)
        {
            alert('拒绝理由不能为');
            return;
        }
    }

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/groupRecruitVolunteer/verfier";
        $.post(url, {"id":id,"status": status,"cause":cause}, function (result) {
            alert(result.message);
            if(result.code ==0)
                window.location.href = ROOT_URL+"/groupRecruitVolunteer?pageNumber=1&status=0";
        }, "json");
    }
}

function searchByStatus(status)
{
    window.location.href = ROOT_URL+"/groupRecruitVolunteer?pageNumber=1&status="+status;
}

function exportVolunteer(status)
{
    window.location = ROOT_URL+"/groupRecruitVolunteer/excel?status="+status;
}


//
//function join()
//{
//    var message =  "确认要挂靠吗?";
//
//    var platform = $('#platform').val();
//    var parentCode = $('#parentCode').val();
//    if(window.confirm(message) == true)
//    {
//        var url = ROOT_URL+"/group/joinOrg";
//        $.post(url,{"platform":platform,"parentCode":parentCode},function(data){
//            alert(data.message);
//            $('#myModal').modal('hide');
//            window.location.reload();
//        },"json");
//    }
//}


