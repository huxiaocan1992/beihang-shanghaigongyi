function searchActivity()
{
    var startDate = $('#startDate').val();
    var endDate = $('#endDate').val();
    var title = $('#title').val();
    var url = ROOT_URL+"/activity/search?title="+title+"&startDate="+startDate+"&endDate="+endDate;
    window.location=url;
}
function pubActivity(url)
{
    window.location=url;
}

function del(activityCode)
{
    var message = "确定要删除活动吗?";
    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/activity/delete";
        $.post(url,{"activityCode":activityCode},function(data){
            alert(data.message);
            $('#'+activityCode).remove();
        },"json");
    }
}