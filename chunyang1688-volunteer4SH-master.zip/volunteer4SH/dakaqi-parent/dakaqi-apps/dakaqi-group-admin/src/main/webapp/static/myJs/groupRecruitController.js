function addQuestion()
{
    var questions = $('#myQuestion').val();
    $('#questions').val(questions);
    if(questions==undefined || questions=="" || questions==null)
    {
        alert("招募问题不能为空");
        return false;
    }
    var array_ = questions.split(";");
    var text_ = "";
    for(var i=0;i<array_.length;i++)
    {
        var temp = "<li class=\"list-item\">"+array_[i]+"</li>";
        text_ = text_  + temp;
    }
    if("" != text_)
    {
        $('#question_list').html(text_);
    }
    $('#myModal').modal('hide');
}

function save()
{

    var id=$('#id').val();

    var title = $('#title').val();

    var stopDate = $('#stopDate').val();

    var needs = $('#needs').val();
    var linkman = $('#linkman').val();
    var phone = $('#phone').val();
    var job = $("#job").val();
    var skill = $("#skill").val();
    var serviceField = $("#serviceField").val();
    var img = $('#img').val();
    var demo = $('#demo').val();
    var questions =  $('#myQuestion').val();
    //alert(id + "," + title + "," +stopDate + "," + needs + "," + linkman + "," + phone + "," + job+ "," + skill + "," + serviceField + "," + img + "," + demo + ","  +questions);
    var url = ROOT_URL+"/groupRecruit/save";
    $.post(url,{"id":id,"title":title,"stopDate":stopDate,"needs":needs,"linkman":linkman,"phone":phone,"job":job,"skill":skill,"serviceField":serviceField,"img":img,"demo":demo,"questions":questions},function(data){
        alert(data.message);
        if(data.code == 0)
        {
            window.location.href = ROOT_URL+"/groupRecruit";
        }
    },"json");
}

function cancelRecruit(id)
{
    var message = "取消后不可以恢复,确认要取消吗?";

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/groupRecruit/cancel/"+id;
        $.post(url,{"id":id},function(data){
            alert(data.message);
            $('#groupRecruit_'+id).remove();
        },"json");
    }
}
function searchByTitle()
{
    var key = $('#key').val();
    window.location.href = ROOT_URL+"/groupRecruit/searchByTitle?key="+key;
}

function verfier(id,status)
{
    var message = "确认要通过吗?";
    var cause = $('#cause').val();
    if(status == -1)
    {
        message = "确认要拒绝吗?";
        if(cause == null || ""==cause)
        {
            alert('拒绝理由不能为');
            return;
        }
    }

    if(window.confirm(message) == true)
    {
        var url = ROOT_URL+"/groupRecruitVolunteer/verfier";
        $.post(url, {"id":id,"status": status,"cause":cause}, function (result) {
            alert(result.message);
            if(result.code ==0)
                window.location.href = ROOT_URL+"/groupRecruitVolunteer?pageNumber=1&status=0";
        }, "json");
    }
}

function searchByStatus(status)
{
    window.location.href = ROOT_URL+"/groupRecruitVolunteer?pageNumber=1&status="+status;
}

//
//function join()
//{
//    var message =  "确认要挂靠吗?";
//
//    var platform = $('#platform').val();
//    var parentCode = $('#parentCode').val();
//    if(window.confirm(message) == true)
//    {
//        var url = ROOT_URL+"/group/joinOrg";
//        $.post(url,{"platform":platform,"parentCode":parentCode},function(data){
//            alert(data.message);
//            $('#myModal').modal('hide');
//            window.location.reload();
//        },"json");
//    }
//}


