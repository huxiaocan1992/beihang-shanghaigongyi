package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

/**
 * Created by chunyang on 2016/5/9.
 */
@Data
public class BaseActivityVO
{
    /*************活动信息**************************************/
    private long   activityId;        //ID
    private String activityName;            //活动名称
    private String activityCode;    //活动CODE
    private String activityStartTime;
    private String activityEndTime;
    private String activityAddress;
    private String activityTags;
    private Double activityLng;
    private Double activityLat;
}
