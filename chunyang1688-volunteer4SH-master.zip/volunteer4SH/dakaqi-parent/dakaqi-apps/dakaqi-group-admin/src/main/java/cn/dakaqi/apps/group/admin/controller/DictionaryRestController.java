package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.utils.CodeMap;
import cn.dakaqi.utils.JsonResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/7.
 * 字典
 */
@RestController
@RequestMapping(value = "/api/v1/dictionary")
public class DictionaryRestController
{
    private static Logger logger = LoggerFactory.getLogger(DictionaryRestController.class);

    @RequestMapping(value = "/dictions", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> dictions()
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        resultMap.put("cardType", CodeMap.getCardType());
        resultMap.put("edutcation", CodeMap.getEdutcation());
        resultMap.put("userServiceFiled", CodeMap.getUserServiceFiled());
        resultMap.put("userSkill", CodeMap.getUserSkill());
        resultMap.put("userType", CodeMap.getUserType());
        resultMap.put("groupServiceFiled", CodeMap.getGroupServiceFiled());
        resultMap.put("parts", CodeMap.getMemberParts());
        resultMap.put("prvoinceCityDistr", CodeMap.getProvinceCityDistrict());
        resultMap.put("ActivityRecruitImg", CodeMap.getActivityRecruitImg());
        resultMap.put("GroupRecruitImg", CodeMap.getGroupRecruitImg());
        jsonResult.setData(resultMap);
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }

}
