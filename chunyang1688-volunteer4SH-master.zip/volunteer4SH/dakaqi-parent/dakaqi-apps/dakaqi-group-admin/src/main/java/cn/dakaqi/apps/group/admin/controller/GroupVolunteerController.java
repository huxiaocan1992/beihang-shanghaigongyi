package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.GroupVolunteer;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.GroupService;
import cn.dakaqi.services.GroupVolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springside.modules.web.MediaTypes;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by chunyang on 2016/5/12.
 */
@RestController
@RequestMapping(value = "/groupVolunteer")
public class GroupVolunteerController extends BaseController
{
    @Autowired
    GroupService groupService;
    @Autowired
    GroupVolunteerService groupVolunteerService;

    @Override
    protected ModelAndView initModelAndView(String groupCode, String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        return new ModelAndView(view, modelMap);
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {
    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView list(@RequestParam(value = "pageNumber",defaultValue = "1") int pageNumber,HttpServletRequest request)
    {
        String view = "groupVolunteer/wait";
        Group curGroup = getCurGroup(request);
        ModelAndView modelAndView = initModelAndView(curGroup.getGroupCode(), view,request);
        //查询当前社团的所有管理员
        Page<GroupVolunteer> data = this.groupVolunteerService.queryGroupCode(curGroup.getGroupCode(), DKQConstant.APPLY_STATUS,pageNumber);
        modelAndView.addObject("data",data);
        return modelAndView;
    }

    @RequestMapping(value = "/verfier", method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestParam("id") long id,@RequestParam("status") int status,@RequestParam(value = "refuseCase",required = false) String  refuseCase,HttpServletRequest request)
    {
        JsonResult jsonResult = new JsonResult();
        String message = "审核成功";
        try
        {
            volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
            this.groupVolunteerService.updateStatus(id,status,volunteer.getMemberCode(),refuseCase);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage(message);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            message = e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(message);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            message = "审核失败";
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(message);
        }

        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}
