package cn.dakaqi.apps.group.admin.cron.thread;


import cn.dakaqi.services.GroupMonthDataService;

/**
 * Created by chunyang on 2016/4/28.
 */
public class GroupMonthDataThread implements Runnable
{
    GroupMonthDataService groupMonthDataService;

    public GroupMonthDataThread(GroupMonthDataService groupMonthDataService)
    {
        this.groupMonthDataService = groupMonthDataService;
    }

    @Override
    public void run()
    {
        groupMonthDataService.statistics();
    }
}
