package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivitySignRecord;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class ActivitySignRecordVO  implements Serializable
{
    public static ActivitySignRecordVO buildVO(Volunteer volunteer,Activity activity,List<ActivitySignRecord> list)
    {
        ActivitySignRecordVO vo = new ActivitySignRecordVO();
        vo.setActivityLng(activity.getLng());
        vo.setActivityLat(activity.getLat());
        vo.setRealName(volunteer.getRealName());
        vo.setNickName(volunteer.getNickName());
        vo.setHeadUrl(volunteer.getHeadUrl());
        vo.setActivityName(activity.getName());
        vo.setActivityStartTime(activity.getStartTime());
        vo.setActivityEndTime(activity.getEndTime());
        vo.setActivityAddress(activity.getAddress());
        vo.setActivityScope(activity.getScope());
        if(null == list || list.size() == 0 || list.isEmpty())
        {
            vo.setInTime("");
            vo.setOutTime("");
        }
        else
        {
            vo.setInTime(DateUtil.DefaultTimeFormatter.format(list.get(0).getCreateTime()));

            try
            {
                if(list.size()>=2)
                {
                    vo.setOutTime(DateUtil.DefaultTimeFormatter.format(list.get(list.size() - 1).getCreateTime()));
                    vo.setTimes(DateUtil.countMinutes2(vo.getInTime(), vo.getOutTime()));
                }
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        return vo;
    }
    /***********志愿者信息***************/
    public String nickName;//昵称
    public String realName;//真实姓名
    public String headUrl;//头图

    /*************活动信息**************************************/
    private String activityName;            //活动名称
    private String activityStartTime;
    private String activityEndTime;
    private String activityAddress;
    private Double activityLng;
    private Double activityLat;
    private int    activityScope;
    /***************************签到/签退时间*********************/
    private int times;
    private String inTime;
    private String outTime;

}
