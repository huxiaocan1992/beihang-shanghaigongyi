package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.*;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

/**
 * Created by chunyang on 2016/5/11.
 */
@Data
public class SearchResultVO
{
    private String title;
    private String type;
    private String createTime;
    private String code;
    private long id;

    public static SearchResultVO buildActivity(Activity activity)
    {
        SearchResultVO vo = new SearchResultVO();
        vo.setTitle(activity.getName());
        vo.setId(activity.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activity.getCreateTime()));
        vo.setType("Activity");
        vo.setCode(activity.getActivityCode());
        return vo;
    }

    public static SearchResultVO buildGroup(Group group)
    {
        SearchResultVO vo = new SearchResultVO();
        vo.setTitle(group.getName());
        vo.setId(group.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(group.getCreateTime()));
        vo.setType("Group");
        vo.setCode(group.getGroupCode());
        return vo;
    }

    public static SearchResultVO buildTopic(SysTopic sysTopic)
    {
        SearchResultVO vo = new SearchResultVO();
        vo.setTitle(sysTopic.getTitle());
        vo.setId(sysTopic.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(sysTopic.getCreateTime()));
        vo.setType("SysTopic");
        vo.setCode(sysTopic.getCode());
        return vo;
    }

    public static SearchResultVO buildGroupRecruit(GroupRecruit groupRecruit)
    {
        SearchResultVO vo = new SearchResultVO();
        vo.setTitle(groupRecruit.getTitle());
        vo.setId(groupRecruit.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(groupRecruit.getCreateTime()));
        vo.setType("GroupRecruit");
        vo.setCode(String.valueOf(groupRecruit.getId()));
        return vo;
    }
    public static SearchResultVO buildActivityRecruit(ActivityRecruit activityRecruit)
    {
        SearchResultVO vo = new SearchResultVO();
        vo.setTitle(activityRecruit.getActivity().getName());
        vo.setId(activityRecruit.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activityRecruit.getCreateTime()));
        vo.setType("ActivityRecruit");
        vo.setCode(String.valueOf(activityRecruit.getId()));
        return vo;
    }

}
