package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.GroupRecruit;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class GroupRecruitVO extends BaseVolunteerVO implements Serializable
{

    public static GroupRecruitVO buildVO(GroupRecruit groupRecruit)
    {
        GroupRecruitVO vo = new GroupRecruitVO();
        vo.setTitle(groupRecruit.getTitle());
        vo.setDemo(groupRecruit.getDemo());
        vo.setStopApplyTime(DateUtil.DefaultTimeFormatter.format(groupRecruit.getStopApplyTime()));
        vo.setNeeds(groupRecruit.getNeeds());
        vo.setJob(groupRecruit.getJob());
        vo.setSkill(groupRecruit.getSkill());
        vo.setServiceField(groupRecruit.getServiceField());
        vo.setImg(groupRecruit.getImg());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(groupRecruit.getCreateTime()));
        vo.setTop(groupRecruit.getTop());
        vo.setApplys(groupRecruit.getApplys());
        vo.setQuestion(groupRecruit.getQuestion());
        vo.setStatus(groupRecruit.getStatus());

        vo.setVolunteerCode(groupRecruit.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(groupRecruit.getVolunteer().getId());
        vo.setRealName(groupRecruit.getVolunteer().getRealName());
        vo.setNickName(groupRecruit.getVolunteer().getNickName());
        vo.setMemberCode(groupRecruit.getVolunteer().getMemberCode());
        vo.setVolunteerCode(groupRecruit.getVolunteer().getVolunteerCode());
        vo.setHeadUrl(groupRecruit.getVolunteer().getHeadUrl());
        vo.setMobile(groupRecruit.getVolunteer().getMobile());

        vo.setQuestion(groupRecruit.getQuestion());
        vo.setOrgName(groupRecruit.getGroup().getName());
        vo.setPhone(groupRecruit.getGroup().getPhone());
        vo.setMonitor(groupRecruit.getGroup().getMonitor());


        vo.setBrowses(groupRecruit.getBrowses());
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            vo.setSurplusDays(DateUtil.countDay(new Date(), sdf.parse(groupRecruit.getStopApplyTime())));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        vo.setGroupName(groupRecruit.getGroup().getName());
        vo.setGroupCode(groupRecruit.getGroup().getGroupCode());
        vo.setGroupId(groupRecruit.getGroup().getId());

        return vo;
    }
    private long groupId;
    private String groupName;
    private String groupCode;
    private String title;
    private String demo;
    private String stopApplyTime;
    private int needs;
    private String job;
    private String skill;
    private String serviceField;
    private String img;
    private String createTime;
    private int top;//是否被置顶
    private int applys;//报名人数
    private String question;//问题列表
    private int status;//是否已结束
    private String orgName;
    private String phone;
    private String monitor;
    private long surplusDays;//剩余天数
    private String memberCode;
    private int browses;//浏览量
}
