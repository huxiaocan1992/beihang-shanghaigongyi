package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/9.
 */
@Data
public class BaseVolunteerVO implements Serializable
{
    /***********志愿者信息***************/
    private long   volunteerId; //ID编号
    private String volunteerCode;//志愿者一号通编号
    private String memberCode;//会员本地唯一编号
    private String mobile;//手机号
    private String nickName;//昵称
    private String realName;//真实姓名
    private String headUrl;//头图
    private String sign;    //签名
    private int isRealVerfier;     //是否已实名认证

}
