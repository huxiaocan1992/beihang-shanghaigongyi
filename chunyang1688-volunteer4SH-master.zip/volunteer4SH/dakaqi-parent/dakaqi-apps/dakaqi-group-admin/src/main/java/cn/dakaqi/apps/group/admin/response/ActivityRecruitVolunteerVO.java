package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivityRecruitVolunteer;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/11.
 * 活动招募报名名单
 */
@Data
public class ActivityRecruitVolunteerVO extends BaseVolunteerVO implements Serializable
{

    public static ActivityRecruitVolunteerVO buildVO(ActivityRecruitVolunteer activityRecruitVolunteer)
    {
        ActivityRecruitVolunteerVO vo = new ActivityRecruitVolunteerVO();
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activityRecruitVolunteer.getCreateTime()));
        vo.setVolunteerCode(activityRecruitVolunteer.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(activityRecruitVolunteer.getVolunteer().getId());
        vo.setRealName(activityRecruitVolunteer.getVolunteer().getRealName());
        vo.setNickName(activityRecruitVolunteer.getVolunteer().getNickName());
        vo.setMemberCode(activityRecruitVolunteer.getVolunteer().getMemberCode());
        vo.setVolunteerCode(activityRecruitVolunteer.getVolunteer().getVolunteerCode());
        vo.setHeadUrl(activityRecruitVolunteer.getVolunteer().getHeadUrl());
        vo.setMobile(activityRecruitVolunteer.getVolunteer().getMobile());
        vo.setIsRealVerfier(activityRecruitVolunteer.getVolunteer().getLocked());
        vo.setActivityRecruitVolunteerId(activityRecruitVolunteer.getId());
//        vo.setActivityName(activityRecruitVolunteer.getActivityRecruit().getActivity().getName());
//        vo.setActivityCode(activityRecruitVolunteer.getActivityRecruit().getActivity().getActivityCode());
//        vo.setActivityId(activityRecruitVolunteer.getActivityRecruit().getActivity().getId());
//        vo.setActivityLat(activityRecruitVolunteer.getActivityRecruit().getActivity().getLat());
//        vo.setActivityLng(activityRecruitVolunteer.getActivityRecruit().getActivity().getLng());
//        vo.setGroupName(activityRecruitVolunteer.getActivityRecruit().getActivity().getGroup().getName());
//        vo.setGroupCode(activityRecruitVolunteer.getActivityRecruit().getActivity().getGroup().getGroupCode());
//        vo.setGroupId(activityRecruitVolunteer.getActivityRecruit().getActivity().getGroup().getId());
//        vo.setGroupLog(activityRecruitVolunteer.getActivityRecruit().getActivity().getGroup().getLogo());
        vo.setStatus(activityRecruitVolunteer.getStatus());
        vo.setQuestion(activityRecruitVolunteer.getQuestion());
        vo.setAnswer(activityRecruitVolunteer.getAnswer());
        return vo;
    }
    int status;
    String createTime;
    private String question;    //问题
    private String answer;      //答案
    private long activityRecruitVolunteerId;
}
