package cn.dakaqi.apps.group.admin.response;

/**
 * Created by chunyang on 2016/6/21.
 */
public class MessageGroup
{
    private String code;
    private String name;

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public MessageGroup()
    {
    }

    public MessageGroup(String code, String name)
    {
        this.code = code;
        this.name = name;
    }
}
