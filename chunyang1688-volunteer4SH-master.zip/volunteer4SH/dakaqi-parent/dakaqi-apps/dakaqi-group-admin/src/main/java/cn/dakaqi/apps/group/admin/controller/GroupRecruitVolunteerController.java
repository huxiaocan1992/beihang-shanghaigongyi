package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.*;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.GroupRecruitVolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springside.modules.web.MediaTypes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chunyang on 2016/5/9.
 */
@Controller
@RequestMapping(value = "/groupRecruitVolunteer")
public class GroupRecruitVolunteerController extends BaseController
{
    @Autowired
    GroupRecruitVolunteerService groupRecruitVolunteerService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        return new ModelAndView(view,modelMap);
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView list(@RequestParam(value = "pageNumber",defaultValue = "1") int pageNumber,@RequestParam(value = "status",defaultValue = "0") int status,HttpServletRequest request)
    {
        String view = "groupRecruitVolunteer/wait";
        Group curGroup = getCurGroup(request);
        modelAndView = initModelAndView(curGroup.getGroupCode(), view,request);
        GroupRecruit groupRecruit = this.groupRecruitService.findLastByGroupCode(curGroup.getGroupCode(), DKQConstant.PROCEED_START);
        Page<GroupRecruitVolunteer> data = this.groupRecruitVolunteerService.findStatusByGroup(curGroup.getGroupCode(), status, pageNumber);
        modelAndView.addObject("data", data);
        modelAndView.addObject("groupRecruit", groupRecruit);
        modelAndView.addObject("status", status);
        return modelAndView;
    }
    @RequestMapping(value = "/detail/{groupRecruitVolunteerId}",method = RequestMethod.GET)
    public ModelAndView detail(@PathVariable("groupRecruitVolunteerId") long groupRecruitVolunteerId,HttpServletRequest request)
    {
        String view = "groupRecruitVolunteer/detail";
        Group curGroup = getCurGroup(request);
        modelAndView = initModelAndView(curGroup.getGroupCode(), view,request);
        GroupRecruitVolunteer groupRecruitVolunteer = this.groupRecruitVolunteerService.findOne(groupRecruitVolunteerId);
        modelAndView.addObject("groupRecruitVolunteer", groupRecruitVolunteer);
        return modelAndView;
    }
    @RequestMapping(value = "/verfier", method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestParam("id") Long id,@RequestParam("status") int status,@RequestParam(value = "cause",required = false) String cause,HttpServletRequest request)
    {
        JsonResult jsonResult = new JsonResult();
        String message = "审核成功";
        try
        {
            Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
            this.groupRecruitVolunteerService.updateVerfierStatus(id,volunteer.getMemberCode(),status,cause);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage(message);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            message = e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(message);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            message = "审核失败";
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(message);
        }

        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping("/excel")
    public String viewExcel(ModelMap modelMap,@RequestParam(value = "status",defaultValue = "2") int status,HttpServletRequest request,
                            HttpServletResponse response) {
        Group curGroup = getCurGroup(request);
        List<Volunteer> vos = new ArrayList<Volunteer>();
        Page<GroupRecruitVolunteer> data = this.groupRecruitVolunteerService.findStatusByGroup(curGroup.getGroupCode(), status, 1);
        if(null != data && data.getContent() != null && data.getContent().size()>0)
        {
            for(GroupRecruitVolunteer groupVolunteer:data.getContent())
            {
                vos.add(groupVolunteer.getVolunteer());
            }
            for(int i=2;i<=data.getTotalPages();i++)
            {
                data = groupRecruitVolunteerService.findStatusByGroup(curGroup.getGroupCode(), status,i);
                if(null != data && data.getContent() != null && data.getContent().size()>0)
                {
                    for(GroupRecruitVolunteer groupVolunteer:data.getContent())
                    {
                        vos.add(groupVolunteer.getVolunteer());
                    }
                }
            }
        }


        String[] title = new String [8];
        title[0] = "姓名";
        title[1] = "手机";
        title[2] = "性别";
        title[3] = "服务领域";
        title[4] = "职业";
        title[5] = "技能";
        title[6] = "证件类型";
        title[7] = "证件号";


        modelMap.put("list", vos);
        modelMap.put("fileName","志愿者信息.xls");
        modelMap.put("sheetName","志愿者信息");
        modelMap.put("title",title);
        return "volunteer-record-list";
    }

}
