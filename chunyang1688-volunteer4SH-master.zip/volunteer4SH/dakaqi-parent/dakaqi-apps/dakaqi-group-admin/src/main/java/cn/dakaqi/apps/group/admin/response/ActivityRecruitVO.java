package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivityRecruit;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by chunyang on 2016/5/11.
 * 活动招募信息
 */
@Data
public class ActivityRecruitVO extends BaseActivityVO implements Serializable
{
    static SimpleDateFormat DefaultTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    public static ActivityRecruitVO buildVO(ActivityRecruit activityRecruit)
    {
        ActivityRecruitVO vo = new ActivityRecruitVO();
        vo.setActivityRecruitId(activityRecruit.getId());
        vo.setActivityAddress(activityRecruit.getActivity().getAddress());
        vo.setActivityId(activityRecruit.getActivity().getId());
        vo.setActivityName(activityRecruit.getActivity().getName());
        vo.setActivityCode(activityRecruit.getActivity().getActivityCode());
        vo.setActivityEndTime(activityRecruit.getActivity().getEndTime());
        vo.setActivityStartTime(activityRecruit.getActivity().getStartTime());
        vo.setActivityTags(activityRecruit.getActivity().getTags());
        vo.setActivityLat(activityRecruit.getActivity().getLat());
        vo.setActivityLng(activityRecruit.getActivity().getLng());
        vo.setNeeds(activityRecruit.getNeeds());
        vo.setJob(activityRecruit.getJob());
        vo.setSkill(activityRecruit.getSkill());
        vo.setServiceField(activityRecruit.getServiceField());
        vo.setImg(activityRecruit.getImg());
        vo.setCreateTime(DefaultTimeFormatter.format(activityRecruit.getCreateTime()));
        vo.setStopTime(DefaultTimeFormatter.format(activityRecruit.getStopTime()));
        vo.setApplys(activityRecruit.getApplys());
        vo.setStatus(activityRecruit.getStatus());
        vo.setQuestion(activityRecruit.getQuestion());
        vo.setOrgName(activityRecruit.getActivity().getGroup().getName());
        vo.setPhone(activityRecruit.getActivity().getMonitor().getMobile());
        vo.setMonitor(activityRecruit.getActivity().getMonitor().getNickName());
        vo.setBrowses(activityRecruit.getBrowses());
        vo.setDemo(activityRecruit.getActivity().getDemo());
        vo.setWeekDay(activityRecruit.getActivity().getWeekDay());
        vo.setMonitorHead(activityRecruit.getActivity().getMonitor().getHeadUrl());
        vo.setMonitorRealName(activityRecruit.getActivity().getMonitor().getRealName());
        vo.setMonitorNickName(activityRecruit.getActivity().getMonitor().getNickName());
        vo.setUserId(activityRecruit.getActivity().getMonitor().getUserId());
        vo.setMemberCode(activityRecruit.getActivity().getMonitor().getMemberCode());
        vo.setGroupCode(activityRecruit.getActivity().getGroup().getGroupCode());
        try
        {
            vo.setSurplusDays(DateUtil.countDay(new Date(), activityRecruit.getStopTime()));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return vo;
    }
    private long activityRecruitId;
    private int needs;//需要人数
    private String job;//职业
    private String skill;//服务技能
    private String serviceField;//服务领域
    private String img;//封面图
    private String  createTime;//发布时间
    private String stopTime;//招募结束日期
    private int applys;//报名人数
    private String question;//问题列表
    private int status; //招募状态
    private String orgName;
    private String phone;
    private String monitor;
    private long surplusDays;//剩余天数
    private int browses;//
    private String demo;
    private String weekDay;
    private long userId;//活动现场人的USERID，用于消息通信
    private String  memberCode;
    private String monitorNickName;
    private String monitorRealName;
    private String monitorHead;
    private String groupCode;
}
