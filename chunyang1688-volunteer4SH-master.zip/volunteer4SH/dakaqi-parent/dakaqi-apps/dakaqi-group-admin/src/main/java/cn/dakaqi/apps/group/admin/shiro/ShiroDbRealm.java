/*******************************************************************************
 * Copyright (c) 2005, 2014 springside.github.io
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *******************************************************************************/
package cn.dakaqi.apps.group.admin.shiro;

import cn.dakaqi.entities.user.User;
import cn.dakaqi.services.user.UserService;
import com.google.common.base.Objects;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.Md5CredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import javax.annotation.PostConstruct;
import java.io.Serializable;

public class ShiroDbRealm extends AuthorizingRealm {

	protected UserService userService;


	/**
	 * 认证回调函数,登录时调用.
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
		UsernamePasswordToken token = (UsernamePasswordToken) authcToken;

		String username = token.getUsername();
		String password = String.valueOf(token.getPassword());
		//System.out.println("username------------------->" + token.getUsername());
		//System.out.println("password------------------->" + String.valueOf(token.getPassword()));
		//User user = userService.findByMobile(token.getUsername());
		User user = userService.login(username,password);
		if (user != null) {
			//System.out.println("------------> is not null ");
				return new SimpleAuthenticationInfo(new ShiroUser(user.getId(), user.getMobile(), user.getRealName()),user.getPassword(),getName());
		} else {
			//System.out.println("------------> is null ");
			return null;
		}
	}

//	@Override
//	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
//		UsernamePasswordToken token = (UsernamePasswordToken) authcToken;
//		User user = accountService.findByMobile(token.getUsername());
//		System.out.println(token.getUsername() + "----------->"+String.valueOf(token.getPassword()));
//		if (user != null) {
//			byte[] salt = Encodes.decodeHex(user.getSalt());
//			return new SimpleAuthenticationInfo(new ShiroUser(user.getId(), user.getMobile(), user.getRealName()),
//					user.getPassword(), ByteSource.Util.bytes(salt), getName());
//		} else {
//			return null;
//		}
//	}


	/**
	 * 授权查询回调函数, 进行鉴权但缓存中无用户的授权信息时调用.
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		ShiroUser shiroUser = (ShiroUser) principals.getPrimaryPrincipal();
		User user = userService.findByMobile(shiroUser.mobile);
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		info.addRoles(user.getRoleList());
		return info;
	}

	/**
	 * 设定Password校验的Hash算法与迭代次数.
	 */
	@PostConstruct
	public void initCredentialsMatcher() {
		Md5CredentialsMatcher matcher = new Md5CredentialsMatcher();
		setCredentialsMatcher(matcher);
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}


	@Override
	public void clearCachedAuthorizationInfo(PrincipalCollection principals) {
		super.clearCachedAuthorizationInfo(principals);
	}

	@Override
	public void clearCachedAuthenticationInfo(PrincipalCollection principals) {
		super.clearCachedAuthenticationInfo(principals);
	}

	@Override
	public void clearCache(PrincipalCollection principals) {
		super.clearCache(principals);
	}

	public void clearAllCachedAuthorizationInfo() {
		getAuthorizationCache().clear();
	}

	public void clearAllCachedAuthenticationInfo() {
		getAuthenticationCache().clear();
	}

	public void clearAllCache() {
		clearAllCachedAuthenticationInfo();
		clearAllCachedAuthorizationInfo();
	}

	/**
	 * 自定义Authentication对象，使得Subject除了携带用户的登录名外还可以携带更多信息.
	 */
	public static class ShiroUser implements Serializable {
		private static final long serialVersionUID = -1373760761780840081L;
		public Long id;
		public String mobile;
		public String realName;

		public ShiroUser(Long id, String mobile, String realName) {
			this.id = id;
			this.mobile = mobile;
			this.realName = realName;
		}

		public String getMobile()
		{
			return mobile;
		}

		public String getRealName()
		{
			return realName;
		}

		/**
		 * 本函数输出将作为默认的<shiro:principal/>输出.
		 */
		@Override
		public String toString() {
			return mobile;
		}

		/**
		 * 重载hashCode,只计算loginName;
		 */
		@Override
		public int hashCode() {
			return Objects.hashCode(mobile);
		}

		/**
		 * 重载equals,只计算loginName;
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			ShiroUser other = (ShiroUser) obj;
			if (mobile == null) {
				if (other.mobile != null) {
					return false;
				}
			} else if (!mobile.equals(other.mobile)) {
				return false;
			}
			return true;
		}
	}
}
