/*******************************************************************************
 * Copyright (c) 2005, 2014 springside.github.io
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *******************************************************************************/
package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.user.User;
import cn.dakaqi.services.user.UserService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springside.modules.web.MediaTypes;

import javax.validation.Valid;

/**
 * 用户注册的Controller.
 * 
 * @author chunyang
 */
@Controller
@RequestMapping(value = "/register")
public class RegisterController
{

	@Autowired
	private UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public String registerForm() {
		return "account/register";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String register(@Valid User user, RedirectAttributes redirectAttributes) {
		user.setEmail(user.getMobile()+"@dakaqi.cn");
		user.setPlatform(DKQConstant.USER_PLATFORM_WEB);
		user.setOldID(0L);
		//accountService.registerUser(user);
		userService.saveUser(user);
		redirectAttributes.addFlashAttribute("username", user.getMobile());
		return "redirect:/login";
	}

	@RequestMapping(value = "/sendCode/{mobile}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
	public ResponseEntity<?> sendCodeByRegister(@PathVariable("mobile") String mobile)
	{
		JsonResult result = new JsonResult();
		try
		{
			if(StringUtils.isBlank(mobile))
			{
				result.setMessage("手机不能为空");
				result.setCode(JsonResult.CODE_FAIL);
				return new ResponseEntity(result, HttpStatus.OK);
			}
			User user = this.userService.findByMobile(mobile);
			if(null != user)
			{
				result.setMessage("手机号已存在");
				result.setCode(JsonResult.CODE_FAIL);
				return new ResponseEntity(result,HttpStatus.OK);
			}
			this.userService.sendVerifierCode(mobile.trim());
			result.setCode(JsonResult.CODE_SUCCESS);
			result.setMessage("验证码已发送,请注意查收");
		}
		catch (ServiceRuntimeException e)
		{
			e.printStackTrace();
			result.setMessage(e.getMessage());
			result.setCode(JsonResult.CODE_FAIL);
			return new ResponseEntity(result,HttpStatus.OK);
		}
		return new ResponseEntity(result,HttpStatus.OK);
	}

	/**
	 * Ajax请求校验mobile是否唯一。
	 */
	@RequestMapping(value = "checkMobile")
	@ResponseBody
	public String checkMobile(@RequestParam("mobile") String mobile) {
		if (userService.findByMobile(mobile) == null) {
			return "true";
		} else {
			return "false";
		}
	}
}
