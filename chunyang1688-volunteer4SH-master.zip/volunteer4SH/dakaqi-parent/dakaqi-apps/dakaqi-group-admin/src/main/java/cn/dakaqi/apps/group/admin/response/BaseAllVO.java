package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

/**
 * Created by chunyang on 2016/5/9.
 */
@Data
public class BaseAllVO
{
    /***********志愿者信息***************/
    public long   volunteerId; //ID编号
    public String volunteerCode;//志愿者一号通编号
    public String memberCode;//会员本地唯一编号
    public String mobile;//手机号
    public String nickName;//昵称
    public String realName;//真实姓名
    public String headUrl;//头图
    private String sign;    //签名

    /*************社团信息*****************************/
    private long  groupId;
    private String groupName;
    private String groupCode;
    private String groupLog;

    /*************活动信息**************************************/
    private long   activityId;        //ID
    private String activityName;            //活动名称
    private String activityCode;    //活动CODE
    private String activityStartTime;
    private String activityEndTime;
    private String activityAddress;
    private String activityTags;
    private Double activityLng;
    private Double activityLat;

}
