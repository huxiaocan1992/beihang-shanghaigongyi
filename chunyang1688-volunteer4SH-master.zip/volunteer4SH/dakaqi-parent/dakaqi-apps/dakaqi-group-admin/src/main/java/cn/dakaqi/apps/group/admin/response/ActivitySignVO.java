package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.entities.ActivitySignRecord;
import cn.dakaqi.utils.DateUtil;
import cn.dakaqi.utils.latitude.LatitudeUtils;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class ActivitySignVO implements Serializable
{
    public static ActivitySignVO buildVO(ActivitySign activitySign,List<ActivitySignRecord> list)
    {
        ActivitySignVO vo = new ActivitySignVO();
        vo.setActivitySignId(activitySign.getId());
        vo.setActivityName(activitySign.getActivity().getName());
        vo.setNickName(activitySign.getVolunteer().getNickName());
        vo.setRealName(activitySign.getVolunteer().getRealName());
        vo.setHeadUrl(activitySign.getVolunteer().getHeadUrl());
        vo.setTimes(activitySign.getTimes());
        if(null != list && list.size()>=2)
        {
            vo.setInTime(DateUtil.DefaultTimeFormatter.format(list.get(0).getCreateTime()));
            vo.setInAddress(list.get(0).getAdress());
            vo.setInDistance(LatitudeUtils.GetDistance(activitySign.getActivity().getLng(), activitySign.getActivity().getLat(), list.get(0).getLng(), list.get(0).getLat()));
            vo.setOutTime(DateUtil.DefaultTimeFormatter.format(list.get(list.size()-1).getCreateTime()));
            vo.setOutAddress(list.get(list.size()-1).getAdress());
            vo.setOutDistance(LatitudeUtils.GetDistance(activitySign.getActivity().getLng(), activitySign.getActivity().getLat(), list.get(list.size() - 1).getLng(), list.get(list.size() - 1).getLat()));
        }
        else if(null != list && list.size() ==1)
        {
            vo.setInTime(DateUtil.DefaultTimeFormatter.format(list.get(0).getCreateTime()));
            vo.setInAddress(list.get(0).getAdress());
            vo.setInDistance(LatitudeUtils.GetDistance(activitySign.getActivity().getLng(), activitySign.getActivity().getLat(), list.get(0).getLng(), list.get(0).getLat()));

            vo.setOutTime("00:00");
            vo.setOutAddress("暂无签出");
            vo.setOutDistance(0.00);
        }
        return vo;
    }

    private long activitySignId;
    private String nickName;//昵称
    private String realName;//真实姓名
    private String headUrl;//头图
    private String inTime;//
    private String inAddress;
    private double inDistance;

    private String activityName;
    private String outTime;
    private String outAddress;
    private double outDistance;
    private int times;
}
