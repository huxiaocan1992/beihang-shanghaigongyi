package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.GroupRecruitVolunteer;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class GroupRecruitVolunteerVO extends BaseVolunteerVO implements Serializable
{

    public static GroupRecruitVolunteerVO buildVO(GroupRecruitVolunteer groupRecruitVolunteer)
    {
        GroupRecruitVolunteerVO vo = new GroupRecruitVolunteerVO();
        vo.setTitle(groupRecruitVolunteer.getGroupRecruit().getTitle());
        vo.setDemo(groupRecruitVolunteer.getGroupRecruit().getDemo());
        vo.setStopApplyTime(DateUtil.DefaultTimeFormatter.format(groupRecruitVolunteer.getGroupRecruit().getStopApplyTime()));
        vo.setNeeds(groupRecruitVolunteer.getGroupRecruit().getNeeds());
        vo.setJob(groupRecruitVolunteer.getGroupRecruit().getJob());
        vo.setSkill(groupRecruitVolunteer.getGroupRecruit().getSkill());
        vo.setServiceField(groupRecruitVolunteer.getGroupRecruit().getServiceField());
        vo.setImg(groupRecruitVolunteer.getGroupRecruit().getImg());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(groupRecruitVolunteer.getCreateTime()));
        vo.setTop(groupRecruitVolunteer.getGroupRecruit().getTop());
        vo.setApplys(groupRecruitVolunteer.getGroupRecruit().getApplys());
        vo.setQuestion(groupRecruitVolunteer.getGroupRecruit().getQuestion());
        vo.setStatus(groupRecruitVolunteer.getGroupRecruit().getStatus());
        vo.setVolunteerCode(groupRecruitVolunteer.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(groupRecruitVolunteer.getVolunteer().getId());
        vo.setRealName(groupRecruitVolunteer.getVolunteer().getRealName());
        vo.setNickName(groupRecruitVolunteer.getVolunteer().getNickName());
        vo.setMemberCode(groupRecruitVolunteer.getVolunteer().getMemberCode());
        vo.setVolunteerCode(groupRecruitVolunteer.getVolunteer().getVolunteerCode());
        vo.setHeadUrl(groupRecruitVolunteer.getVolunteer().getHeadUrl());
        vo.setMobile(groupRecruitVolunteer.getVolunteer().getMobile());
//        vo.setGroupName(groupRecruitVolunteer.getGroupRecruit().getGroup().getName());
//        vo.setGroupCode(groupRecruitVolunteer.getGroupRecruit().getGroup().getGroupCode());
//        vo.setGroupId(groupRecruitVolunteer.getGroupRecruit().getGroup().getId());
        vo.setAnswer(groupRecruitVolunteer.getAnswer());
        vo.setGroupRecruitVolunteerId(groupRecruitVolunteer.getId());
        return vo;
    }

    String answer;
    private long groupRecruitVolunteerId;
    private String title;
    private String demo;
    private String stopApplyTime;
    private int needs;
    private String job;
    private String skill;
    private String serviceField;
    private String img;
    private String createTime;
    private int top;//是否被置顶
    private int applys;//报名人数
    private String question;//问题列表
    private int status;//是否已结束
}
