package cn.dakaqi.apps.group.admin.utils;

import cn.dakaqi.utils.redis.RedisClientTemplate;
import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;

/**
 * Created by chunyang on 2016/5/12.
 */
@Component(value = "pageCahe")
public class PageCache implements DKQCacheManager
{

    @Autowired
    RedisClientTemplate redisClientTemplate;

    @Override
    public boolean exists(String key)
    {
        //return redisClientTemplate.hexists(key,"modelAndView");
        return false;
    }

    @Override
    public void setModelAndView(String key,Object object)
    {
        HashMap<String,String> map = new HashMap<String,String>();
        map.put("modelAndView", JSON.toJSONString(object));
        redisClientTemplate.hmset(key, map);
        redisClientTemplate.expire(key,3600);
    }

    @Override
    public ModelAndView getModelAndView(String key)
    {
        return JSON.parseObject(redisClientTemplate.hget(key,"modelAndView"),ModelAndView.class);
    }
}
