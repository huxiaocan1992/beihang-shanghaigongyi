package cn.dakaqi.apps.group.admin.utils;

import org.springframework.web.servlet.ModelAndView;

/**
 * Created by chunyang on 2016/5/12.
 */
public interface DKQCacheManager
{
    boolean exists(String key);
    void    setModelAndView(String key, Object object);
    ModelAndView getModelAndView(String key);
}
