package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivityDiary;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class GroupDiaryVO extends BaseVolunteerVO implements Serializable
{

    public static GroupDiaryVO buildVO(ActivityDiary activityDiary)
    {
        GroupDiaryVO vo = new GroupDiaryVO();
        vo.setMessage(activityDiary.getMessage());
        vo.setImgs(activityDiary.getImgs());
        vo.setVolunteerCode(activityDiary.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(activityDiary.getVolunteer().getId());
        vo.setRealName(activityDiary.getVolunteer().getRealName());
        vo.setNickName(activityDiary.getVolunteer().getNickName());
        vo.setMemberCode(activityDiary.getVolunteer().getMemberCode());
        vo.setVolunteerCode(activityDiary.getVolunteer().getVolunteerCode());
        vo.setHeadUrl(activityDiary.getVolunteer().getHeadUrl());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activityDiary.getCreateTime()));
        vo.setActivityName(activityDiary.getActivity().getName());
        vo.setActivityStartTime(activityDiary.getActivity().getStartTime());
        vo.setActivityEndTime(activityDiary.getActivity().getEndTime());
        vo.setActivityAddress(activityDiary.getActivity().getAddress());
        return vo;
    }
    private String message;
    private String imgs;
    private String createTime;

    private String activityName;            //活动名称
    private String activityStartTime;
    private String activityEndTime;
    private String activityAddress;
}
