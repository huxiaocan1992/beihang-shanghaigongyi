package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.GroupVolunteer;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * 志愿者加入的组织
 * Created by chunyang on 2016/5/5.
 */
@Data
public class GroupVolunteerVO extends BaseVolunteerVO implements Serializable
{
    public static GroupVolunteerVO buildVO(GroupVolunteer groupVolunteer)
    {
        GroupVolunteerVO vo = new GroupVolunteerVO();
        vo.setGroupVolunteerId(groupVolunteer.getId());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(groupVolunteer.getCreateTime()));
        vo.setRole(groupVolunteer.getRole());
        vo.setStatus(groupVolunteer.getStatus());
        vo.setDemo(groupVolunteer.getDemo());
        vo.setVolunteerId(groupVolunteer.getVolunteer().getId());
        vo.setRealName(groupVolunteer.getVolunteer().getRealName());
        vo.setNickName(groupVolunteer.getVolunteer().getNickName());
        vo.setHeadUrl(groupVolunteer.getVolunteer().getHeadUrl());
        vo.setMemberCode(groupVolunteer.getVolunteer().getMemberCode());
        vo.setActivitys(groupVolunteer.getVolunteer().getActs());
        vo.setTimes(groupVolunteer.getVolunteer().getTimes());
        vo.setLastJoinDay(groupVolunteer.getVolunteer().getLastJoinActDate());
        vo.setGroupId(groupVolunteer.getGroup().getId());
        vo.setGroupCode(groupVolunteer.getGroup().getGroupCode());
        vo.setGroupName(groupVolunteer.getGroup().getName());
        vo.setGroupLog(groupVolunteer.getGroup().getLogo());
        return vo;
    }

    private long groupVolunteerId;
    private long  groupId;
    private String groupName;
    private String groupCode;
    private String groupLog;

    private int role;              //身份
    private int status;             //审核状态
    private String createTime;      //加入日期
    private String demo;            //备注
    private int activitys;          //个人累计活动数
    private long times;             //个人累计时间
    private String lastJoinDay;     //最后一次参加活动的时间

}
