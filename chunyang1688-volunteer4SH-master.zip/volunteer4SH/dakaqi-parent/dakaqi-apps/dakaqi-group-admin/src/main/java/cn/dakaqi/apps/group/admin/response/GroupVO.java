package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.Group;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class GroupVO implements Serializable
{
    public static GroupVO buildVO(Group group)
    {
        GroupVO vo = new GroupVO();
        vo.setGroupId(group.getId());
        vo.setName(group.getName());
        vo.setGroupCode(group.getGroupCode());
        vo.setLogo(group.getLogo());
        vo.setTimes(group.getTimes());
        vo.setVolunteers(group.getVolunteers());
        vo.setActivitys(group.getActvitys());
        vo.setLiveness(group.getLiveness());
        vo.setDemo(group.getDemo());
        vo.setServiceField(group.getServiceField());
        vo.setSetupDate(group.getSetupDate());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(group.getCreateTime()));
        vo.setRegAddress(group.getRegAddress());
        vo.setMonitor(group.getMonitor());
        vo.setGoodComment(group.getGoodComment());
        vo.setMediumComment(group.getMediumComment());
        vo.setBadComment(group.getBadComment());
        vo.setPrvoince(group.getProvince());
        vo.setCity(group.getCity());
        vo.setDistrict(group.getDistrict());
        vo.setPhone(group.getPhone());
        vo.setPlatform(group.getPlatform());
        vo.setStartActs(0);
        vo.setVolunteerCode(group.getCreateUser().getVolunteerCode());
        vo.setVolunteerId(group.getCreateUser().getId());
        vo.setRealName(group.getCreateUser().getRealName());
        vo.setNickName(group.getCreateUser().getNickName());
        vo.setMemberCode(group.getCreateUser().getMemberCode());
        vo.setVolunteerCode(group.getCreateUser().getVolunteerCode());
        vo.setHeadUrl(group.getCreateUser().getHeadUrl());
        vo.setCoverImg("http://img.dakaqi.cn/cover_org_default.png");
        vo.setUserId(group.getCreateUser().getUserId());
        return vo;
    }
    private long groupId;
    private String name;
    private String groupCode;
    private String logo;
    private long times;//公益时间
    private int volunteers;//成员量
    private int activitys;//活动量
    private int liveness;//活跃度
    private String demo;//简介
    private String serviceField;//服务领域
    private String setupDate;//成立日期
    private String createTime;//入驻日期
    private String regAddress;//注册地
    private String monitor;//负责人
    private int goodComment;//好评
    private int mediumComment;//中评
    private int badComment;//差评
    private String prvoince;//省
    private String city;//市
    private String district;//区县
    private String phone;//联系电话
    private int waiteVerifers;//待审核人数
    private int waiteRecruits;//招募待审核人数
    private int role;//个人在当前组织中是什么身份
    private int startActs;//进行中的活动数量
    private String coverImg;        //封面图
    private String platform;//挂靠到哪些平台
    //创建者信息
    private long volunteerId;
    private String realName;
    private String nickName;
    private String memberCode;
    private String volunteerCode;
    private String headUrl;
    private long userId;      //创建者的userId，用于消息通信
}
