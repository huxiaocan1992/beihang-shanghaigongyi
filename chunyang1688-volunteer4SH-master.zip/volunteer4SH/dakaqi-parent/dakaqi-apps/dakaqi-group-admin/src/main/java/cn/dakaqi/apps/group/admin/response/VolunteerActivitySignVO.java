package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivitySign;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class VolunteerActivitySignVO implements Serializable
{
    public static VolunteerActivitySignVO buildVO(ActivitySign activitySign,long allTimes,long yearTime,long monthTimes)
    {
        VolunteerActivitySignVO vo = new VolunteerActivitySignVO();
        vo.setActivityName(activitySign.getActivity().getName());
        vo.setActivityStartDate(activitySign.getActivity().getStartTime());
        vo.setActivityEndDate(activitySign.getActivity().getEndTime());
        vo.setTimes(activitySign.getTimes());
        vo.setTags(activitySign.getActivity().getTags());
        vo.setAllTimes(allTimes);
        vo.setYearTimes(yearTime);
        vo.setMonthTime(monthTimes);
        vo.setRecordId(activitySign.getRecordId());
        return vo;
    }

    private long recordId;
    private String activityName;
    private String activityStartDate;
    private String activityEndDate;
    private int times;
    private String tags;
    private long allTimes;
    private long yearTimes;
    private long monthTime;

}
