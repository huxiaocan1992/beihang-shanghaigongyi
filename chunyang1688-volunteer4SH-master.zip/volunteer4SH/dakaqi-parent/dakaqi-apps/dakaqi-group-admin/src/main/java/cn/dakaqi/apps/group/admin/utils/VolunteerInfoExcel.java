package cn.dakaqi.apps.group.admin.utils;

import cn.dakaqi.entities.user.Volunteer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chunyang on 2016/5/29.
 */
public class VolunteerInfoExcel
{
    public static List<Volunteer> importVolunteerInfo(File file, HttpServletRequest request)
    {
        try
        {
            // 创建需要批量插入数据集合
            List<Volunteer> list = new ArrayList<Volunteer>();
            // 创建一个FileInputStream 文件输入流
            FileInputStream inputStream = new FileInputStream(file);
            // 创建对Excel工作簿文件的引用
            Workbook wookbook = null;
            String name = file.getName();
            String fileType = name.substring(name.lastIndexOf(".") + 1,
                    name.length());
            if (fileType.equals("xlsx"))
            {
                wookbook = new XSSFWorkbook(inputStream);
            } else if (fileType.equals("xls"))
            {
                wookbook = new HSSFWorkbook(inputStream);
            }
            // 在Excel文档中，第一张工作表的缺省索引是0
            Sheet sheet = wookbook.getSheetAt(0);
            // 获取到Excel文件中的所有行数
            int rows = sheet.getPhysicalNumberOfRows();
            // 遍历行 从第二行开始遍历
            for (int i = 1; i < rows; i++)
            {
                // 读取左上端单元格
                Row row = sheet.getRow(i);
                // 行不为空
                if (row != null)
                {
                    // 创建对象
                    Volunteer volunteer = new Volunteer();
                    row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setRealName(String.valueOf(row.getCell(0).getStringCellValue()).trim());
                    System.out.println(volunteer.getRealName());

                    row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setCardNO(String.valueOf(row.getCell(1).getStringCellValue()).trim());
                    System.out.println(volunteer.getCardNO());

                    row.getCell(2).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setMobile(String.valueOf(row.getCell(2).getStringCellValue()).trim());
                    System.out.println(volunteer.getMobile());

                    row.getCell(3).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setSex(String.valueOf(row.getCell(3).getStringCellValue()).trim());
                    System.out.println(volunteer.getSex());

                    row.getCell(4).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setProvince(String.valueOf(row.getCell(4).getStringCellValue()).trim());
                    System.out.println(volunteer.getProvince());

                    row.getCell(5).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setCity(String.valueOf(row.getCell(5).getStringCellValue()).trim());
                    System.out.println(volunteer.getCity());

                    row.getCell(6).setCellType(Cell.CELL_TYPE_STRING);
                    volunteer.setDistrict(String.valueOf(row.getCell(6).getStringCellValue()).trim());
                    System.out.println(volunteer.getDistrict());


                    list.add(volunteer);

//                    object.setRow(i + 1);
//                    object.setCommunityName((row.getCell(0).getStringCellValue()).trim());// 获取小区名称
//                    object.setHomeAddress((row.getCell(1).getStringCellValue()).trim());// 获取房屋信息
//                    // 设置姓名
//                    Cell nameCell = row.getCell(2);
//                    if (nameCell != null && !nameCell.equals(""))
//                    {
//                        nameCell.setCellType(Cell.CELL_TYPE_STRING);
//                        String bname = nameCell.getStringCellValue().trim();
//                        if (bname != null && StringUtils.isEmpty(bname))
//                        {
//                            object.setName(bname);
//                        }
//                    }
//                    // 设置性别
//                    Cell sexCell = row.getCell(3);
//                    if (sexCell != null && !sexCell.equals(""))
//                    {
//                        sexCell.setCellType(Cell.CELL_TYPE_STRING);
//                        String sex = sexCell.getStringCellValue().trim();
//                        if (sex.equals("男") || sex.equals("女"))
//                        {
//                            object.setSex(sex);
//                        }
//
//                    }
//                    Cell homeAreaCell = row.getCell(4);
//                    if (homeAreaCell != null && !homeAreaCell.equals(""))
//                    {
//                        homeAreaCell.setCellType(Cell.CELL_TYPE_STRING);
//                        String homeAreaString = homeAreaCell
//                                .getStringCellValue().trim();
//                        if (!homeAreaString.equals(""))
//                        {
//                            try
//                            {
//                                Float homeArea = Float.parseFloat(homeAreaString);
//                                object.setHomeArea(homeArea);
//                            } catch (NumberFormatException e)
//                            {
//                                object.setHomeArea(null);
//                            }
//                        }
//                    }
//                    Cell mobileCell = row.getCell(5);
//                    if (mobileCell != null && !(mobileCell.equals("")))
//                    {
//                        mobileCell.setCellType(Cell.CELL_TYPE_STRING);
//                        String mobile = mobileCell.getStringCellValue().trim();
//                        if (!mobile.equals(""))
//                        {
//                            object.setPhone(mobile);
//                        }
//                    }
//                    // 将对象增加到集合中
//                    list.add(object);
                }
            }
            // 返回集合
            return list;
        } catch (IOException e)
        {
            //logger.error("创建导入excel对象报错！", e);
        }
        return null;
    }

//根据byte[]获取file

    /**
     * 根据字节数组获取File
     *
     * @param b          字节数组
     * @param outputFile 输出的路径(保存路径)
     * @return
     */
    public static File getFileFromBytes(byte[] b, String outputFile)
    {
        BufferedOutputStream stream = null;
        File file = null;
        try
        {
            file = new File(outputFile);
            FileOutputStream fstream = new FileOutputStream(file);
            stream = new BufferedOutputStream(fstream);
            stream.write(b);
        } catch (Exception e)
        {
            //logger.error("文件保存出错",e);
        } finally
        {
            if (stream != null)
            {
                try
                {
                    stream.close();
                } catch (IOException e1)
                {
                    //logger.error("文件流关闭出错",e1);
                }
            }
        }
        return file;
    }
}
