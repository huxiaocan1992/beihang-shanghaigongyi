package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.SysTopicComment;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class SysTopicCommentVO extends BaseVolunteerVO implements Serializable
{
    public static SysTopicCommentVO buildVO(SysTopicComment sysTopicComment)
    {
        SysTopicCommentVO vo = new SysTopicCommentVO();
        vo.setVolunteerId(sysTopicComment.getVolunteer().getId());
        vo.setHeadUrl(sysTopicComment.getVolunteer().getHeadUrl());
        vo.setVolunteerCode(sysTopicComment.getVolunteer().getVolunteerCode());
        vo.setMemberCode(sysTopicComment.getVolunteer().getMemberCode());
        vo.setVolunteerId(sysTopicComment.getVolunteer().getId());
        vo.setNickName(sysTopicComment.getVolunteer().getNickName());
        vo.setRealName(sysTopicComment.getVolunteer().getRealName());
        vo.setDemo(sysTopicComment.getDemo());
        vo.setCode(sysTopicComment.getSysTopic().getCode());
        vo.setTitle(sysTopicComment.getSysTopic().getTitle());
        vo.setIntro(sysTopicComment.getSysTopic().getIntro());
        vo.setBackground(sysTopicComment.getSysTopic().getBackground());
        vo.setBrowses(sysTopicComment.getSysTopic().getBrowses());
        vo.setParticipants(sysTopicComment.getSysTopic().getParticipants());
        vo.setPromulgator(sysTopicComment.getSysTopic().getPromulgator());
        vo.setGoods(sysTopicComment.getSysTopic().getGoods());
        vo.setComments(sysTopicComment.getSysTopic().getComments());
        vo.setTags(sysTopicComment.getSysTopic().getTags());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(sysTopicComment.getCreateTime()));
        return vo;
    }
    private String demo;//评论内容
    private String code;//编码
    private String title;//标题
    private String intro;//简介
    private String background;//背景图
    private int browses;//浏览量
    private int participants;//参与人数
    private int goods;//获得的赞数
    private int comments;//评论数
    private String promulgator;//发布人
    private String tags;//本话题对应该的标签
    private String createTime;//评论时间
}
