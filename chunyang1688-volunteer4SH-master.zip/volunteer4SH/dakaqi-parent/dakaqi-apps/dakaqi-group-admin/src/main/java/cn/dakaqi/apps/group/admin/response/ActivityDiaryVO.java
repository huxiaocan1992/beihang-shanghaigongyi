package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivityDiary;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class ActivityDiaryVO extends BaseVolunteerVO implements Serializable
{

    public static ActivityDiaryVO buildVO(ActivityDiary activityDiary)
    {
        ActivityDiaryVO vo = new ActivityDiaryVO();
        vo.setMessage(activityDiary.getMessage());
        vo.setImgs(activityDiary.getImgs());
        vo.setVolunteerCode(activityDiary.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(activityDiary.getVolunteer().getId());
        vo.setRealName(activityDiary.getVolunteer().getRealName());
        vo.setNickName(activityDiary.getVolunteer().getNickName());
        vo.setMemberCode(activityDiary.getVolunteer().getMemberCode());
        vo.setVolunteerCode(activityDiary.getVolunteer().getVolunteerCode());
        vo.setHeadUrl(activityDiary.getVolunteer().getHeadUrl());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activityDiary.getCreateTime()));
        vo.setActivityName(activityDiary.getActivity().getName());
        vo.setActivityCode(activityDiary.getActivity().getActivityCode());
        vo.setActivityId(activityDiary.getActivity().getId());
        vo.setActivityLat(activityDiary.getActivity().getLat());
        vo.setActivityLng(activityDiary.getActivity().getLng());
//        vo.setGroupName(activityDiary.getGroup().getName());
//        vo.setGroupCode(activityDiary.getGroup().getGroupCode());
//        vo.setGroupId(activityDiary.getGroup().getId());
//        vo.setGroupLog(activityDiary.getGroup().getLogo());
        return vo;
    }
    private String message;
    private String imgs;
    private String createTime;

    private long   activityId;        //ID
    private String activityName;            //活动名称
    private String activityCode;    //活动CODE
    private String activityStartTime;
    private String activityEndTime;
    private String activityAddress;
    private String activityTags;
    private Double activityLng;
    private Double activityLat;

}
