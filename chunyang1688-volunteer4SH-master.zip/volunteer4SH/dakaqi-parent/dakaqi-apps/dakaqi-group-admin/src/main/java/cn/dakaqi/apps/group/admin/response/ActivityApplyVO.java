package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.ActivityApply;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ActivityApplyVO extends BaseVolunteerVO implements Serializable
{
    public static ActivityApplyVO buildVO(ActivityApply activityApply)
    {
        ActivityApplyVO vo = new ActivityApplyVO();
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(activityApply.getCreateTime()));
        vo.setStatus(activityApply.getStatus());
        vo.setRole(activityApply.getRole());
        //会员
        vo.setVolunteerCode(activityApply.getVolunteer().getVolunteerCode());
        vo.setVolunteerId(activityApply.getVolunteer().getId());
        vo.setMemberCode(activityApply.getVolunteer().getMemberCode());
        vo.setNickName(activityApply.getVolunteer().getNickName());
        vo.setRealName(activityApply.getVolunteer().getRealName());
        vo.setHeadUrl(activityApply.getVolunteer().getHeadUrl());
        vo.setMobile(activityApply.getVolunteer().getMobile());
        vo.setDemo("非本社团成员");
//        //活动
//        vo.setActivityCode(activityApply.getActivity().getActivityCode());
//        vo.setActivityId(activityApply.getActivity().getId());
//        vo.setActivityName(activityApply.getActivity().getName());
        return vo;
    }
    private String createTime;        //报名日期
    private int status;             //审核状态
    private int role;               //本次活动中的身份
    private String demo;            //成员备注
}
