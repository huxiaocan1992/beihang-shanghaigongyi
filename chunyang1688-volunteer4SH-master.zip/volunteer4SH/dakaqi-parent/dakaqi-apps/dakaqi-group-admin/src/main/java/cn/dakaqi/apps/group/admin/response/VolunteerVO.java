package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.user.Volunteer;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class VolunteerVO implements Serializable
{
    public static VolunteerVO buildVO(Volunteer volunteer)
    {
        VolunteerVO vo = new VolunteerVO();
        vo.setVolunteerCode(volunteer.getVolunteerCode());
        vo.setMemberCode(volunteer.getMemberCode());
        vo.setMobile(volunteer.getMobile());
        vo.setNickName(volunteer.getNickName());
        vo.setRealName(volunteer.getRealName());
        vo.setHeadUrl(volunteer.getHeadUrl());
        vo.setProvince(volunteer.getProvince());
        vo.setCity(volunteer.getCity());
        vo.setDistrict(volunteer.getDistrict());
        vo.setCardType(volunteer.getCardType());
        vo.setCardNO(volunteer.getCardNO());
        vo.setResidenceAddress(volunteer.getResidenceAddress());
        vo.setJob(volunteer.getJob());
        vo.setServiceField(volunteer.getServiceField());
        vo.setSkill(volunteer.getSkill());
        vo.setQQ(volunteer.getQQ());
        vo.setWeChat(volunteer.getWeChat());
        vo.setSign(volunteer.getSign());
        vo.setTimes(volunteer.getTimes());
        vo.setLocked(volunteer.getLocked());
        vo.setSex(volunteer.getSex());
        vo.setBirthDay(volunteer.getBirthDay());
        vo.setEducation(volunteer.getEducation());
        vo.setRank(volunteer.getRank());
        vo.setNativePlace(volunteer.getNativePlace());
        vo.setNation(volunteer.getNation());
        vo.setType(volunteer.getType());
        vo.setUserId(volunteer.getUserId());
        vo.setVolunteerId(volunteer.getId());
        return vo;
    }
    private long   volunteerId;
    private String volunteerCode;//志愿者一号通编号
    private String memberCode;//会员本地唯一编号
    private String mobile;//手机号
    private String nickName;//昵称
    private String realName;//真实姓名
    private String headUrl;//头图
    private String province;//省市
    private String city;//城市
    private String district;//区县
    private String cardType;//证件类型
    private String cardNO;//证件号
    private String residenceAddress;//现居住地
    private String job;//工作
    private String serviceField;//服务领域
    private String skill;//服务技能
    private String QQ;//QQ号
    private String sign;//个人签名
    private String weChat;//微信号
    private long times;//公益时间
    private int locked;//是否被锁定
    private String sex;//性别
    private String birthDay;//生日
    private String education;//文化成度
    private int rank;   //排名
    private String nation;//民族
    private String nativePlace;//籍贯
    private String type; //用户类型
    private long goods;//好评论数
    private long mids;//中评论数
    private long bads;//差评论数
    private long lives;//活跨度
    private int realNameVerifer;//是否已实名认证
    private long userId;
}
