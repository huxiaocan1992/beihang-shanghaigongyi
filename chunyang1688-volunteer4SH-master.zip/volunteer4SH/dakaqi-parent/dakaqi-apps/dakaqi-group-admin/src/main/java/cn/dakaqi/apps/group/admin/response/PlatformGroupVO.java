package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

/**
 * Created by chunyang on 2016/6/14.
 */
@Data
public class PlatformGroupVO
{
    private String parentCode;
    private String parentName;
    private Long platformId;
    private String platformName;
    private int status;
}
