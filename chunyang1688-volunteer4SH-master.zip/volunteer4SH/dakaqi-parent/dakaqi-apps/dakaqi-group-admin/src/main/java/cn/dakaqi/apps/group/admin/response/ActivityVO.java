package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by chunyang on 2016/5/5.
 * 活动信息
 */
@Data
public class ActivityVO implements Serializable
{
    static SimpleDateFormat DefaultTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public static ActivityVO buildVO(Activity activity)
    {
        ActivityVO vo = new ActivityVO();
        vo.setName(activity.getName());
        vo.setRole(0);
        vo.setActivityCode(activity.getActivityCode());
        vo.setDemo(activity.getDemo());
        vo.setImgs(activity.getImgs());
        vo.setStartTime(activity.getStartTime());
        vo.setEndTime(activity.getEndTime());
        vo.setType(activity.getType());
        vo.setAddress(activity.getAddress());
        vo.setTags(activity.getTags());
        vo.setWeekDay(activity.getWeekDay());
        vo.setNeeds(activity.getNeeds());
        vo.setScope(activity.getScope());
        vo.setTimes(activity.getTimes());
        vo.setLocked(activity.getLocked());
        vo.setApplys(activity.getApplys());
        vo.setAttends(activity.getAttends());
        vo.setProvince(activity.getProvince());
        vo.setCity(activity.getCity());
        vo.setDistrict(activity.getDistrict());
        vo.setCreateTime(DefaultTimeFormatter.format(activity.getCreateTime()));
        vo.setGoodComments(activity.getGoodComments());
        vo.setMidComments(activity.getMidComments());
        vo.setBadComments(activity.getBadComments());
        vo.setLng(activity.getLng());
        vo.setLat(activity.getLat());
        vo.setSkill(activity.getSkill());
        vo.setGroupName(activity.getGroup().getName());
        vo.setGroupId(activity.getGroup().getId());
        vo.setGroupCode(activity.getGroup().getGroupCode());
        vo.setCreateUserRealName(activity.getCreateUser().getRealName());
        vo.setCreateUserHead(activity.getCreateUser().getHeadUrl());
        vo.setCreateUserNickName(activity.getCreateUser().getNickName());
        vo.setCreateUserMemberCode(activity.getCreateUser().getMemberCode());
        vo.setMonitorHead(activity.getMonitor().getHeadUrl());
        vo.setMonitorMebmerCode(activity.getMonitor().getMemberCode());
        vo.setMonitorNickName(activity.getMonitor().getNickName());
        vo.setMonitorRealName(activity.getMonitor().getRealName());
        vo.setCoverImg("http://img.dakaqi.cn/cover_act_default.png");
        vo.setBrowses(activity.getBrowses());
        vo.setMonitorPhone(activity.getMonitor().getMobile());
        vo.setUserId(activity.getMonitor().getUserId());
        vo.setCreateUserId(activity.getCreateUser().getUserId());
        vo.setMemberCode(activity.getMonitor().getMemberCode());
        vo.setDetailUrl("http://wap.dakaqi.cn/h5/ActivityInfo.html?memberCode=null&activityCode="+activity.getActivityCode());
        try
        {
            vo.setSurplusDays(DateUtil.countDay(new Date(), DefaultTimeFormatter.parse(activity.getEndTime())));
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return vo;
    }

    private String name;            //活动名称
    private String activityCode;    //活动CODE
    private String demo;            //活动简单
    private String imgs;            //图片
    private String startTime;       //开始日期
    private String endTime;         //结束日期
    private int type;               //活动开展类型
    private String address;         //活动地址
    private String tags;            //标签
    private String weekDay;         //周期
    private int needs;              //所需人数
    private int scope;              //签到误差范围
    private long times;              //累计产生的公益时间
    private int locked;             //是否已被封存
    private int applys;             //报名数
    private int attends;            //参加人数
    private String province;        //省市
    private String city;            //城市
    private String district;        //区县
    private String createTime;        //发布日期
    private int goodComments;       //好评
    private int midComments;        //中评
    private int badComments;        //差评
    private Double lng;             //活动经度
    private Double lat;             //活动纬度
    private int role;               //当前用户在当前活动的角色 0志愿者 1活动负责人 2活动发布者
    private String coverImg;        //活动封面图
    private String groupName;       //社团名称
    private long groupId;           //社团ID
    private String groupCode;       //社团编号
    private String createUserNickName;//活动发布者昵称
    private String createUserRealName;//活动发布者真实姓名
    private String createUserMemberCode;//活动发布者编号
    private String createUserHead;      //活动发布者头像
    private long createUserId;      //活动发布者的userId，用于消息通信
    private String monitorNickName;     //活动负责人昵称
    private String monitorRealName;//活动负责人真实姓名
    private String monitorMebmerCode;//活动负责人编号
    private String monitorHead;//活动负责人头像
    private long userId;//活动负责人的userId，用于消息通信
    private String monitorPhone;//活动负责人电话
    private String memberCode;
    private int browses;//浏览量
    private long surplusDays;//剩余天数
    private int isRecruit;//当前活动是否发布了招募
    private String skill;//活动需要的服务技能
    private int isApply = -10;//当前用户是否报名本次活动
    private String detailUrl;//活动分享出去的时的地址

    public ActivityVO()
    {
    }


}
