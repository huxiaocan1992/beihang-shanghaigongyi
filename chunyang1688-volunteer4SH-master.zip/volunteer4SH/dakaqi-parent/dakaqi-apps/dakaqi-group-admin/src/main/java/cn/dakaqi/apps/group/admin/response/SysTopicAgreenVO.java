package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.SysTopicAgreen;
import cn.dakaqi.utils.DateUtil;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by chunyang on 2016/5/5.
 */
@Data
public class SysTopicAgreenVO extends BaseVolunteerVO implements Serializable
{
    public static SysTopicAgreenVO buildVO(SysTopicAgreen sysTopicAgreen)
    {
        SysTopicAgreenVO vo = new SysTopicAgreenVO();
        vo.setVolunteerId(sysTopicAgreen.getVolunteer().getId());
        vo.setHeadUrl(sysTopicAgreen.getVolunteer().getHeadUrl());
        vo.setVolunteerCode(sysTopicAgreen.getVolunteer().getVolunteerCode());
        vo.setMemberCode(sysTopicAgreen.getVolunteer().getMemberCode());
        vo.setVolunteerId(sysTopicAgreen.getVolunteer().getId());
        vo.setNickName(sysTopicAgreen.getVolunteer().getNickName());
        vo.setRealName(sysTopicAgreen.getVolunteer().getRealName());
        vo.setType(sysTopicAgreen.getType());
        vo.setCode(sysTopicAgreen.getSysTopic().getCode());
        vo.setTitle(sysTopicAgreen.getSysTopic().getTitle());
        vo.setIntro(sysTopicAgreen.getSysTopic().getIntro());
        vo.setBackground(sysTopicAgreen.getSysTopic().getBackground());
        vo.setBrowses(sysTopicAgreen.getSysTopic().getBrowses());
        vo.setParticipants(sysTopicAgreen.getSysTopic().getParticipants());
        vo.setPromulgator(sysTopicAgreen.getSysTopic().getPromulgator());
        vo.setGoods(sysTopicAgreen.getSysTopic().getGoods());
        vo.setComments(sysTopicAgreen.getSysTopic().getComments());
        vo.setTags(sysTopicAgreen.getSysTopic().getTags());
        vo.setCreateTime(DateUtil.DefaultTimeFormatter.format(sysTopicAgreen.getCreateTime()));
        return vo;
    }
    private int type;
    private String code;//编码
    private String title;//标题
    private String intro;//简介
    private String background;//背景图
    private int browses;//浏览量
    private int participants;//参与人数
    private int goods;//获得的赞数
    private int comments;//评论数
    private String promulgator;//发布人
    private String tags;//本话题对应该的标签
    private String createTime;//评论时间
}
