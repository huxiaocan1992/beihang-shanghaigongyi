package cn.dakaqi.apps.group.admin.cron;

import cn.dakaqi.apps.group.admin.cron.thread.GroupMonthDataThread;
import cn.dakaqi.services.GroupMonthDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by chunyang on 2016/4/21.
 */
public class CronJob
{
    private static Logger logger = LoggerFactory.getLogger(CronJob.class);

    @Autowired
    GroupMonthDataService groupMonthDataService;


    /**
     * 每月1日统计社团上一月的新增活动量、人员量、公益时间
     */
    public void statistics()
    {
        logger.info("---------------每月1日统计社团上一月的新增活动量、人员量、公益时间--------start-------------");
        GroupMonthDataThread dataThread = new GroupMonthDataThread(groupMonthDataService);
        Thread thread = new Thread(dataThread);
        thread.start();
        logger.info("---------------每月1日统计社团上一月的新增活动量、人员量、公益时间--------end----------------");
    }

}
