package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class SysTopicTest
{
    private static Logger logger = LoggerFactory.getLogger(SysTopicTest.class);
    public static void main(String[] args)
    {
        //create();
        //setDisplay();
        //setTop();
        //detail();
        //goods();
        //createSysTopicComment();
        //sysTopicComment();
        agreen();
    }

    private static void agreen()
    {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("code", "bWByNPQBpe");
        map.put("memberCode", "40288289540eed3501540eed35940000");
        map.put("type", "2");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopicAgreen/agreen", param);

    }

    private static void goods()
    {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("code", "ArVUBTS3em");
            String param = JSON.toJSONString(map);
            logger.info(param);
            HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopic/good", param);
    }

    private static void sysTopicComment()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code","ArVUBTS3em");
        map.put("pageNumber", "1");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/sysTopicCommnet/sysTopcode/ArVUBTS3em/1");
    }

    private static void createSysTopicComment()
    {
        for(int i=0;i<=100;i++)
        {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("code", "ArVUBTS3em");
            map.put("memberCode", "40288289540eed3501540eed35940000");
            map.put("demo", "这是一个话题的评论第"+i + "条评论！");
            String param = JSON.toJSONString(map);
            logger.info(param);
            HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopicCommnet/create", param);
        }
    }

    private static void detail()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code","ArVUBTS3em");
        map.put("status", "1");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/sysTopic/code/ArVUBTS3em");
    }

    private static void setTop()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code","ArVUBTS3em");
        map.put("status", "1");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopic/top",param);
    }

    private static void setDisplay()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code","ArVUBTS3em");
        map.put("status", "1");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopic/display",param);
    }

    private static void create()
    {
        for(int i=0;i<=10;i++)
        {
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("title","植树节要不NGO联合起来一起团种子吧" + i);
            map.put("intro","植树节要不NGO联合起来一起团种子吧植树节要不NGO联合起来一起团种子吧植树节要不NGO联合起来一起团种子吧植树节要不NGO联合起来一起团种子吧");
            map.put("background","http://img.dakaqi.cn/ads_1398742460387");
            map.put("promulgator", "天天菜");
            map.put("tags", "防诈骗;环保宣传;关爱行动;助残服务");
            String param = JSON.toJSONString(map);
            logger.info(param);
            HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/sysTopic/create",param);
        }

        //HttpInvoker.httpPost1("http://192.168.2.118:8080/unicorn/api/v1/account/create",param);

    }

    private static void sendCode()
    {
        try
        {
            HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/account/sendCode/18643720428");
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    //手机用户注册
    private static void createUser()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117934");
        map.put("password","123456");
        map.put("code","1234");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
        //HttpInvoker.httpPost1("http://192.168.2.118:8080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
