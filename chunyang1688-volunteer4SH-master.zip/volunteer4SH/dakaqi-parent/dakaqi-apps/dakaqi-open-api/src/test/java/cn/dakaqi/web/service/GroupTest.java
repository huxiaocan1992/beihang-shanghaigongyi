package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class GroupTest
{
    private static Logger logger = LoggerFactory.getLogger(GroupTest.class);
    public static void main(String[] args)
    {
        try
        {
            //findByMemberCode();
            //findByVolunteerCode();
            //updateVolunteer();
            //createGroup();

            createGroupRecriut();
            //groupRecriutDetail();
            //applyGroupRecriute();
            //volunteers();
            //answer();
            //verfier();

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static void verfier()
    {

        Map<String,Object> map = new HashMap<String,Object>();
        map.put("groupRecruitVolunteerId","4");
        map.put("memberCode","40288289541cf8cd01541cf8cd520000");
        map.put("status","2");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/verfier",param);
    }

    private static void answer()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/answer/4");
    }

    private static void volunteers()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/volunteers/9/0/1");
    }

    private static void applyGroupRecriute()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("groupRecruitId","9");
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("question","问题一;问题二;问题三;问题四;问题五;问题六;问题七;问题八;问题九;问题十");
        map.put("answer","答案一;答案二;答案三;答案四;答案五;答案六;答案七;答案八;答案九;答案十");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/apply",param);

    }

    private static void groupRecriutDetail()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/9");
    }

    private static void createGroupRecriut()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("groupCode","G32020160425D100");
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("title","第一个社团招募测试");
        map.put("demo","一个社团招募测试简介");
        map.put("stopApplyTime","2016-12-31 12:15:12");
        map.put("needs","10");
        map.put("job","学生");
        map.put("skill","电脑维修;水电维修");
        map.put("serviceField","电脑维修;水电维修");
        map.put("img","http://img.dakaqi.cn/ads_1400666639629");
        map.put("question","问题一;问题二;问题三;问题四;问题五;问题六;问题七;问题八;问题九;问题十");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/groupRecruit/create",param);

    }

    private static void createGroup()
    {
        for(int i=0;i<=10;i++)
        {
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("volunteerId","1");
            map.put("name","第"+i+"个测试社团");
            map.put("logo","张春洋2");
            map.put("demo","第"+i+"个测试社团demo");
            map.put("serviceField","1,2,3");
            map.put("setupDate","2016-10-15");
            map.put("regAddress","江苏省-南京市-江宁区");
            map.put("monitor","张小菜");
            map.put("phone","15821117931");

            String param = JSON.toJSONString(map);
            logger.info(param);
            HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/group/save",param);
        }

    }

    private static void findByVolunteerCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/memberCode/40288289540eed3501540eed35940000");
    }

    private static void findByMemberCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/volunteerCode/32-00008048-4");
    }

    private static void updateVolunteer()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("nickName","张春洋1");
        map.put("realName","张春洋2");
        map.put("cardType","CID");
        map.put("cardNO","32030519810302243X");
        map.put("residenceAddress","江苏省-南京市-江宁区");
        map.put("job","job");
        map.put("serviceField","serviceField");
        map.put("skill","skill");
        map.put("QQ","QQ");
        map.put("sign","sign");
        map.put("weChat","15821117932");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/volunteer/update",param);
    }

    //手机用户注册
    private static void createUser()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
