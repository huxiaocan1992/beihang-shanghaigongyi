package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class ActivityTest
{
    private static Logger logger = LoggerFactory.getLogger(ActivityTest.class);
    public static void main(String[] args)
    {
        try
        {
            //findByMemberCode();
            //findByVolunteerCode();
            //updateVolunteer();
            create();

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static void create()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("name","第一个活动");
        map.put("demo","demo");
        map.put("imgs","");
        map.put("startTime","2016-06-14 10:00:00");
        map.put("endTime","2016-06-14 20:00:00");
        map.put("type","1");
        map.put("province","江苏省");
        map.put("city","南京市");
        map.put("district","江宁区");
        map.put("lng","31.23654");
        map.put("lat","121.12345");
        map.put("address", "人民大道200号");
        map.put("tags","江苏省;南京市;江宁区");
        map.put("weekDay","");
        map.put("needs","20");
        map.put("scope","3000");
        map.put("monitorMemberCode","40288289540eed3501540eed35940000");
        map.put("crateUseMemberCode","402882f6541cfeb001541cfeb0180000");
        map.put("groupCode","G320201604256046");
//

//        Map<String,Object> map = new HashMap<String,Object>();
//        map.put("memberCode","40288289540eed3501540eed35940000");
//        map.put("name","第一个活动");
//        map.put("demo","demo");
//        map.put("imgs","");
//        map.put("startTime","2016-08-01 10:00:00");
//        map.put("endTime","2016-08-02 20:00:00");
//        map.put("type","2");
//        map.put("province","江苏省");
//        map.put("city","南京市");
//        map.put("district","江宁区");
//        map.put("lng","31.23654");
//        map.put("lat","121.12345");
//        map.put("address", "人民大道200号");
//        map.put("tags","江苏省;南京市;江宁区");
//        map.put("weekDay","江苏省-南京市-江宁区");
//        map.put("needs","20");
//        map.put("scope","3000");
//        map.put("monitorMemberCode","40288289540eed3501540eed35940000");
//        map.put("crateUseMemberCode","402882f6541cfeb001541cfeb0180000");
//        map.put("groupCode","qazxswedc");


//        map.put("memberCode","40288289540eed3501540eed35940000");
//        map.put("name","第一个活动");
//        map.put("demo","demo");
//        map.put("imgs","");
//        map.put("startTime","2016-04-14 10:00:00");
//        map.put("endTime","2016-04-30 20:00:00");
//        map.put("type","3");
//        map.put("province","江苏省");
//        map.put("city","南京市");
//        map.put("district","江宁区");
//        map.put("lng","31.23654");
//        map.put("lat","121.12345");
//        map.put("address", "人民大道200号");
//        map.put("tags","江苏省;南京市;江宁区");
//        map.put("weekDay","1;3;5");
//        map.put("needs","20");
//        map.put("scope","3000");
//        map.put("monitorMemberCode","40288289540eed3501540eed35940000");
//        map.put("crateUseMemberCode","402882f6541cfeb001541cfeb0180000");
//        map.put("groupCode","qazxswedc");


//        String name = jsonObject.getString("name");            //活动名称
//        String demo= jsonObject.getString("demo");            //活动简单
//        String imgs= jsonObject.getString("imgs");            //图片
//        String startTime= jsonObject.getString("startTime");       //开始日期
//        String endTime= jsonObject.getString("endTime");         //结束日期
//        int type= jsonObject.getIntValue("type");               //活动开展类型
//        String address= jsonObject.getString("address");         //活动地址
//        String tags= jsonObject.getString("tags");            //标签
//        String weekDay= jsonObject.getString("weekDay");         //周期
//        int needs= jsonObject.getIntValue("needs");              //所需人数
//        int scope= jsonObject.getIntValue("scope");              //签到误差范围
//        Long monitorId= jsonObject.getLong("monitorId");      //现场负责人
//        Long crateUserId= jsonObject.getLong("crateUserId");    //活动发布者
//        Long groupId= jsonObject.getLong("groupId");            //所属组织


        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/activity/create",param);
    }

    private static void findByVolunteerCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/memberCode/40288289540eed3501540eed35940000");
    }

    private static void findByMemberCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/volunteerCode/32-00008048-4");
    }

    private static void updateVolunteer()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("nickName","张春洋1");
        map.put("realName","张春洋2");
        map.put("cardType","CID");
        map.put("cardNO","32030519810302243X");
        map.put("residenceAddress","江苏省-南京市-江宁区");
        map.put("job","job");
        map.put("serviceField","serviceField");
        map.put("skill","skill");
        map.put("QQ","QQ");
        map.put("sign","sign");
        map.put("weChat","15821117932");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/volunteer/update",param);
    }

    //手机用户注册
    private static void createUser()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
