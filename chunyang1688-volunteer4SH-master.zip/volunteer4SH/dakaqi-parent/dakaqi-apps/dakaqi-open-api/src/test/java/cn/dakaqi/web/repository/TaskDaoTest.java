/*******************************************************************************
 * Copyright (c) 2005, 2014 springside.github.io
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *******************************************************************************/
package cn.dakaqi.web.repository;

import cn.dakaqi.dao.ActivityDao;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springside.modules.test.spring.SpringTransactionalTestCase;

@ContextConfiguration(locations = {"/applicationContext-service.xml"})
@Slf4j
public class TaskDaoTest extends SpringTransactionalTestCase {

	@Autowired
	private ActivityDao activityDao;

	@Test
	public void findTasksByUserId() throws Exception {
		//log.info(activityDao.findOne(117L).getName());
	}
}
