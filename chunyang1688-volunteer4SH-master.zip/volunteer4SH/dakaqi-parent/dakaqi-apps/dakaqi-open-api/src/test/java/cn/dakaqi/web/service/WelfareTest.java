package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class WelfareTest
{
    private static Logger logger = LoggerFactory.getLogger(WelfareTest.class);
    public static void main(String[] args)
    {
        //create();
        //list();
        //get();
        //my();
        id();

    }

    private static void id()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/welfare/2");
    }

    private static void my()
    {

        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/welfare/memberCode/40288289540eed3501540eed35940000/1");
    }

    private static void get()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("welfareId","1");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/welfare/get",param);
    }

    private static void list()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/welfare/list/1");
    }

    //手机用户注册
    private static void create()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117934");
        map.put("password","123456");
        map.put("code","1234");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
        //HttpInvoker.httpPost1("http://192.168.2.118:8080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
