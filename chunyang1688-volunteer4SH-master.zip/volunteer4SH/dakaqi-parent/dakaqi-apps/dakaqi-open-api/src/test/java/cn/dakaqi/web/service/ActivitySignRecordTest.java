package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class ActivitySignRecordTest
{
    private static Logger logger = LoggerFactory.getLogger(ActivitySignRecordTest.class);
    public static void main(String[] args)
    {
        try
        {
            //findByMemberCode();
            //findByVolunteerCode();
            //updateVolunteer();
            create();

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static void create()
    {
        for(int i=1;i<=5;i++)
        {
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("volunteerId",""+i);
            map.put("activityId","28");
            map.put("lng","121.36985");
            map.put("lat","31.69874");

            String param = JSON.toJSONString(map);
            logger.info(param);
            HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/activitySignRecord/save",param);
        }


    }

    private static void findByVolunteerCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/memberCode/40288289540eed3501540eed35940000");
    }

    private static void findByMemberCode()throws Exception
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/volunteer/volunteerCode/32-00008048-4");
    }

    private static void updateVolunteer()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("nickName","张春洋1");
        map.put("realName","张春洋2");
        map.put("cardType","CID");
        map.put("cardNO","32030519810302243X");
        map.put("residenceAddress","江苏省-南京市-江宁区");
        map.put("job","job");
        map.put("serviceField","serviceField");
        map.put("skill","skill");
        map.put("QQ","QQ");
        map.put("sign","sign");
        map.put("weChat","15821117932");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/volunteer/update",param);
    }

    //手机用户注册
    private static void createUser()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
