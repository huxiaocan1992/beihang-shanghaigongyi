package cn.dakaqi.web.service;

import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class DictionaryTest
{
    private static Logger logger = LoggerFactory.getLogger(DictionaryTest.class);
    public static void main(String[] args)
    {
        //createUser();
        //login();
/*        //String icard = "320305810302243";
        String icard = "32030519810302243X";
        int len = icard.length();
        String sex = "男";
        switch (len){
            case 15:
                String birth1 = icard.substring(6, 12);
                System.out.println(birth1);
                sex = icard.substring(14, 15);
                if(Integer.parseInt(sex)%2==0){
                    sex = "女";
                }else{
                    sex ="男";

                }
                break;
            case 18:
                //String birth2 = icard.substring(6, 14);
                sex = icard.substring(16, 17);
                if(Integer.parseInt(sex)%2==0){
                    sex = "女";
                }else{
                    sex ="男";

                }
                break;
        }
        System.out.println(sex);*/
        //sendCode();
        //qqlogin();

//        Map<String,String > map = new HashMap<String ,String >();
//        map.put("memberCode","402882f655591a000155591bf46f0001");
//        map.put("name","1236987");
//        String param = JSON.toJSONString(map);
//        logger.info(param);


    }

    private static void qqlogin()
    {
        String token = "8217C98FCCDCD0EEA9A180A836E78158";
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("platform","1");
        map.put("token",token);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/tencent",param);
    }

    private static void sendCode()
    {
        try
        {
            HttpInvoker.httpGet("http://192.168.2.118:8080/unicorn/api/v1/account/register/sendCode/15821117931");
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    //手机用户注册
    private static void createUser()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("mobile","15821117934");
        map.put("password","123456");
        map.put("code","1234");
        map.put("platform", DKQConstant.USER_PLATFORM_ANDROID);
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/create",param);
        //HttpInvoker.httpPost1("http://192.168.2.118:8080/unicorn/api/v1/account/create",param);
    }
    private static void login()
    {
        Map<String,String> map = new HashMap<String,String>();
        map.put("mobile","15821117932");
        map.put("password","123456");
        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/account/login", param);
    }
}
