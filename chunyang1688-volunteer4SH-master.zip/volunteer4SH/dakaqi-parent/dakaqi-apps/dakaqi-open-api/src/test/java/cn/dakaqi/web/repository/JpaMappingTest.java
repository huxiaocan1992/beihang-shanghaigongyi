/*******************************************************************************
 * Copyright (c) 2005, 2014 springside.github.io
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *******************************************************************************/
package cn.dakaqi.web.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springside.modules.test.spring.SpringTransactionalTestCase;

@ContextConfiguration(locations = {"/applicationContext-service.xml"})
public class JpaMappingTest extends SpringTransactionalTestCase
{

    private static Logger logger = LoggerFactory.getLogger(JpaMappingTest.class);

    @PersistenceContext
    private EntityManager em;

    @Test
    public void allClassMapping() throws Exception
    {
//        Metamodel model = em.getEntityManagerFactory().getMetamodel();
//        assertThat(model.getEntities()).as("No entity mapping found").isNotEmpty();
//        for (EntityType entityType : model.getEntities())
//        {
//            String entityName = entityType.getName();
//            String query = "select o from " + entityName + " o";
//            logger.info(query);
//            em.createQuery(query).getResultList();
//            logger.info("ok: " + entityName);
//        }
    }
}
