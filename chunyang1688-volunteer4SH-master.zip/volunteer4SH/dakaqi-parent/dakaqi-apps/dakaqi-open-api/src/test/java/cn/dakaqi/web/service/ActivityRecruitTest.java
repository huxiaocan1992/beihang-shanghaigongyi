package cn.dakaqi.web.service;

import cn.dakaqi.utils.http.HttpInvoker;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/12.
 */
public class ActivityRecruitTest
{
    private static Logger logger = LoggerFactory.getLogger(ActivityRecruitTest.class);
    public static void main(String[] args)
    {
        create();
        //detail();
        //apply();
        //volunteers();
        //answer();
        //verfier();
    }

    private static void verfier()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("activityRecruitVolunteerId","5");
        map.put("status","2");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/verfier",param);
    }

    private static void answer()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/answer/5");
    }

    private static void volunteers()
    {

        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/volunteers/1/0/1");
    }

    private static void apply()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("activityRecruitId","1");
        map.put("memberCode","40288289540eed3501540eed35940000");
        map.put("question","问题一;问题二;问题三;问题四;问题五;问题六;问题七;问题八;问题九;问题十");
        map.put("answer","答案一;答案二;答案三;答案四;答案五;答案六;答案七;答案八;答案九;答案十");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/apply",param);
    }

    private static void detail()
    {
        HttpInvoker.httpGet("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/1");
    }

    private static void create()
    {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("activityCode","A32020160414CF47");
        map.put("needs","10");
        map.put("job","在职");
        map.put("skill","技能一;技能二;技能三");
        map.put("serviceField","领域一;领域二;领域三");
        map.put("img","http://img.dakaqi.cn/ads_1400666639629");
        map.put("question","问题一;问题二;问题三;问题四;问题五;问题六;问题七;问题八;问题九;问题十");

        String param = JSON.toJSONString(map);
        logger.info(param);
        HttpInvoker.httpPost1("http://192.168.2.9:9080/unicorn/api/v1/activityRecruit/create",param);
    }
}
