package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Organization;
import cn.dakaqi.entities.Platform;
import cn.dakaqi.services.OrganizationService;
import cn.dakaqi.services.PlatformService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import com.wordnik.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 */
@RestController
@RequestMapping(value = "/api/v1/platfrom")
@Api(value = "平台管理API")
public class PlatformGroupRestController
{
    private static Logger logger = LoggerFactory.getLogger(PlatformGroupRestController.class);

    @Autowired
    PlatformService platformService;
    @Autowired
    OrganizationService organizationService;

    @RequestMapping(method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> list()
    {
        JsonResult result = new JsonResult();
        try
        {
            Page<Platform> data = platformService.findAll(1, DKQConstant.DEL_NO);
            if (data == null)
            {
                String message = "暂无数据";
                logger.warn(message);
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            result.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/searchByName/{name}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> searchByName(@PathVariable("name") String name)
    {
        JsonResult result = new JsonResult();
        try
        {
            List<Organization> data = organizationService.findByName(name,1);
            if (data == null)
            {
                String message = "暂无数据";
                logger.warn(message);
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data);
            result.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

}
