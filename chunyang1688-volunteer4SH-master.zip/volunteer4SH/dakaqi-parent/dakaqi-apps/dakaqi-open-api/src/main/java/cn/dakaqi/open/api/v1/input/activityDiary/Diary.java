package cn.dakaqi.open.api.v1.input.activityDiary;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by zhangchunyang on 16/8/1.
 */
@Data
@ApiModel
public class Diary implements Serializable
{
    @ApiModelProperty(value = "当前操作用户")
    String memberCode;
    @ApiModelProperty(value = "活动一号通")
    String activityCode;
    @ApiModelProperty(value = "日记内容")
    String message;
    @ApiModelProperty(value = "日记图片")
    String imgs;
    @ApiModelProperty(value = "好中差评类型")
    int type;
}
