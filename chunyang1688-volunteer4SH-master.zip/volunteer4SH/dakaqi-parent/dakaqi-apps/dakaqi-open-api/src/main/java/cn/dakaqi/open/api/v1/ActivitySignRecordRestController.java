package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.entities.ActivitySignRecord;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.vo.response.ActivitySignRecordVO;
import cn.dakaqi.services.ActivityService;
import cn.dakaqi.services.ActivitySignRecordService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.List;

/**
 * Created by chunyang on 2016/4/17.
 * 活动签到
 */
@RestController
@RequestMapping(value = "/api/v1/activitySignRecord")
@Api(value = "活动签到记录API")
public class ActivitySignRecordRestController
{
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    ActivityService activityService;

    @Autowired
    ActivitySignRecordService activitySignRecordService;

    @RequestMapping(value = "/create",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity(jsonResult, HttpStatus.OK);
            }
            ActivitySign activitySign = this.activitySignRecordService.save(param);
            if(activitySign.getTimes() == 0)
                jsonResult.setMessage("签到成功");
            else
                jsonResult.setMessage("签出成功");

        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

//    @RequestMapping(value = "/queryByMemberCode/{memberCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
//    public ResponseEntity<?> queryByMemberCode(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") Integer pageNumber)
//    {
//        JsonResult jsonResult = new JsonResult();
//
//        Page<ActivitySignRecord> data = this.activitySignRecordService.queryByMember(memberCode,pageNumber);
//        Map<String,Object> resultMap = new HashMap<String,Object>();
//        List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
//        if(null != data && data.getContent() != null && data.getContent().size()>0)
//        {
//            for(ActivitySignRecord asr:data.getContent())
//                vos.add(ActivitySignVO.buildVO(asr));
//        }
//
//        resultMap.put("list", vos);
//        resultMap.put("page", new DKQPage(data));
//        jsonResult.setData(resultMap);
//        jsonResult.setMessage("成功");
//        return new ResponseEntity(jsonResult, HttpStatus.OK);
//    }
//    @RequestMapping(value = "/queryByVolunteerId/{volunteerId}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
//    public ResponseEntity<?> queryByVolunteerId(@PathVariable("volunteerId") Long volunteerId,@PathVariable("pageNumber") Integer pageNumber)
//    {
//        JsonResult jsonResult = new JsonResult();
//
//        Page<ActivitySignRecord> data = this.activitySignRecordService.queryByMember(volunteerId,pageNumber);
//        Map<String,Object> resultMap = new HashMap<String,Object>();
//        List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
//        if(null != data && data.getContent() != null && data.getContent().size()>0)
//        {
//            for(ActivitySignRecord asr:data.getContent())
//                vos.add(ActivitySignVO.buildVO(asr));
//        }
//
//        resultMap.put("list", vos);
//        resultMap.put("page", new DKQPage(data));
//        jsonResult.setData(resultMap);
//        jsonResult.setMessage("成功");
//        return new ResponseEntity(jsonResult, HttpStatus.OK);
//    }
//
//    @RequestMapping(value = "/queryByActivityCode/{activityCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
//    public ResponseEntity<?> queryByActivityCode(@PathVariable("activityCode") String activityCode,@PathVariable("pageNumber") Integer pageNumber)
//    {
//        JsonResult jsonResult = new JsonResult();
//
//        Page<ActivitySignRecord> data = this.activitySignRecordService.queryByActivity(activityCode, pageNumber);
//        Map<String,Object> resultMap = new HashMap<String,Object>();
//        List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
//        if(null != data && data.getContent() != null && data.getContent().size()>0)
//        {
//            for(ActivitySignRecord asr:data.getContent())
//                vos.add(ActivitySignVO.buildVO(asr));
//        }
//
//        resultMap.put("list", vos);
//        resultMap.put("page", new DKQPage(data));
//        jsonResult.setData(resultMap);
//        jsonResult.setMessage("成功");
//        return new ResponseEntity(jsonResult, HttpStatus.OK);
//    }
//    @RequestMapping(value = "/queryByActivityId/{activityId}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
//    public ResponseEntity<?> queryByActivityId(@PathVariable("activityId") Long activityId,@PathVariable("pageNumber") Integer pageNumber)
//    {
//        JsonResult jsonResult = new JsonResult();
//
//        Page<ActivitySignRecord> data = this.activitySignRecordService.queryByActivity(activityId, pageNumber);
//        Map<String,Object> resultMap = new HashMap<String,Object>();
//        List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
//        if(null != data && data.getContent() != null && data.getContent().size()>0)
//        {
//            for(ActivitySignRecord asr:data.getContent())
//                vos.add(ActivitySignVO.buildVO(asr));
//        }
//
//        resultMap.put("list", vos);
//        resultMap.put("page", new DKQPage(data));
//        jsonResult.setData(resultMap);
//        jsonResult.setMessage("成功");
//        return new ResponseEntity(jsonResult, HttpStatus.OK);
//    }

    @RequestMapping(value = "/queryByMemberIdAndActivityId/{volunteerId}/{activityId}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryByMemberAndActivity(@PathVariable("volunteerId") Long volunteerId,@PathVariable("activityId") Long activityId)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Volunteer volunteer = this.volunteerService.findOne(volunteerId);
            Activity activity = this.activityService.findOne(activityId);
            if(null == volunteer || null == activity)
            {
                jsonResult.setMessage("当前会员或活动无效");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult, HttpStatus.OK);
            }

            List<ActivitySignRecord> data = this.activitySignRecordService.queryByMemberAndActivity(volunteerId,activityId,1);
            ActivitySignRecordVO vo = ActivitySignRecordVO.buildVO(volunteer,activity,data);
            jsonResult.setData(vo);
            jsonResult.setMessage("成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/queryByMemberAndActivity/{memberCode}/{activityCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryByMemberAndActivity(@PathVariable("memberCode") String memberCode,@PathVariable("activityCode") String activityCode)
    {
        JsonResult jsonResult = new JsonResult();

        try
        {
            Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);
            Activity activity = this.activityService.findByActivityCode(activityCode);
            if(null == volunteer || null == activity)
            {
                jsonResult.setMessage("当前会员或活动无效");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult, HttpStatus.OK);
            }

            List<ActivitySignRecord> data = this.activitySignRecordService.queryByMemberAndActivity(memberCode,activityCode,1);
            ActivitySignRecordVO vo = ActivitySignRecordVO.buildVO(volunteer,activity,data);

            jsonResult.setData(vo);
            jsonResult.setMessage("成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}
