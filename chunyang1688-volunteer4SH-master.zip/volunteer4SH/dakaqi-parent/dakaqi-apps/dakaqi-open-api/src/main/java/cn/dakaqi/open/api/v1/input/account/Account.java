package cn.dakaqi.open.api.v1.input.account;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: Account <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/1 13:49
 * @version: 1.0.0
 */
@Data
@ApiModel
public class Account implements Serializable
{
    @NotBlank(message = "手机号不能为空")
    @ApiModelProperty(value = "手机号")
    String mobile;

    @NotBlank(message = "密码不能为空")
    @ApiModelProperty(value = "密码")
    String password;

    @NotBlank(message = "手机验证码不能为空")
    @ApiModelProperty(value = "手机验证码")
    String code;

    @ApiModelProperty(value = "注册地点")
    String area;
    @ApiModelProperty(value = "经度")
    double lng = 0.00;
    @ApiModelProperty(value = "纬度")
    double lat = 0.00;

    @ApiModelProperty(value = "注册来源")
    int platform = 0;
}
