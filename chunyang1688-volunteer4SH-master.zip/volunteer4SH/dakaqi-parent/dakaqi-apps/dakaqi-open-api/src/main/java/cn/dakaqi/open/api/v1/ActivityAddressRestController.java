package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.ActivityAddress;
import cn.dakaqi.open.api.v1.input.activityAddress.ActivityAdressInput;
import cn.dakaqi.open.api.v1.input.activityAddress.DelActivityAdress;
import cn.dakaqi.services.ActivityAddressService;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.DKQPage;
import com.alibaba.fastjson.JSON;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/7.
 * 活动地址
 */
@RestController
@RequestMapping(value = "/api/v1/activityAddress")
@Api(value = "活动地址API")
@Slf4j
public class ActivityAddressRestController
{
    @Autowired
    ActivityAddressService activityAddressService;
    @Autowired
    ConfigUtil configUtil;

    @RequestMapping(value = "/memberCode/{memberCode}/{pageNumber}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getByGroupCode(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult result = new JsonResult();
        try
        {
            Page<ActivityAddress> data = this.activityAddressService.findByMemberCode(memberCode,null,ConfigUtil.getClientId(),pageNumber);
            if (data == null)
            {
                String message = "暂无活动地址";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            result.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

    @RequestMapping(value = "/id/{id}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findOne(@PathVariable("id") Long id)
    {
        JsonResult result = new JsonResult();
        try
        {
            ActivityAddress activityAddress = this.activityAddressService.findOne(id);
            if (activityAddress == null)
            {
                String message = "活动地址不存在";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("ActivityAddress", activityAddress);
            result.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/findName/{memberCode}/{name}/{pageNumber}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findName(@PathVariable("memberCode") String memberCode,@PathVariable("name") String name,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult result = new JsonResult();
        try
        {
            Page<ActivityAddress> data = this.activityAddressService.findByMemberCode(memberCode,name,ConfigUtil.getClientId(),pageNumber);
            if (data == null)
            {
                String message = "活动地址不存在";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            result.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }

        return new ResponseEntity(result,HttpStatus.OK);
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            //BeanValidators.validateWithException(validator, user);
            //检查非空

            this.activityAddressService.save(param);
            result.setMessage("活动地点创建成功");
            result.setCode(JsonResult.CODE_SUCCESS);

        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/del", method = RequestMethod.POST,consumes = MediaTypes.JSON, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> del(@RequestBody DelActivityAdress delActivityAdress)
    {
        JsonResult result = new JsonResult();
        try
        {
            String param = JSON.toJSONString(delActivityAdress);
            this.activityAddressService.del(param);
            result.setCode(JsonResult.CODE_SUCCESS);
            result.setMessage("删除成功");
        }
        catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
}
