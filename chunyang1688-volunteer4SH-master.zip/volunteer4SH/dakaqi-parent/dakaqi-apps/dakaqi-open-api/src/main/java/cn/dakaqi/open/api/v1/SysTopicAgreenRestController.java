package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.SysTopicAgreen;
import cn.dakaqi.vo.response.SysTopicAgreenVO;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.services.SysTopicAgreenService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/24.
 */
@RestController
@RequestMapping(value = "/api/v1/sysTopicAgreen")
@Api(value = "话题点赞API")
public class SysTopicAgreenRestController
{
    @Autowired
    SysTopicAgreenService sysTopicAgreenService;

    /**
     * 对话题点赞
     * @param param
     * @return
     */
    @RequestMapping(value = "/agreen",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.sysTopicAgreenService.create(param);
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定话题的所有点赞记录
     * @param code
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/sysTopcode/{code}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> sysTopcode(@PathVariable("code") String code,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(code))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            Page<SysTopicAgreen> data = this.sysTopicAgreenService.findBySysTopic(code,pageNumber);
            List<SysTopicAgreenVO> vos = new ArrayList<SysTopicAgreenVO>();

            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(SysTopicAgreen aa:data.getContent())
                    vos.add(SysTopicAgreenVO.buildVO(aa));
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }


}
