package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivityApply;
import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.ActivityApplyService;
import cn.dakaqi.services.ActivityService;
import cn.dakaqi.services.GroupService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;

/**
 * 扫描二维码
 * Created by chunyang on 2016/5/11.
 */
@RestController
@RequestMapping(value = "/api/v1/scan")
@Api(value = "扫描二维码API")
public class ScanRestController
{
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    GroupService groupService;
    @Autowired
    ActivityService activityService;
    @Autowired
    ActivityApplyService activityApplyService;

    @RequestMapping(value = "/activity/{activityCode}/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> activity(@PathVariable("activityCode") String activityCode,@PathVariable("memberCode") String memberCode)
    {
        String url = "http://wap.dakaqi.cn/h5/ActivityInfo.html?memberCode="+memberCode+"&activityCode="+activityCode;
        HashMap<String,String> resultMap = new HashMap<String, String>();
        JsonResult jsonResult = new JsonResult();;
        try
        {
            resultMap.put("url",url);
            //检查当前活动是否有效
            Activity activity = this.activityService.findByActivityCode(activityCode);
            if(null == activity)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("活动二维码无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            //检查当前用户是否已登录
            if(null == memberCode || "null".equals(memberCode) || StringUtils.isBlank(memberCode))
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setData(resultMap);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);
            if(null == volunteer)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("当前用户无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            //检查活动是否已封存或已结束
            if(activity.getLocked() == DKQConstant.ACTIVITY_LOCK)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setData(resultMap);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            //活动进行状态，检查当前用户是否报名当前活动
            ActivityApply activityApply = activityApplyService.findByVolunteerAndActivity(volunteer, activity);
            if(null == activityApply)
            {
                //用户未报名参加当前活动,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setData(resultMap);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            //用户未报名参加当前活动,转入到活动详情页面
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("可以进行签到");
            jsonResult.setCode(JsonResult.CODE_NO_DATA);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }

    @RequestMapping(value = "/group/{groupCode}/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> group(@PathVariable("groupCode") String groupCode,@PathVariable("memberCode") String memberCode)
    {
        String url = "http://wap.dakaqi.cn/h5/GroupInfo.html?memberCode="+memberCode+"&groupCode="+groupCode;
        HashMap<String,String> resultMap = new HashMap<String, String>();
        JsonResult jsonResult = null;
        try
        {
            resultMap.put("url",url);
            jsonResult = new JsonResult();
            //检查当前社团是否有效
            Group group = this.groupService.findByGroupCode(groupCode);
            if(null == group)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("社团二维码无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            //检查当前用户是否已登录
            if(null == memberCode || "null".equals(memberCode) || StringUtils.isBlank(memberCode))
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setData(resultMap);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);
            if(null == volunteer)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("当前用户无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }

            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }

    @RequestMapping(value = "/volunteer/{volunteerCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> volunteer(@PathVariable("volunteerCode") String volunteerCode)
    {
        String url = "http://wap.dakaqi.cn/h5/OtherMember.html?otherMemberCode=";
        HashMap<String,String> resultMap = new HashMap<String, String>();
        JsonResult jsonResult = null;
        try
        {
            resultMap.put("url",url);
            jsonResult = new JsonResult();
            //检查当前用户是否已登录
            if(null == volunteerCode || "null".equals(volunteerCode) || StringUtils.isBlank(volunteerCode))
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setData("当前用户无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            Volunteer volunteer = this.volunteerService.findByVolunteerCode(volunteerCode);
            if(null == volunteer)
            {
                //用户未登录,转入到活动详情页面
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("当前用户无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            url = url+volunteer.getMemberCode();
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }
}
