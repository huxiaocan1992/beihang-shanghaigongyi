package cn.dakaqi.open.api.v1.input.activityRecruit;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by zhangchunyang on 16/8/1.
 */
@Data
@ApiModel
public class ActRecruit implements Serializable
{
    @ApiModelProperty(value = "活动的一号通")
    String activityCode;
    @ApiModelProperty(value = "本次招募关心的职业")
    String job;
    @ApiModelProperty(value = "本次招募的服务技能")
    String skill;
    @ApiModelProperty(value = "本次扫墓的服务领域")
    String serviceField;
    @ApiModelProperty(value = "本次招募的封面图片")
    String img;
    @ApiModelProperty(value = "本次招募关心的问题")
    String question;
}
