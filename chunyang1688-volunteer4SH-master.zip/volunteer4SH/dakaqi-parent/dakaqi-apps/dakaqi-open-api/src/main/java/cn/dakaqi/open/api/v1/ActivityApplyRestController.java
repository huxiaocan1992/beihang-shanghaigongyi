package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.ActivityApply;
import cn.dakaqi.entities.GroupVolunteer;
import cn.dakaqi.services.ActivityApplyService;
import cn.dakaqi.services.ActivityRecruitVolunteerService;
import cn.dakaqi.services.GroupVolunteerService;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.ActivityApplyVO;
import cn.dakaqi.vo.response.ActivityVO;
import cn.dakaqi.vo.response.DKQPage;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/17.
 */
@RestController
@RequestMapping(value = "/api/v1/activityApply")
@Api(value = "活动报名API")
public class ActivityApplyRestController
{
    @Autowired
    ActivityRecruitVolunteerService activityRecruitVolunteerService;
    @Autowired
    ActivityApplyService activityApplyService;
    @Autowired
    GroupVolunteerService groupVolunteerService;
    @Autowired
    ConfigUtil configUtil;

    /**
     * 报名参加活动
     * @return
     */
    @RequestMapping(value = "/apply",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> apply(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(apply);
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                jsonResult.setMessage(message);
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            this.activityApplyService.apply(param);
            jsonResult.setMessage("报名成功,请准时参加");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
                e.printStackTrace();
                jsonResult.setCode(e.getCode());
                jsonResult.setMessage(e.getMessage());
                return new ResponseEntity(jsonResult,HttpStatus.OK);

        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @RequestMapping(value = "/exit",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> exit(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(exitActivityApply);
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                jsonResult.setMessage(message);
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            this.activityApplyService.exit(param);
            jsonResult.setMessage("您已退出本活动");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定会员所参加的活动
     * @param memberCode
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/queryActivityByMember/{memberCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryActivityByMember(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityApply> data =  this.activityApplyService.queryByMember(memberCode, DKQConstant.APPLY_STATUS_OK,pageNumber);
            List<ActivityVO> vos = new ArrayList<ActivityVO>();

            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivityApply aa:data.getContent())
                {
                    ActivityVO vo = ActivityVO.buildVO(aa.getActivity(),null,ConfigUtil.getClientId());
                    vo.setRole(aa.getRole());
                    vos.add(vo);
                }
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定活动 指定报名状态 的所有报名记录
     * @param activityCode
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/queryByActivity/{activityCode}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryByActivity(@PathVariable("activityCode") String activityCode,@PathVariable("status") Integer status,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityApply> data =  this.activityApplyService.queryByActivity(activityCode, status, pageNumber);
            List<ActivityApplyVO> vos = new ArrayList<ActivityApplyVO>();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivityApply aa:data.getContent())
                    vos.add(ActivityApplyVO.buildVO(aa));
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定活动的所有报名记录
     * @param activityCode
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/queryAllByActivity/{activityCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryAllByActivity(@PathVariable("activityCode") String activityCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityApply> data =  this.activityApplyService.queryAllByActivity(activityCode, pageNumber);
            List<ActivityApplyVO> vos = new ArrayList<ActivityApplyVO>();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                //检查当前活动是否发布了对外招募
                Page<ActivityApply> tt = activityApplyService.queryByActivity(data.getContent().get(0).getActivity().getActivityCode(),DKQConstant.APPLY_STATUS,1);
                long count = 0;
                if(null != tt)
                    count = tt.getTotalElements();
                resultMap.put("waiteRecruits", count);
                for(ActivityApply aa:data.getContent())
                {
                    ActivityApplyVO vo = ActivityApplyVO.buildVO(aa);
                    //检查当前用户是否本组织成员
                    GroupVolunteer groupVolunteer = this.groupVolunteerService.findByMemberAndGroup(vo.getMemberCode(),DKQConstant.APPLY_STATUS_OK ,aa.getActivity().getGroup().getGroupCode());
                    if(null != groupVolunteer)
                        vo.setDemo(groupVolunteer.getDemo());
                    else
                        vo.setDemo("暂无备注");
                    vos.add(vo);
                }
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 检查指定用户是否报名参加指定活动
     * @param activityCode
     * @param memberCode
     * @return
     */
    @RequestMapping(value = "/isApply/{activityCode}/{memberCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryAllByActivity(@PathVariable("activityCode") String activityCode,@PathVariable("memberCode") String memberCode)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            ActivityApply data =  this.activityApplyService.findByVolunteerAndActivity(memberCode,activityCode);
            Map<String,Object> resultMap = new HashMap<String, Object>();
            if(null != data)
            {
                if(data.getStatus() != DKQConstant.APPLY_STATUS_EXIT)
                    resultMap.put("isApply",data.getStatus());
                else
                    resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
            }
            else
            {
                resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
            }
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    /**
     * 查看指定用活动待审核记录
     * @param activityCode
     * @return
     */
    @RequestMapping(value = "/waiteVerfier/{activityCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> waiteVerfier(@PathVariable("activityCode") String activityCode,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Map<String,Object> resultMap = new HashMap<String, Object>();
            List<ActivityApplyVO> vos = new ArrayList<>();

            Page<ActivityApply> data =  this.activityApplyService.queryByActivity(activityCode, DKQConstant.ACT_STATUS_OUTER,pageNumber);

            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivityApply aa:data.getContent())
                {
                    vos.add(ActivityApplyVO.buildVO(aa));
                }
                resultMap.put("vos",vos);
            }
            else
                resultMap.put("vos",vos);

            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    /**
     * 审核报名记录
     * @return
     */
    @RequestMapping(value = "/verfier",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(verfierActivityApply);
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                jsonResult.setMessage(message);
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            this.activityApplyService.verfier(param);
        }
        catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 设置管理员
     * @return
     */
    @RequestMapping(value = "/setAdmin",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> setAdmin(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(setActivityAdmin);
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                jsonResult.setMessage(message);
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            this.activityApplyService.setAdmin(param);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}
