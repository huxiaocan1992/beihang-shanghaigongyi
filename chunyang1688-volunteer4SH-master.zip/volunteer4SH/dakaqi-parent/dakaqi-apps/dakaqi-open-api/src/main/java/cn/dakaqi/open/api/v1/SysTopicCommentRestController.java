package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.SysTopicComment;
import cn.dakaqi.vo.response.SysTopicCommentVO;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.services.SysTopicCommentService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/24.
 */
@RestController
@RequestMapping(value = "/api/v1/sysTopicCommnet")
@Api(value = "话题评论API")
public class SysTopicCommentRestController
{
    @Autowired
    SysTopicCommentService sysTopicCommentService;

    /**
     * 发表话题评论
     * @param param
     * @return
     */
    @RequestMapping(value = "/create",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.sysTopicCommentService.create(param);
            JSONObject jsonObject = JSON.parseObject(param);
            String code = jsonObject.getString("code");
            String memberCode = jsonObject.getString("memberCode");
            SysTopicComment comment = this.sysTopicCommentService.findLastComment(memberCode,code);
            Map<String,Object> resultMap = new HashMap<String, Object>();
            resultMap.put("comment", SysTopicCommentVO.buildVO(comment));

            jsonResult.setData(resultMap);
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定话题的所有评论
     * @param code
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/sysTopcode/{code}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> sysTopcode(@PathVariable("code") String code,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(code))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            Page<SysTopicComment> data = this.sysTopicCommentService.findBySysTopic(code,pageNumber);
            List<SysTopicCommentVO> vos = new ArrayList<SysTopicCommentVO>();

            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(SysTopicComment aa:data.getContent())
                    vos.add(SysTopicCommentVO.buildVO(aa));
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }


}
