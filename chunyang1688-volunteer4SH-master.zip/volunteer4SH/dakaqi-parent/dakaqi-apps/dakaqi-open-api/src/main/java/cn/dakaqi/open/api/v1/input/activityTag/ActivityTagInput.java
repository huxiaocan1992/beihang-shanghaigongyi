package cn.dakaqi.open.api.v1.input.activityTag;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: ActivityTagInput <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/11 14:32
 * @version: 1.0.0
 */
@Data
@ToString
@Slf4j
@ApiModel
public class ActivityTagInput implements Serializable
{
    private static final long serialVersionUID = 8075154074133754854L;
    @ApiModelProperty(value = "当前用户唯一标识",dataType = "String")
    private String memberCode;
    @ApiModelProperty(value = "自定义标签,多个间用;分隔",dataType = "String")
    private String name;
    @ApiModelProperty(value = "活动标签编号ID",dataType = "Long")
    private Long activityTagId;
}
