package cn.dakaqi.open.api.v1.input.activityApply;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Created by zhangchunyang on 16/8/1.
 */
@Data
@ApiModel
public class ExitActivityApply
{
    @ApiModelProperty(value = "当前操作用户维一标识")
    String memberCode;
    @ApiModelProperty(value = "活动一号通")
    String activityCode;
    @ApiModelProperty(value = "退出原因")
    String cause ;
}
