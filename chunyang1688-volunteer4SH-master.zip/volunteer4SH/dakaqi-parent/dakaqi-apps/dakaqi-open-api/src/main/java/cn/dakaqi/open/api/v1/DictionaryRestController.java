package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.*;
import cn.dakaqi.services.*;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.CodeMap;
import cn.dakaqi.utils.Dictionary;
import cn.dakaqi.utils.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/7.
 * 字典
 */
@RestController
@RequestMapping(value = "/api/v1/dictionary")
@Slf4j
public class DictionaryRestController
{
    @Autowired
    SysActivityTagService sysActivityTagService;
    @Autowired
    JobService jobService;
    @Autowired
    PersionServiceDomainService persionServiceDomainService;
    @Autowired
    GroupServiceDomainService groupServiceDomainService;
    @Autowired
    SkillService skillService;

    @Autowired
    ConfigUtil configUtil;

    @RequestMapping(value = "/dictions", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> dictions()
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        resultMap.put("cardType", CodeMap.getCardType());
        resultMap.put("edutcation", CodeMap.getEdutcation());
        resultMap.put("userServiceFiled", personServiceFiled());
        resultMap.put("userSkill", userSkill());
        resultMap.put("userType", CodeMap.getUserType());
        resultMap.put("groupServiceFiled", groupServiceFiled());
        resultMap.put("parts", CodeMap.getMemberParts());
        resultMap.put("prvoinceCityDistr", CodeMap.getProvinceCityDistrict());
        resultMap.put("ActivityRecruitImg", CodeMap.getActivityRecruitImg());
        resultMap.put("GroupRecruitImg", CodeMap.getGroupRecruitImg());
        resultMap.put("job", jobs());
        resultMap.put("hotTags", hotTags());
        System.out.println(CodeMap.getRongYunKey()[0]);
        jsonResult.setData(resultMap);
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }
    private List<Dictionary> personServiceFiled()
    {
        List<Dictionary> results = new ArrayList<Dictionary>();

        List<PersionServiceDomain> list = this.persionServiceDomainService.queryAllByClient(ConfigUtil.getClientId());
        if(null != list && list.size()>0)
        {
            for(PersionServiceDomain domain:list)
                results.add(new Dictionary(domain.getCode(), domain.getName()));
        }
        return results;
    }
    private List<Dictionary> jobs()
    {
        List<Dictionary> results = new ArrayList<Dictionary>();

        List<Job> list = this.jobService.queryAllByClient(ConfigUtil.getClientId());
        if(null != list && list.size()>0)
        {
            for(Job domain:list)
                results.add(new Dictionary(domain.getCode(), domain.getName()));
        }
        return results;
    }
    private List<Dictionary> userSkill()
    {
        List<Dictionary> results = new ArrayList<Dictionary>();

        List<Skill> list = this.skillService.queryAllByClient(ConfigUtil.getClientId());
        if(null != list && list.size()>0)
        {
            for(Skill domain:list)
                results.add(new Dictionary(domain.getCode(), domain.getName()));
        }
        return results;
    }
    private List<Dictionary> groupServiceFiled()
    {
        List<Dictionary> results = new ArrayList<Dictionary>();

        List<GroupServiceDomain> list = this.groupServiceDomainService.queryAllByClient(ConfigUtil.getClientId());
        if(null != list && list.size()>0)
        {
            for(GroupServiceDomain domain:list)
                results.add(new Dictionary(domain.getCode(), domain.getName()));
        }
        return results;
    }

    private List<Dictionary> hotTags()
    {
        List<Dictionary> results = new ArrayList<Dictionary>();

        List<SysActivityTag> list = this.sysActivityTagService.findAll();
        if(null != list && list.size()>0)
        {
            for(SysActivityTag domain:list)
                results.add(new Dictionary(domain.getId()+"", domain.getName()));
        }
        return results;
    }
}
