package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.GroupRecruit;
import cn.dakaqi.entities.GroupRecruitVolunteer;
import cn.dakaqi.entities.GroupVolunteer;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.*;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.vo.response.GroupVO;
import cn.dakaqi.vo.response.GroupVolunteerVO;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/16.
 * 社团成员管理
 */
@RestController
@RequestMapping(value = "/api/v1/groupVolunteer")
@Api(value = "社团成员管理API")
public class GroupVolunteerRestControl
{
    @Autowired
    private GroupVolunteerService groupVolunteerService;
    @Autowired
    private ActivityService activityService;
    @Autowired
    private GroupRecruitService groupRecruitService;
    @Autowired
    private GroupRecruitVolunteerService groupRecruitVolunteerService;
    @Autowired
    private GroupService groupService;
    @Autowired
    private VolunteerService volunteerService;

    /**
     * 查询指定会员是否加入当前社团
     * @param memberCode
     * @param groupCode
     * @return
     */
    @RequestMapping(value = "/isApply/{memberCode}/{groupCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> isApply(@PathVariable("memberCode") String memberCode,@PathVariable("groupCode") String groupCode)
    {
        //32-00002129-6
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(memberCode))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            GroupVolunteer data = this.groupVolunteerService.findByMemberAndGroup(memberCode,DKQConstant.APPLY_STATUS_ALL ,groupCode);
            if(null == data)
            {
                resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
            }
            else
            {
                if(data.getStatus() != DKQConstant.APPLY_STATUS_EXIT)
                    resultMap.put("isApply",data.getStatus());
                else
                    resultMap.put("isApply",data.getStatus());

                resultMap.put("refuseCase",data.getRefuseCase());
            }

            jsonResult.setMessage("查询成功");
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 报名参加指定社团
     * @param param
     * @return
     */
    @RequestMapping(value = "/apply",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> apply(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.save(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("等待管理员审核");
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(e.getCode());
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 退出社团招募报名
     * @param param
     * @return
     */
    @RequestMapping(value = "/exit",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> exit(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.exit(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("退出成功");
        } catch (ServiceRuntimeException e)
        {
                e.printStackTrace();
                jsonResult.setCode(e.getCode());
                jsonResult.setMessage(e.getMessage());
                return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
    /**
     * 审核社团报名人员
     * @param param
     * @return
     */
    @RequestMapping(value = "/verfier",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.updateStatus(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("审核完成");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 志愿者冻结
     * @param param
     * @return
     */
    public ResponseEntity<?> freeze(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.freeze(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("冻结成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 设置社团管理员
     * @param param
     * @return
     */
    @RequestMapping(value = "/setAdmin",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> setAdmin(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.setAdmin(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("设置成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定会员所有参加的社团
     * @param memberCode
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/volunteer/{memberCode}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> volunteer(@PathVariable("memberCode") String memberCode,@PathVariable("status") Integer status,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Map<String,Object> resultMap = new HashMap<String,Object>();
            //数据非空检查
            if(StringUtils.isBlank(memberCode))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            Page<GroupVolunteer> data = this.groupVolunteerService.queryMemberCode(memberCode,status, pageNumber);
            List<GroupVolunteerVO> vos = new ArrayList<GroupVolunteerVO>();
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(GroupVolunteer groupVolunteer:data.getContent())
                    vos.add(GroupVolunteerVO.buildVO(groupVolunteer));
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定社团所有成员列表
     * @param groupCode
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/group/{groupCode}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findByGroupCode(@PathVariable("groupCode") String groupCode,@PathVariable("status") Integer status,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(groupCode))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            Page<GroupVolunteer>  data = this.groupVolunteerService.queryGroupCode(groupCode,status,pageNumber);
            List<GroupVolunteerVO> vos = new ArrayList<GroupVolunteerVO>();
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(GroupVolunteer groupVolunteer:data.getContent())
                    vos.add(GroupVolunteerVO.buildVO(groupVolunteer));
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定会员最近加入的一个社团
     * @param memberCode
     * @return
     */
    @RequestMapping(value = "/oneGroup/{memberCode}/{groupCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> oneGroup(@PathVariable("memberCode") String memberCode,@PathVariable("groupCode") String groupCode)
    {
        JsonResult jsonResult = new JsonResult();
        List<GroupVO> vos = new ArrayList<GroupVO>();

        try
        {
            Map<String,Object> resultMap = new HashMap<String,Object>();
            //数据非空检查
            if(StringUtils.isBlank(memberCode))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            GroupVolunteer groupVolunteer = null;
            if(null == groupCode || "null".equals(groupCode) || StringUtils.isBlank(groupCode))
            {
                groupVolunteer = this.groupVolunteerService.findMemberLast(memberCode);
            }
            else
            {
                groupVolunteer = this.groupVolunteerService.findByMemberAndGroup(memberCode,DKQConstant.APPLY_STATUS_ALL ,groupCode);
                if(null == groupVolunteer)
                    groupVolunteer = this.groupVolunteerService.findMemberLast(memberCode);
            }

            if(null == groupVolunteer)
            {
                //推荐用户当前所在地的社团、若当地没有社团则推荐系统中最活跃的社团
                Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);
                if(null != volunteer)
                {
                    if(StringUtils.isNotBlank(volunteer.getCity()))
                    {
                        List<Group> groups = groupService.findByCity(volunteer.getCity(),2);
                        if(null != groups && groups.size()>0)
                            for(Group group:groups)
                            {
                                GroupVO vo = GroupVO.buildVO(group);
                                vos.add(vo);
                            }
                    }
                }

                if(vos.size() ==0 || vos.size() == 1)
                {
                    List<Group> groups = groupService.findHot(2);
                    if(null != groups && groups.size()>0)
                        for(Group group:groups)
                        {
                            GroupVO vo = GroupVO.buildVO(group);
                            vos.add(vo);
                        }
                }
                resultMap.put("list", vos);
                jsonResult.setData(resultMap);
                jsonResult.setCode(JsonResult.CODE_NO_DATA);
                jsonResult.setMessage("查询成功");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            GroupVO vo = GroupVO.buildVO(groupVolunteer.getGroup());
            //设置当前用户在当前社团中的身份
            vo.setRole(groupVolunteer.getRole());
            //查询当前社团正在进行的活动数量
            vo.setStartActs(this.activityService.countByGroupAndStatus(groupVolunteer.getGroup().getId(), DKQConstant.ACT_STATUS_PROCESS));

            //查询当前社团成员待审核数
            int count = groupVolunteerService.counts(vo.getGroupId(), DKQConstant.APPLY_STATUS);
            vo.setWaiteVerifers(count);

            //当前社团招募待审核数
            GroupRecruit groupRecruit = groupRecruitService.findLastByGroupCode(vo.getGroupCode(),DKQConstant.PROCEED_START);
            if(null != groupRecruit)
            {
                List<GroupRecruitVolunteer> list = this.groupRecruitVolunteerService.findVerfierByGroupRecruit(groupRecruit.getId(),DKQConstant.APPLY_STATUS);
                if(null != list)
                    vo.setWaiteRecruits(list.size());
            }

            vos.add(vo);
            resultMap.put("list", vos);
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 设置成员备注
     * @param param
     * @return
     */
    @RequestMapping(value = "/setdemo",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> setDemo(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.setDemo(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("设置成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 开除成员
     * @param param
     * @return
     */
    @RequestMapping(value = "/expel",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> expel(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //数据非空检查
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.groupVolunteerService.expel(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("开除成功");
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 按昵称搜索本社团成员
     * @param groupCode
     * @param name
     * @return
     */
    @RequestMapping(value = "/search/{groupCode}/{name}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> search(@PathVariable("groupCode") String groupCode,@PathVariable("name") String name)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Map<String,Object> resultMap = new HashMap<String,Object>();
            Page<GroupVolunteer>  data = this.groupVolunteerService.findNameLike(groupCode,name);
            List<GroupVolunteerVO> vos = new ArrayList<GroupVolunteerVO>();
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(GroupVolunteer groupVolunteer:data.getContent())
                    vos.add(GroupVolunteerVO.buildVO(groupVolunteer));
            }
            resultMap.put("list", vos);
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
}
