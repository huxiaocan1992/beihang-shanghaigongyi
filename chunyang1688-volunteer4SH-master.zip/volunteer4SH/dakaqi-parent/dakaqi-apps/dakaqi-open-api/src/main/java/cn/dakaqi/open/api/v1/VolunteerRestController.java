package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.*;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.entities.user.VolunteerInsurance;
import cn.dakaqi.entities.user.VolunteerMoney;
import cn.dakaqi.services.user.VolunteerCertificationService;
import cn.dakaqi.services.user.VolunteerInsuranceService;
import cn.dakaqi.services.user.VolunteerMoneyService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.CodeMap;
import cn.dakaqi.vo.response.*;
import cn.dakaqi.services.*;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import javax.validation.ConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by chunyang on 2016/4/7.
 * 志愿者
 */
@RestController
@RequestMapping(value = "/api/v1/volunteer")
@Slf4j
@Api(value = "志愿者API")
public class VolunteerRestController
{
    @Autowired
    ActivitySignService activitySignService;
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    VolunteerCertificationService volunteerCertificationService;
    @Autowired
    VolunteerInsuranceService volunteerInsuranceService;
    @Autowired
    GroupVolunteerService groupVolunteerService;
    @Autowired
    VolunteerMoneyService volunteerMoneyService;

    /**
     * 根据会员编号获取我的二维码
     * @param memberCode 用户编码
     * @return 二维码信息（BASE64）
     */
    @RequestMapping(value = "/qr/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public DataResponseVo<String> qr(@PathVariable("memberCode") String memberCode)
    {
        Volunteer volunteer = null;
        try
        {
            volunteer = this.volunteerService.findByMemberCode(memberCode);
            if (volunteer == null)
            {
                return new DataResponseVo<String>(JsonResult.CODE_FAIL,"志愿者不存在",null);
            }
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            return new DataResponseVo<String>(JsonResult.CODE_FAIL,"FAIL",null);
        }catch (Exception e)
        {
            e.printStackTrace();
            return new DataResponseVo<String>(JsonResult.CODE_FAIL,"FAIL",null);
        }
        return new DataResponseVo<String>(JsonResult.CODE_SUCCESS,"SUCCESS",Volunteer.getQr(volunteer.getVolunteerCode()));
    }

    /**
     * 根据会员编号返回个人信息
     * @param memberCode 用户编码
     * @return 用户个人信息
     */
    @RequestMapping(value = "/memberCode/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getByMemberCode(@PathVariable("memberCode") String memberCode)
    {
        Map<String,Object> resultMap = new HashMap<String,Object>();
        JsonResult result = new JsonResult();
        try
        {
            //志愿者数据
            Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);

            if (volunteer == null)
            {
                result.setMessage("志愿者不存在");
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            VolunteerVO vo = VolunteerVO.buildVO(volunteer);
            //好中差评数
            Long good = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_GOOD);
            Long mid = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_MID);
            Long bad = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_BAD);
            vo.setGoods(good==null?0L:good);
            vo.setBads(bad==null?0L:bad);
            vo.setMids(mid==null?0L:mid);
            //我参加的活动,我报名的活动

            //是否已购买保险
            VolunteerInsurance insurance = this.volunteerInsuranceService.findByVolunteerCode(volunteer.getVolunteerCode());
            //我的公益钱包

            //福利数量

            //实名认证结果
            String volunteerType = CodeMap.getVolunteerName()[0];
            if(StringUtils.isNotBlank(vo.getVolunteerCode()))
            {
                volunteerType = CodeMap.getVolunteerName()[1];
            }
            vo.setVolunteerType(volunteerType);
            //加入的社团
            List<SamllGroupVO> myGroups = new ArrayList<SamllGroupVO>();
            Page<GroupVolunteer> groupVolunteers = this.groupVolunteerService.queryMemberCode(memberCode,DKQConstant.APPLY_STATUS_OK,1);
            if(null != groupVolunteers && groupVolunteers.getContent() != null && groupVolunteers.getContent().size()>0)
            {
                for(GroupVolunteer gv:groupVolunteers.getContent())
                    myGroups.add(SamllGroupVO.buildVO(gv.getGroup(),gv.getTimes()));
            }
            //当前参加活动的活动活跨度
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            String month = sdf.format(new Date());
            Long lives = this.activitySignService.countByMemberMonth(volunteer.getId(),month);
            vo.setLives(lives == null?0L:lives);


            if(null != vo)
                resultMap.put("volunteerVO",vo);
            else
                resultMap.put("volunteerVO",new HashMap<String ,Object>());

            if(null != insurance)
                resultMap.put("insurance",insurance);
            else
                resultMap.put("insurance",new HashMap<String ,Object>());

            if(null != myGroups)
                resultMap.put("groups",myGroups);
            else
                resultMap.put("groups",new HashMap<String ,Object>());

            result.setData(resultMap);
            result.setMessage("查询成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage("程序异常");
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/OtherMemberCode/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getOtherMemberCode(@PathVariable("memberCode") String memberCode)
    {
        Map<String,Object> resultMap = new HashMap<String,Object>();
        JsonResult result = new JsonResult();
        try
        {
            //志愿者数据
            Volunteer volunteer = this.volunteerService.findByMemberCode(memberCode);

            if (volunteer == null)
            {
                result.setMessage("志愿者不存在");
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            VolunteerVO vo = VolunteerVO.buildVO(volunteer);
            vo.setCardNO("");
            vo.setCardType("");
            //好中差评数
            Long good = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_GOOD);
            Long mid = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_MID);
            Long bad = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_BAD);
            vo.setGoods(good==null?0L:good);
            vo.setBads(bad==null?0L:bad);
            vo.setMids(mid==null?0L:mid);

            //我参加的活动,我报名的活动

            //是否已购买保险
            VolunteerInsurance insurance = this.volunteerInsuranceService.findByVolunteerCode(volunteer.getVolunteerCode());
            //实名认证结果
            String volunteerType = CodeMap.getVolunteerName()[0];
            if(StringUtils.isNotBlank(vo.getVolunteerCode()))
            {
                volunteerType = CodeMap.getVolunteerName()[1];
            }
            vo.setVolunteerType(volunteerType);

            //加入的社团
            List<SamllGroupVO> myGroups = new ArrayList<SamllGroupVO>();
            Page<GroupVolunteer> groupVolunteers = this.groupVolunteerService.queryMemberCode(memberCode,DKQConstant.APPLY_STATUS_OK,1);
            if(null != groupVolunteers && groupVolunteers.getContent() != null && groupVolunteers.getContent().size()>0)
            {
                for(GroupVolunteer gv:groupVolunteers.getContent())
                    myGroups.add(SamllGroupVO.buildVO(gv.getGroup(),gv.getTimes()));
            }
            //当前参加活动的活动活跨度
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            String month = sdf.format(new Date());
            Long lives = this.activitySignService.countByMemberMonth(volunteer.getId(),month);
            vo.setLives(lives == null?0L:lives);

            if(null != vo)
                resultMap.put("volunteerVO",vo);
            else
                resultMap.put("volunteerVO",new HashMap<String ,Object>());

            if(null != insurance)
                resultMap.put("insurance",insurance);
            else
                resultMap.put("insurance",new HashMap<String ,Object>());

            if(null != myGroups)
                resultMap.put("groups",myGroups);
            else
                resultMap.put("groups",new HashMap<String ,Object>());

            result.setData(resultMap);
            result.setMessage("查询成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            result.setMessage("程序异常");
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/OtherVolunteerCode/{volunteerCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> OtherVolunteerCode(@PathVariable("volunteerCode") String volunteerCode)
    {
        Map<String,Object> resultMap = new HashMap<String,Object>();
        JsonResult result = new JsonResult();
        try
        {
            //志愿者数据
            Volunteer volunteer = this.volunteerService.findByVolunteerCode(volunteerCode);

            if (volunteer == null)
            {
                result.setMessage("志愿者不存在");
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            VolunteerVO vo = VolunteerVO.buildVO(volunteer);
            vo.setCardNO("");
            vo.setCardType("");
            //好中差评数
            Long good = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_GOOD);
            Long mid = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_MID);
            Long bad = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_BAD);
            vo.setGoods(good==null?0L:good);
            vo.setBads(bad==null?0L:bad);
            vo.setMids(mid==null?0L:mid);

            //我参加的活动,我报名的活动

            //是否已购买保险
            VolunteerInsurance insurance = this.volunteerInsuranceService.findByVolunteerCode(volunteer.getVolunteerCode());
            //实名认证结果
            String volunteerType = CodeMap.getVolunteerName()[0];
            if(StringUtils.isNotBlank(vo.getVolunteerCode()))
            {
                volunteerType = CodeMap.getVolunteerName()[1];
            }
            vo.setVolunteerType(volunteerType);

            //加入的社团
            List<SamllGroupVO> myGroups = new ArrayList<SamllGroupVO>();
            Page<GroupVolunteer> groupVolunteers = this.groupVolunteerService.queryMemberCode(volunteer.getMemberCode(),DKQConstant.APPLY_STATUS_OK,1);
            if(null != groupVolunteers && groupVolunteers.getContent() != null && groupVolunteers.getContent().size()>0)
            {
                for(GroupVolunteer gv:groupVolunteers.getContent())
                    myGroups.add(SamllGroupVO.buildVO(gv.getGroup(),gv.getTimes()));
            }
            //当前参加活动的活动活跨度
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            String month = sdf.format(new Date());
            Long lives = this.activitySignService.countByMemberMonth(volunteer.getId(),month);
            vo.setLives(lives == null?0L:lives);
            if(null != vo)
                resultMap.put("volunteerVO",vo);
            else
                resultMap.put("volunteerVO",new HashMap<String ,Object>());

            if(null != insurance)
                resultMap.put("insurance",insurance);
            else
                resultMap.put("insurance",new HashMap<String ,Object>());

            if(null != myGroups)
                resultMap.put("groups",myGroups);
            else
                resultMap.put("groups",new HashMap<String ,Object>());

            result.setData(resultMap);
            result.setMessage("查询成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            result.setMessage("程序异常");
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    /**
     * 根据一号通返回个人信息
     * @param volunteerCode
     * @return
     */
    @RequestMapping(value = "/volunteerCode/{volunteerCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getByVolunteerCode(@PathVariable("volunteerCode") String volunteerCode)
    {
        Map<String,Object> resultMap = new HashMap<String,Object>();
        JsonResult result = new JsonResult();
        try
        {
            //志愿者数据
            Volunteer volunteer = this.volunteerService.findByVolunteerCode(volunteerCode);

            if (volunteer == null)
            {
                result.setMessage("志愿者不存在");
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            VolunteerVO vo = VolunteerVO.buildVO(volunteer);
            //好中差评数
            Long good = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_GOOD);
            Long mid = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_MID);
            Long bad = activitySignService.countComments(volunteer.getId(), DKQConstant.COMMENT_TYPE_BAD);
            vo.setGoods(good==null?0L:good);
            vo.setBads(bad==null?0L:bad);
            vo.setMids(mid==null?0L:mid);

            //我参加的活动,我报名的活动

            //是否已购买保险
            VolunteerInsurance insurance = this.volunteerInsuranceService.findByVolunteerCode(volunteer.getVolunteerCode());
            //我的公益钱包

            //福利数量

            //实名认证结果
            String volunteerType = CodeMap.getVolunteerName()[0];
            if(StringUtils.isNotBlank(vo.getVolunteerCode()))
            {
                volunteerType = CodeMap.getVolunteerName()[1];
            }
            vo.setVolunteerType(volunteerType);
            //加入的社团
            List<SamllGroupVO> myGroups = new ArrayList<SamllGroupVO>();
            Page<GroupVolunteer> groupVolunteers = this.groupVolunteerService.queryMemberCode(volunteer.getMemberCode(),DKQConstant.APPLY_STATUS_OK,1);
            if(null != groupVolunteers && groupVolunteers.getContent() != null && groupVolunteers.getContent().size()>0)
            {
                for(GroupVolunteer gv:groupVolunteers.getContent())
                    myGroups.add(SamllGroupVO.buildVO(gv.getGroup(),gv.getTimes()));
            }
            //当前参加活动的活动活跨度
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
            String month = sdf.format(new Date());
            Long lives = this.activitySignService.countByMemberMonth(volunteer.getId(),month);
            vo.setLives(lives == null?0L:lives);


            if(null != vo)
                resultMap.put("volunteerVO",vo);
            else
                resultMap.put("volunteerVO",new HashMap<String ,Object>());

            if(null != insurance)
                resultMap.put("insurance",insurance);
            else
                resultMap.put("insurance",new HashMap<String ,Object>());

            if(null != myGroups)
                resultMap.put("groups",myGroups);
            else
                resultMap.put("groups",new HashMap<String ,Object>());

            result.setData(resultMap);
            result.setMessage("查询成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage("程序异常");
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

    /**
     * 根据会员ID获取个人信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/id/{id}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getById(@PathVariable("id") Long id)
    {
        JsonResult result = new JsonResult();
        try
        {
            Volunteer volunteer = this.volunteerService.findOne(id);
            if (volunteer == null)
            {
                String message = "志愿者不存在";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result, HttpStatus.OK);
            }
            Map<String, Object> resultMap = new HashMap<String, Object>();
            resultMap.put("volunteer", volunteer);
            result.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        catch (Exception e)
        {
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /**
     * 更新个人信息
     * @param param
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST, consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> updateVolunteerInfo(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            //BeanValidators.validateWithException(validator, user);
            //检查非空
            if (StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result, HttpStatus.OK);
            }
            this.volunteerService.updateVolunteer(param);
            result.setMessage("个人信息更新成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /**
     * 更新个人头像
     * @param param
     * @return
     */
    @RequestMapping(value = "/updatePortrait", method = RequestMethod.POST, consumes = MediaTypes.JSON, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> updatePortrait(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            log.info(param);
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            //BeanValidators.validateWithException(validator, user);
            //检查非空
            if (StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result, HttpStatus.OK);
            }
            this.volunteerService.updatePortrait(param);
            result.setMessage("头像修改成功");
            result.setCode(JsonResult.CODE_SUCCESS);
        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /**
     * 会员提交实名认证
     * @param param
     * @return
     */
    @RequestMapping(value = "/createVerifer", method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            log.info(param);
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            //BeanValidators.validateWithException(validator, user);
            //检查非空
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            this.volunteerCertificationService.save(param);
            result.setMessage("认证已提交,等待审核");
            result.setCode(JsonResult.CODE_SUCCESS);

        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

    /**
     * 对会员提交的实名认证进行认证
     * @param param
     * @return
     */
    @RequestMapping(value = "/updateVerifer", method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> update(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            log.info(param);
            // 调用JSR303 Bean Validator进行校验, 异常将由RestExceptionHandler统一处理.
            //BeanValidators.validateWithException(validator, user);
            //检查非空
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            this.volunteerCertificationService.update(param);
            result.setMessage("认证已提交,等待审核");
            result.setCode(JsonResult.CODE_SUCCESS);

        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

    /**
     * 我的钱包累计金额
     * @param memberCode
     * @return
     */
    @RequestMapping(value = "/money/{memberCode}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> myMoney(@PathVariable("memberCode") String memberCode)
    {
        JsonResult result = new JsonResult();
        try
        {
            Long money = this.volunteerMoneyService.findByMemberCode(memberCode);
            Map<String,Object> resultMap = new HashMap<String, Object>();
            resultMap.put("money",money==null?0L:money);
            result.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        catch (Exception e)
        {
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }

    /**
     * 我的收入/支出记录
     * @param memberCode
     * @param type
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/money/{memberCode}/{type}/{pageNumber}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> money(@PathVariable("memberCode") String memberCode,@PathVariable("type") int type,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult result = new JsonResult();
        try
        {
            Page<VolunteerMoney> data = this.volunteerMoneyService.findByMemberCode(memberCode,type,pageNumber);
            if (data == null)
            {
                String message = "暂无记录";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result, HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String, Object>();
            resultMap.put("list",data.getContent());
            resultMap.put("page",new DKQPage(data));
            result.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        catch (Exception e)
        {
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result, HttpStatus.OK);
        }
        return new ResponseEntity(result, HttpStatus.OK);
    }
}
