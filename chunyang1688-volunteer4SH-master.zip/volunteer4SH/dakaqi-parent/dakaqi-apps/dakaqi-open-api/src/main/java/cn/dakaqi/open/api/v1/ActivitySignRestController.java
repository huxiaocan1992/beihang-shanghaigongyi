package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.entities.ActivitySignRecord;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.vo.response.ActivitySignVO;
import cn.dakaqi.vo.response.VolunteerActivitySignVO;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.qnzyz.BHActivityService;
import cn.dakaqi.qnzyz.BHRecord;
import cn.dakaqi.services.ActivitySignRecordService;
import cn.dakaqi.services.ActivitySignService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.*;

/**
 * Created by chunyang on 2016/4/17.
 * 公益记录
 */
@RestController
@RequestMapping(value = "/api/v1/activitySign")
@Api(value = "公益记录API")
public class ActivitySignRestController
{
    @Autowired
    ActivitySignService activitySignService;
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    ActivitySignRecordService activitySignRecordService;
    @Autowired
    BHActivityService bhActivityService;
    public static void main(String[] args)
    {
        //查询当前当年完成的公益时间
        Calendar calendar = Calendar.getInstance();
        int tYear = calendar.get(Calendar.YEAR);
        int tMonth = calendar.get(Calendar.MONTH) + 1;
        int tDate = calendar.get(Calendar.DATE);
        System.out.println(tMonth);
    }
    @RequestMapping(value = "/queryByMemberCode/{memberCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryByMemberCode(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //查询当前用户信息
            Volunteer volunteer = volunteerService.findByMemberCode(memberCode);

            //查询当前当年完成的公益时间
            Long monthTimes = 0L;
            Long yearTimes = 0L;
//            Calendar calendar = Calendar.getInstance();
//            int tYear = calendar.get(Calendar.YEAR);
//            int tMonth = calendar.get(Calendar.MONTH) + 1;
//            int tDate = calendar.get(Calendar.DATE);
//
//            yearTimes = activitySignService.countByMemberYear(volunteer.getId(),""+tYear);
//
//            if(tMonth<10)
//                monthTimes = activitySignService.countByMemberMonth(volunteer.getId(), tYear + "-0" + tMonth);
//            else
//                monthTimes = activitySignService.countByMemberMonth(volunteer.getId(), tYear + "-" + tMonth);

            //查询当前用户公益记录
            Page<ActivitySign> data = this.activitySignService.queryByMember(memberCode,pageNumber);
            List<VolunteerActivitySignVO> vos = new ArrayList<VolunteerActivitySignVO>();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivitySign as:data.getContent())
                {
                    vos.add(VolunteerActivitySignVO.buildVO(as, volunteer.getTimes(),yearTimes,monthTimes));
                }
            }
            resultMap.put("allTimes",(volunteer.getTimes() + volunteer.getvTimes()));
            resultMap.put("Times",volunteer.getTimes());
            resultMap.put("VTimes",volunteer.getvTimes());
            resultMap.put("yearTimes",yearTimes);
            resultMap.put("monthTimes",monthTimes);
            resultMap.put("ActivitySign",vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/queryFromBH/{memberCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryFromBH(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        String totalServiceHours = "0.00",totalServiceScore = "0";
        List<BHRecord> list = null;
        try
        {
            //查询当前用户信息
            Volunteer volunteer = volunteerService.findByMemberCode(memberCode);
            if(null == volunteer)
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("当前用户无效");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            String volunteerCode = volunteer.getVolunteerCode();
            if(StringUtils.isBlank(volunteerCode))
            {
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("暂无数据");
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            Map<String,Object> map = this.bhActivityService.record4UnregList(volunteerCode,String.valueOf(pageNumber));
            if(null != map)
            {
                totalServiceHours = (String)map.get("totalServiceHours");
                totalServiceScore = (String)map.get("totalServiceScore");
                resultMap.put("totalServiceScore",totalServiceScore);
                resultMap.put("totalServiceHours",totalServiceHours);
                list = (List<BHRecord>)map.get("recordList");
                if(null != list && list.size()>0)
                    resultMap.put("list",list);
            }
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setData(resultMap);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/queryByActivityCode/{activityCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryByActivityCode(@PathVariable("activityCode") String activityCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();

        try
        {
            Page<ActivitySign> data = this.activitySignService.queryByActivity(activityCode,pageNumber);
            List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivitySign as:data.getContent())
                {
                    List<ActivitySignRecord> list = activitySignRecordService.queryByMemberAndActivity(as.getVolunteer().getMemberCode(), as.getActivity().getActivityCode(), 1);
                    vos.add(ActivitySignVO.buildVO(as,list));
                }
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setMessage("签到成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/queryUnCommentByActivityCode/{activityCode}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> queryUnCommentByActivityCode(@PathVariable("activityCode") String activityCode,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();

        try
        {
            Page<ActivitySign> data = this.activitySignService.queryUnCommentByActivityCode(activityCode, pageNumber);
            List<ActivitySignVO> vos = new ArrayList<ActivitySignVO>();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(ActivitySign as:data.getContent())
                {
                    List<ActivitySignRecord> list = activitySignRecordService.queryByMemberAndActivity(as.getVolunteer().getMemberCode(), as.getActivity().getActivityCode(), 1);
                    vos.add(ActivitySignVO.buildVO(as,list));
                }
            }
            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setMessage("签到成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/comment",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> updateCommentType(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            this.activitySignService.updateCommentType(param);
            jsonResult.setMessage("评论成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

}
