package cn.dakaqi.open.api.v1.input.account;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: UpdatePwd <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/1 14:00
 * @version: 1.0.0
 */
@Data
@ApiModel
public class UpdateMobile implements Serializable
{
    @ApiModelProperty(value = "新的手机号")
    String newMobile;
    @ApiModelProperty(value = "旧的手机号")
    String oldMobile;
    @ApiModelProperty(value = "旧手机密码")
    String password;
    @ApiModelProperty(value = "验证码")
    String code;
}
