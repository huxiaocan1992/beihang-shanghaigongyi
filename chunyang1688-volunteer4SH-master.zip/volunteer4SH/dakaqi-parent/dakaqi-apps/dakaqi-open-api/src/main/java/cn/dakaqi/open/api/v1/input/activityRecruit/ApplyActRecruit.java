package cn.dakaqi.open.api.v1.input.activityRecruit;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by zhangchunyang on 16/8/1.
 */
@Data
@ApiModel
public class ApplyActRecruit implements Serializable
{
    @ApiModelProperty(value = "当前操作用户")
    String memberCode;
    @ApiModelProperty(value = "活动一号通")
    String activityCode;
    @ApiModelProperty(value = "招募问题答案")
    String answer;
}
