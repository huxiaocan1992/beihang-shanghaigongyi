package cn.dakaqi.open.pingan2;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.GroupVolunteer;
import cn.dakaqi.entities.user.User;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.GroupVolunteerService;
import cn.dakaqi.services.user.UserService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.Clock;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.UUIDHexGenerator;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by chunyang on 2016/4/28.
 */
public class RegUserThread implements Runnable
{
    UserService userService;
    VolunteerService volunteerService;
    GroupVolunteerService groupVolunteerService;

    String name, idCard, mobile;
    Group group = null;
    Volunteer volunteer;

    public RegUserThread(UserService userService,
            VolunteerService volunteerService,
            GroupVolunteerService groupVolunteerService,
            String name, String idCard, String mobile,Group group,Volunteer volunteer)
    {
        this.userService = userService;
        this.volunteerService = volunteerService;
        this.groupVolunteerService = groupVolunteerService;
        this.name = name;
        this.idCard = idCard;
        this.mobile = mobile;
        this.group = group;
        this.volunteer = volunteer;

    }

    @Override
    public void run()
    {
        if(null == volunteer)
            createUserAndVolunteerCode();
        else
        {
            if(null == volunteer.getVolunteerCode() || StringUtils.isBlank(volunteer.getVolunteerCode()))
                createVolunteerCode(volunteer);
        }
    }

    private void createVolunteerCode(Volunteer volunteer)
    {

        GroupVolunteer groupVolunteer = new GroupVolunteer();
        groupVolunteer.setDelStatus(DKQConstant.DEL_NO);
        groupVolunteer.setStatus(DKQConstant.APPLY_STATUS_OK);
        groupVolunteer.setCreateTime(Clock.DEFAULT.getCurrentDate());
        groupVolunteer.setTimes(0L);
        groupVolunteer.setGroup(group);
        groupVolunteer.setRole(DKQConstant.ROLES_VOLUNTEER);
        groupVolunteer.setVolunteer(volunteer);

        groupVolunteerService.importData(groupVolunteer);
    }

    public void createUserAndVolunteerCode()
    {
        User user = new User();
        user.setMobile(mobile);
        user.setPassword("123456");
        user.setRealName(name);
        user.setNickName(name);
        user.setRoles("user");
        user.setEmail(mobile + "@dakaqi.cn");
        user.setPlatform(DKQConstant.USER_PLATFORM_WEB);
        user.setCreateTime(Clock.DEFAULT.getCurrentDate());
        user.setDelStatus(DKQConstant.DEL_NO);
        user.setLocked(DKQConstant.USER_UNLOCK);
        user.setOldID(0L);
        user.setOldMemberCode("");
        this.userService.saveSimpleUser(user);

        Volunteer v = new Volunteer();
        v.setMemberCode(UUIDHexGenerator.generator());
        v.setCrateTime(Clock.DEFAULT.getCurrentDate());
        v.setMobile(user.getMobile());
        v.setNickName(user.getNickName());
        v.setRealName(user.getRealName());
        v.setUserId(user.getId());
        v.setHeadUrl(DKQConstant.HEAR_URL);
        v.setCardNO(idCard);
        v.setTimes(0L);
        v.setSex(getSexFromCardNO(idCard));
        v.setBirthDay(getBirthFromCardNO(idCard));
        this.volunteerService.saveVolunteer(v);

        GroupVolunteer groupVolunteer = new GroupVolunteer();
        groupVolunteer.setDelStatus(DKQConstant.DEL_NO);
        groupVolunteer.setStatus(DKQConstant.APPLY_STATUS_OK);
        groupVolunteer.setCreateTime(Clock.DEFAULT.getCurrentDate());
        groupVolunteer.setTimes(0L);
        groupVolunteer.setGroup(group);
        groupVolunteer.setRole(DKQConstant.ROLES_VOLUNTEER);
        groupVolunteer.setVolunteer(v);

        groupVolunteerService.importData(groupVolunteer);
    }

    private String getBirthFromCardNO(String icard)
    {
        int len = icard.length();
        StringBuilder ymd = new StringBuilder();
        switch (len)
        {
            case 15:

                ymd.append("19").append(icard.substring(6, 12));
                break;
            case 18:
                ymd.append(icard.substring(6, 14));
                break;
            default:
                return "2010-01-01";
        }
        return ymd.substring(0, 4) + "-" + ymd.substring(4, 6) + "-" + ymd.substring(6, 8);
    }

    private String getSexFromCardNO(String icard)
    {
        int len = icard.length();
        String sex = "男";
        switch (len)
        {
            case 15:
                //String birth1 = icard.substring(6, 12);
                sex = icard.substring(14, 15);
                if (Integer.parseInt(sex) % 2 == 0)
                {
                    sex = "女";
                } else
                {
                    sex = "男";

                }
                break;
            case 18:
                //String birth2 = icard.substring(6, 14);
                sex = icard.substring(16, 17);
                if (Integer.parseInt(sex) % 2 == 0)
                {
                    sex = "女";
                } else
                {
                    sex = "男";

                }
                break;
        }
        return sex;
    }

}
