package cn.dakaqi.open.api.v1.input.account;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: SetNewPwd <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/1 13:57
 * @version: 1.0.0
 */
@Data
@ApiModel
public class SetNewPwd implements Serializable
{
    @ApiModelProperty(value = "手机号")
    String mobile;
    @ApiModelProperty(value = "密码")
    String passwd;
    @ApiModelProperty(value = "验证码")
    String code;
}
