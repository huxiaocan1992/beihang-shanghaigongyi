package cn.dakaqi.open.api.v1.input.activityAddress;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: ActivityAdressInput <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/1 11:14
 * @version: 1.0.0
 */
@Data
@ApiModel
public class DelActivityAdress implements Serializable
{
    @ApiModelProperty(value = "当前用户唯一标识",dataType = "String")
    String memberCode;
    @ApiModelProperty(value = "活动地址编号",dataType = "Long")
    Long activityAddressId;

}
