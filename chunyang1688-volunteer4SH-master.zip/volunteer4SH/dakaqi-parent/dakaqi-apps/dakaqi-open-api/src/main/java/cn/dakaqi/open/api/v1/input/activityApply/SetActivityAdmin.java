package cn.dakaqi.open.api.v1.input.activityApply;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * Created by zhangchunyang on 16/8/1.
 */
@Data
@ApiModel
public class SetActivityAdmin implements Serializable
{
    @ApiModelProperty(value = "活动报名ID")
    Long activityApplyId;
    @ApiModelProperty(value = "当前操作人的唯一标识")
    String memberCode;
    @ApiModelProperty(value = "本次活动的身份")
    int role;
}
