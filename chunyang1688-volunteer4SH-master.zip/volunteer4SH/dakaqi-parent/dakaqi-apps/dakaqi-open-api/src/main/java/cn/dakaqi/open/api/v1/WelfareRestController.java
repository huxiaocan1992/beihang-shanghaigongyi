package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Welfare;
import cn.dakaqi.entities.user.VolunteerWelfare;
import cn.dakaqi.services.WelfareService;
import cn.dakaqi.services.user.VolunteerWelfareService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.DKQPage;
import com.wordnik.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/18.
 */
@RestController
@RequestMapping(value = "/api/v1/welfare")
@Api(value = "福利API")
public class WelfareRestController
{
    @Autowired
    WelfareService welfareService;
    @Autowired
    VolunteerWelfareService volunteerWelfareService;

    /**
     * 福利列表记录
     * @param pageNubmer
     * @return
     */
    @RequestMapping(value = "/list/{pageNubmer}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> list(@PathVariable("pageNubmer") int pageNubmer)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<Welfare> data = this.welfareService.findAll(null,pageNubmer);
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定福利详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findOne(@PathVariable("id") Long id)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Welfare data = this.welfareService.findOne(id);
            jsonResult.setData(data);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定福利详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/findMyOne/{id}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findMyOne(@PathVariable("id") Long id)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            VolunteerWelfare data = this.volunteerWelfareService.findOne(id);
            jsonResult.setData(data);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定用户的福利记录列表
     * @param memberCode
     * @param pageNubmer
     * @return
     */
    @RequestMapping(value = "/memberCode/{memberCode}/{pageNubmer}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findByMemberCode(@PathVariable("memberCode") String memberCode,@PathVariable("pageNubmer") int pageNubmer)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<VolunteerWelfare> data = this.volunteerWelfareService.findByVolunteer(memberCode,pageNubmer);
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 会员领取福利
     * @param param
     * @return
     */
    @RequestMapping(value = "/get",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getWel(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            this.volunteerWelfareService.save(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("领取成功");
        }catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
}
