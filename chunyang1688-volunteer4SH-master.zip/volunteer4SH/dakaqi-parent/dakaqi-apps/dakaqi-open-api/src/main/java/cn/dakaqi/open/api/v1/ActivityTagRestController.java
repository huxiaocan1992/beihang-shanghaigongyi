package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.ActivityTag;
import cn.dakaqi.entities.SysActivityTag;
import cn.dakaqi.open.api.v1.input.activityTag.ActivityTagInput;
import cn.dakaqi.open.api.v1.input.activityTag.DelActivityTag;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.services.ActivityTagService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.alibaba.fastjson.JSON;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/7.
 * 活动地址
 */
@RestController
@RequestMapping(value = "/api/v1/activityTag")
@Api(value = "活动标签API")
public class ActivityTagRestController
{
    private static Logger logger = LoggerFactory.getLogger(ActivityTagRestController.class);

    @Autowired
    ActivityTagService activityTagService;

    @RequestMapping(value = "/memberCode/{memberCode}/{pageNumber}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> getByMemberCode(@PathVariable("memberCode") String memberCode,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        Page<ActivityTag> data = null;
        List<SysActivityTag> list = null;
        try
        {
            data = this.activityTagService.findByMemberCode(memberCode,null,pageNumber);
            list = this.activityTagService.findSysTag();
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            resultMap.put("SysTag", list);
            jsonResult.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }

    @RequestMapping(value = "/id/{id}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findOne(@PathVariable("id") Long id)
    {
        JsonResult result = new JsonResult();
        try
        {
            ActivityTag activityTag = this.activityTagService.findOne(id);
            if (activityTag == null)
            {
                String message = "活动地址不存在";
                logger.warn(message);
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }
            result.setData(activityTag);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @RequestMapping(value = "/findName/{memberCode}/{name}/{pageNumber}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findName(@PathVariable("memberCode") String memberCode,@PathVariable("name") String name,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        Page<ActivityTag> data = null;
        try
        {
            data = this.activityTagService.findByMemberCode(memberCode,name,pageNumber);
            if (data == null)
            {
                String message = "活动地址不存在";
                jsonResult.setMessage(message);
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult,HttpStatus.OK);
            }
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("list", data.getContent());
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }

        return new ResponseEntity(jsonResult,HttpStatus.OK);
    }
    @ApiOperation(value = "自定义活动标签",notes = "{\"memberCode\":\"402882f655591a000155591bf46f0001\",\"name\":\"1236987\"}")
    @RequestMapping(value = "/create", method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult result = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                String message = "数据不能为空";
                result.setMessage(message);
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result,HttpStatus.OK);
            }

            this.activityTagService.save(param);
            result.setMessage("活动标签创建成功");
            result.setCode(JsonResult.CODE_SUCCESS);

        } catch (ConstraintViolationException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

    @RequestMapping(value = "/del", method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> del(@RequestBody DelActivityTag delActivityTag)
    {
        JsonResult result = new JsonResult();
        try
        {
            String param = JSON.toJSONString(delActivityTag);
            this.activityTagService.delTag(param);
            result.setCode(JsonResult.CODE_SUCCESS);
            result.setMessage("删除成功");
        }
        catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
        }catch (Exception e)
        {
            e.printStackTrace();
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }

}
