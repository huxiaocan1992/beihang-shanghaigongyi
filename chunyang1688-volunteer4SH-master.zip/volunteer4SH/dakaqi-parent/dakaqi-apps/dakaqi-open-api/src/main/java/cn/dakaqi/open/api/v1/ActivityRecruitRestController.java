package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.ActivityRecruit;
import cn.dakaqi.entities.ActivityRecruitVolunteer;
import cn.dakaqi.open.api.v1.input.activityRecruit.ActRecruit;
import cn.dakaqi.open.api.v1.input.activityRecruit.ApplyActRecruit;
import cn.dakaqi.open.api.v1.input.activityRecruit.StopRecruit;
import cn.dakaqi.vo.response.ActivityRecruitVO;
import cn.dakaqi.vo.response.ActivityRecruitVolunteerVO;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.services.ActivityRecruitService;
import cn.dakaqi.services.ActivityRecruitVolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.ErrorCodeMsg;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/18.
 */
@RestController
@RequestMapping(value = "/api/v1/activityRecruit")
@Api(value = "活动招募API")
public class ActivityRecruitRestController
{
    @Autowired
    ActivityRecruitService activityRecruitService;
    @Autowired
    ActivityRecruitVolunteerService activityRecruitVolunteerService;

    /**
     *发布活动报幕信息
     * @return
     */
    @RequestMapping(value = "/create",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(actRecruit);
            activityRecruitService.create(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("活动招募发布成功");
        } catch (ServiceRuntimeException e)
        {
                e.printStackTrace();
                jsonResult.setCode(e.getCode());
                jsonResult.setMessage(e.getMessage());
                return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 停止活动招募
     * @return
     */
    @RequestMapping(value = "/stop",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> stop(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(stopRecruit);
            activityRecruitService.stop(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("招募已停止");
        }
        catch (ServiceRuntimeException e)
        {
                e.printStackTrace();
                jsonResult.setCode(e.getCode());
                jsonResult.setMessage(e.getMessage());
                return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看活动招募详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> detail(@PathVariable("id") Long id)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            ActivityRecruit activityRecruit = activityRecruitService.findOne(id);
            if(null == activityRecruit)
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("招募不存在");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            HashMap<String,Object> resultMap = new HashMap<String, Object>();
            //查看当前招募的所有报名名单
            Page<ActivityRecruitVolunteer>  data = activityRecruitVolunteerService.findByActivityRecruit(id, DKQConstant.APPLY_STATUS_OK, 1);
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {

                List<ActivityRecruitVolunteerVO> vos = new ArrayList<ActivityRecruitVolunteerVO>();

                for(ActivityRecruitVolunteer activityRecruitVolunteer:data.getContent())
                    vos.add(ActivityRecruitVolunteerVO.buildVO(activityRecruitVolunteer));

                resultMap.put("volunteers",vos);

            }

            resultMap.put("ActivityRecruit", ActivityRecruitVO.buildVO(activityRecruit));
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 回答问题,报名活动招募
     * @return
     */
    @RequestMapping(value = "/apply",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> apply(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(applyActRecruit);
            activityRecruitVolunteerService.apply(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);

            JSONObject jsonObject = JSON.parseObject(param);
            String answer = jsonObject.getString("answer");
            if(null == answer || StringUtils.isBlank(answer) || "null".equals(answer))
                jsonResult.setMessage("报名成功");
            else
                jsonResult.setMessage("等待管理员审核");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 退出报名活动招募
     * @param param
     * @return
     */
    @RequestMapping(value = "/exit",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> exit(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            activityRecruitVolunteerService.exit(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("退出成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/isApply/{memberCode}/{activityRecruitId}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> isApply(@PathVariable("memberCode") String memberCode,@PathVariable("activityRecruitId") Long activityRecruitId)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String, Object>();
        try
        {
            ActivityRecruitVolunteer volunteer = activityRecruitVolunteerService.isApply(activityRecruitId,memberCode);
            if(null == volunteer)
            {
                resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
            }
            else
            {
                if(volunteer.getStatus() != DKQConstant.APPLY_STATUS_EXIT)
                    resultMap.put("isApply",volunteer.getStatus());
                else
                    resultMap.put("isApply",DKQConstant.APPLY_UN_APPLY_STATUS);

                resultMap.put("refuseCase", volunteer.getRefuseCase());
            }
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
    /**
     * 查看指定招募的所有报名名单
     * @param id
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/volunteers/{id}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> volunteers(@PathVariable("id") Long id,@PathVariable("status") int status,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityRecruitVolunteer> data =  activityRecruitVolunteerService.findByActivityRecruit(id, status,pageNumber);
            Map<String,Object> resultMap = new HashMap<String,Object>();
            List<ActivityRecruitVolunteerVO> vos = new ArrayList<ActivityRecruitVolunteerVO>();

            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(ActivityRecruitVolunteer activityRecruitVolunteer:data.getContent())
                    vos.add(ActivityRecruitVolunteerVO.buildVO(activityRecruitVolunteer));

                resultMap.put("list", vos);
                resultMap.put("page", new DKQPage(data));
                jsonResult.setData(resultMap);
            }

            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定招募的所有报名名单
     * @param activityCode
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/activityCode/{activityCode}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> activity(@PathVariable("activityCode") String activityCode,@PathVariable("status") int status,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityRecruitVolunteer> data =  activityRecruitVolunteerService.findByActivityRecruit(activityCode, status,pageNumber);
            Map<String,Object> resultMap = new HashMap<String,Object>();
            List<ActivityRecruitVolunteerVO> vos = new ArrayList<ActivityRecruitVolunteerVO>();

            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(ActivityRecruitVolunteer activityRecruitVolunteer:data.getContent())
                    vos.add(ActivityRecruitVolunteerVO.buildVO(activityRecruitVolunteer));

                resultMap.put("list", vos);
                resultMap.put("page", new DKQPage(data));
                jsonResult.setData(resultMap);
            }

            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }


    /**
     * 审核报名名单
     * @param param
     * @return
     */
    @RequestMapping(value = "/verfier",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            activityRecruitVolunteerService.updateStatus(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("审核成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定报名人员的问题答案
     * @param activityRecruitVolunteerId
     * @return
     */
    @RequestMapping(value = "/answer/{activityRecruitVolunteerId}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> answer(@PathVariable("activityRecruitVolunteerId") Long activityRecruitVolunteerId)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            ActivityRecruitVolunteer data = this.activityRecruitVolunteerService.findOne(activityRecruitVolunteerId);
            if(null != data)
            {
                ActivityRecruitVolunteerVO vo = ActivityRecruitVolunteerVO.buildVO(data);
                jsonResult.setData(vo);
            }
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
    /**
     * 查看指定报名人员的问题答案
     * @return
     */
    @RequestMapping(value = "/answer/{activityCode}/{memberCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> answer(@PathVariable("activityCode") String  activityCode,@PathVariable("memberCode") String  memberCode)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            ActivityRecruitVolunteer data = this.activityRecruitVolunteerService.findOne(activityCode,memberCode);
            if(null != data)
            {
                ActivityRecruitVolunteerVO vo = ActivityRecruitVolunteerVO.buildVO(data);
                jsonResult.setData(vo);
            }
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

}
