package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.apps.group.admin.response.PassportApplyOrderPatchVO;
import cn.dakaqi.apps.group.admin.shiro.ShiroDbRealm;
import cn.dakaqi.entities.BaseAddress;
import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.PassportApplyOrder;
import cn.dakaqi.entities.PassportApplyOrderPatch;
import cn.dakaqi.services.BaseAddressService;
import cn.dakaqi.services.PassportApplyOrderPatchService;
import cn.dakaqi.services.PassportApplyOrderService;
import cn.dakaqi.utils.Clock;
import cn.dakaqi.utils.DateUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.qrcode.QRCode;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: BaseAddressController <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/9/27 11:33
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/passport")
@Slf4j
@ApiIgnore
public class PassportController extends BaseController
{
    @Autowired
    BaseAddressService baseAddressService;
    @Autowired
    PassportApplyOrderService passportApplyOrderService;
    @Autowired
    PassportApplyOrderPatchService passportApplyOrderPatchService;
    private SimpleDateFormat df;

    @RequestMapping(value = "/waiteMake", method = RequestMethod.GET)
    public ModelAndView waite(@RequestParam(value = "page",defaultValue = "1") int page,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/waite_make";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByBaseAddressId(baseAddress.getId(), PassportApplyOrder.STAUTS_WAITE, page);
            modelAndView.addObject("data", data);
            modelAndView.addObject("cardNO", "");
        }
        return modelAndView;
    }
    @RequestMapping(value = "/waiteSend", method = RequestMethod.GET)
    public ModelAndView finshed(@RequestParam(value = "page",defaultValue = "1") int page,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/send_waite";

        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        //BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        //Page<PassportApplyOrder> data = this.passportApplyOrderService.findByBaseAddressId(baseAddress.getId(),PassportApplyOrder.STAUTS_FINSHED,pageNumber);
        //modelAndView.addObject("data",data);
        //modelAndView.addObject("cardNO","");
        return modelAndView;
    }
    @RequestMapping(value = "/waiteSend/search", method = RequestMethod.GET)
    public ModelAndView waiteSend4Search(
            @RequestParam("cardNO") String cardNO,
            @RequestParam("num") String num,
            @RequestParam("mobile") String mobile,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes)
    {
        String view = "passport/send_waite";
        PassportApplyOrder data = null;
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null == baseAddress)
        {
            modelAndView.addObject("cardNO",cardNO);
            modelAndView.addObject("num",num);
            modelAndView.addObject("mobile",mobile);
            return modelAndView;
        }
        if(null != cardNO && StringUtils.isNotEmpty(cardNO) && StringUtils.isNotBlank(cardNO))
            data = this.passportApplyOrderService.findByCardNO(baseAddress.getId(),PassportApplyOrder.STAUTS_SEND_WAITE,cardNO);
        if(null != num && StringUtils.isNotEmpty(num) && StringUtils.isNotBlank(num))
            data = this.passportApplyOrderService.findByNum(baseAddress.getId(),PassportApplyOrder.STAUTS_SEND_WAITE,num);
        if(null != mobile && StringUtils.isNotEmpty(mobile) && StringUtils.isNotBlank(mobile))
            data = this.passportApplyOrderService.findByMobile(baseAddress.getId(),PassportApplyOrder.STAUTS_SEND_WAITE, mobile);

        if(null != data && data.getStatus() == PassportApplyOrder.STAUTS_SEND_WAITE)
        {
            modelAndView.addObject("data", data);
            String qrcode = getQr(data.getPassportNO());
            modelAndView.addObject("qrcode",qrcode);
        }

        modelAndView.addObject("cardNO",cardNO);
        modelAndView.addObject("num",num);
        modelAndView.addObject("mobile",mobile);

        return modelAndView;
    }
    private static String getQr(String code)
    {
        String qr = "";
        if(StringUtils.isNotBlank(code))
        {
            ByteArrayOutputStream out = QRCode.from(code).withSize(60,60).stream();
            byte[] data = out.toByteArray();
            qr = new String(Base64.encodeBase64(data));
            log.info(qr);
        }
        return qr;
    }
    @RequestMapping(value = "/waiteLogOut", method = RequestMethod.GET)
    public ModelAndView waiteLogOut(HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/waiteLogOut";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByStatusLogOut(baseAddress.getId(), 1);
            List<PassportApplyOrderPatchVO> vos = new ArrayList<PassportApplyOrderPatchVO>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(PassportApplyOrder order:data.getContent())
                {
                    PassportApplyOrderPatch patch = this.passportApplyOrderPatchService.findByOrderId(order.getId());
                    vos.add(PassportApplyOrderPatchVO.buildVO(order,patch));
                }
            }
            modelAndView.addObject("vos",vos);
        }

        return modelAndView;
    }
    @RequestMapping(value = "/waiteLogOut/search", method = RequestMethod.GET)
    public ModelAndView waiteLogOutSearch(HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/waiteLogOut";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByStatusLogOut(baseAddress.getId(), 1);
            List<PassportApplyOrderPatchVO> vos = new ArrayList<PassportApplyOrderPatchVO>();
            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                for(PassportApplyOrder order:data.getContent())
                {
                    PassportApplyOrderPatch patch = this.passportApplyOrderPatchService.findByOrderId(order.getId());
                    vos.add(PassportApplyOrderPatchVO.buildVO(order,patch));
                }
            }
            modelAndView.addObject("vos",vos);
        }

        return modelAndView;
    }
    @RequestMapping(value = "/checkOut", method = RequestMethod.POST)
    public ResponseEntity<?> checkOut(@RequestParam("id") Long id,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();
        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findOne(id);

        PassportApplyOrderPatch patch = this.passportApplyOrderPatchService.findByOrderId(passportApplyOrder.getId());
        PassportApplyOrder newOrder = new PassportApplyOrder();
        Collection<String> excludes = new ArrayList<String>();
        excludes.add("id");
        BeanUtils.copyProperties(passportApplyOrder, newOrder, excludes.toArray(new String[excludes.size()]));
        newOrder.setName(patch.getName());
        newOrder.setSex(patch.getSex());
        newOrder.setCardType(patch.getCardType());
        newOrder.setCardNO(patch.getCardNO());
        newOrder.setBirthday(patch.getBirthday());
        newOrder.setStatus(PassportApplyOrder.STAUTS_WAITE);
        newOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_NORMAL);
        newOrder.setApplyForm(PassportApplyOrder.FROM_OFFLINE);
        newOrder.setBackStatus(0);
        //newOrder.setPrintUser(getCurrentUserId());
        //newOrder.setPrintTime(DateUtil.getToday());
        newOrder.setPrintUser(0L);
        newOrder.setPrintTime("");
        newOrder.setCheckUser(0L);
        newOrder.setCheckTime("");
        //设置日期格式
        df = new SimpleDateFormat("yyyy-MM-dd");
        newOrder.setSignDate(df.format(new Date()));
        newOrder.setSignUser(0L);
//        String day = DateUtil.getAfterDay("",11);
//        String content = "请与"+day+"后的工作时间至预约地址领取";
//        newOrder.setAppointmenDate(content);
//        newOrder.setAppointmentTime("");

        String day = DateUtil.getAfterDay("",11);
        newOrder.setAppointmenDate(day);
        newOrder.setAppointmentTime("");
        //生成订单号、公益护照编号
        newOrder.setNum(PassportApplyOrder.createNum());
        newOrder.setOldNum(passportApplyOrder.getOldNum());
        passportApplyOrder.setStatus(PassportApplyOrder.STAUTS_LOGOUT);
        passportApplyOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_CLOSE);
        passportApplyOrder.setBackStatus(PassportApplyOrder.BACK_STATUS_LOGOUT);

        this.passportApplyOrderService.saveAndUpdate(newOrder,passportApplyOrder);
        //printCertificate();
        return new ResponseEntity(result, HttpStatus.OK);
    }
    @RequestMapping(value = "/activate/{pageNumber}", method = RequestMethod.GET)
    public ModelAndView activate(@PathVariable("pageNumber") int pageNumber,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/activate";

        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByBaseAddressId(baseAddress.getId(),PassportApplyOrder.STAUTS_ACTIVATED,pageNumber);
            modelAndView.addObject("data",data);
            modelAndView.addObject("cardNO","");
        }

        return modelAndView;
    }
    @RequestMapping(value = "/sendOK", method = RequestMethod.GET)
    public ModelAndView sendOK(@RequestParam(value = "page",defaultValue = "1") int page, HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/send_OK";

        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByBaseAddressId(baseAddress.getId(),PassportApplyOrder.STAUTS_SEND_OK,page);
            modelAndView.addObject("data",data);
            modelAndView.addObject("cardNO","");
        }

        return modelAndView;
    }
    @RequestMapping(value = "/sendOK/search", method = RequestMethod.GET)
    public ModelAndView sendOKSearch(@RequestParam("passportNO") String passportNO,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/send_OK";

        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByPassportNO(baseAddress.getId(), passportNO, PassportApplyOrder.STAUTS_SEND_OK, 1);

            modelAndView.addObject("data",data);
            modelAndView.addObject("passportNO",passportNO);
        }

        return modelAndView;
    }
    @RequestMapping(value = "/abolish/{pageNumber}", method = RequestMethod.GET)
    public ModelAndView abolish(@PathVariable("pageNumber") int pageNumber,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "passport/activate";

        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = this.passportApplyOrderService.findByBaseAddressId(baseAddress.getId(),PassportApplyOrder.STAUTS_ABOLISH,pageNumber);
            modelAndView.addObject("data",data);
            modelAndView.addObject("cardNO","");
        }

        return modelAndView;
    }
    @RequestMapping(value = "/updateStatus", method = RequestMethod.POST)
    public ResponseEntity<?> updateStatus(@RequestParam("id") Long id,@RequestParam("status") int status,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();
        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findOne(id);
        passportApplyOrder.setStatus(status);

        switch (status)
        {
            case PassportApplyOrder.STAUTS_CHECK:
                //调用证书打印接口
                if(printCertificate() == false)
                {
                    result.setCode(JsonResult.CODE_FAIL);
                    result.setMessage("打印机故障");
                    return new ResponseEntity(result, HttpStatus.OK);
                }
                //更新订单的打印人、打印时间
                passportApplyOrder.setPrintTime(DateUtil.getToday());
                passportApplyOrder.setPrintUser(getCurrentUserId());
                BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
                passportApplyOrder.setSignAddress(baseAddress.getPutUpAddr());
                passportApplyOrder.setSignUnti(baseAddress.getName());
                 df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
                passportApplyOrder.setSignDate(df.format(new Date()));
                result.setCode(JsonResult.CODE_SUCCESS);
                result.setMessage("证书已打印完成");
                break;
            case PassportApplyOrder.STAUTS_SEND_WAITE:
                passportApplyOrder.setCheckTime(DateUtil.getToday());
                passportApplyOrder.setCheckUser(getCurrentUserId());
                result.setCode(JsonResult.CODE_SUCCESS);
                result.setMessage("证书已复核完成");
                break;
            case PassportApplyOrder.STAUTS_SEND_OK:
                 df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
                passportApplyOrder.setSignDate(df.format(new Date()));
                passportApplyOrder.setSignUser(getCurrentUserId());
                result.setCode(JsonResult.CODE_SUCCESS);
                result.setMessage("证书已发放完成");
                break;
        }

//        PassportApplyOrder passportApplyOrder = this.findOne(id);
//        if(null == passportApplyOrder)
//            return;
//        passportApplyOrder.setSignDate(DateUtil.convertDefaultDateString(new Date()));
//        passportApplyOrder.setStatus(status);
//        this.update(passportApplyOrder);

        this.passportApplyOrderService.update(passportApplyOrder);
        return new ResponseEntity(result, HttpStatus.OK);
    }

    private boolean printCertificate()
    {
        return true;
    }
    @RequestMapping(value = "/againPrint", method = RequestMethod.POST)
    public ResponseEntity<?> againPrint(@RequestParam("id") Long id,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();
        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findOne(id);
        PassportApplyOrder newOrder = new PassportApplyOrder();
        Collection<String> excludes = new ArrayList<String>();
        excludes.add("id");
        BeanUtils.copyProperties(passportApplyOrder, newOrder, excludes.toArray(new String[excludes.size()]));
        newOrder.setStatus(PassportApplyOrder.STAUTS_WAITE);
        newOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_NORMAL);
        newOrder.setApplyForm(PassportApplyOrder.FROM_ONLINE);
        newOrder.setBackStatus(0);
        //newOrder.setPrintUser(getCurrentUserId());
        //newOrder.setPrintTime(DateUtil.getToday());
        newOrder.setPrintUser(0L);
        newOrder.setPrintTime("");
        newOrder.setCheckUser(0L);
        newOrder.setCheckTime("");
         df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        newOrder.setSignDate(df.format(new Date()));
        newOrder.setSignUser(0L);
        //生成订单号、公益护照编号
        newOrder.setNum(PassportApplyOrder.createNum());
        newOrder.setOldNum(passportApplyOrder.getOldNum());
        passportApplyOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_CLOSE);
        passportApplyOrder.setBackStatus(PassportApplyOrder.BACK_STATUS_PRINT);

        this.passportApplyOrderService.saveAndUpdate(newOrder,passportApplyOrder);
        //printCertificate();
        return new ResponseEntity(result, HttpStatus.OK);
    }
    @RequestMapping(value = "/checkAgainPrint", method = RequestMethod.POST)
    public ResponseEntity<?> checkAgainPrint(@RequestParam("id") Long id,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();
        PassportApplyOrder temp = this.passportApplyOrderService.findOne(id);

        PassportApplyOrder newOrder = new PassportApplyOrder();
        Collection<String> excludes = new ArrayList<String>();
        excludes.add("id");
        BeanUtils.copyProperties(temp,newOrder,excludes.toArray(new String[excludes.size()]));
        newOrder.setStatus(PassportApplyOrder.STAUTS_WAITE);
        newOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_NORMAL);
        newOrder.setApplyForm(PassportApplyOrder.FROM_ONLINE);
        newOrder.setBackStatus(0);
        //newOrder.setPrintUser(getCurrentUserId());
        //newOrder.setPrintTime(DateUtil.getToday());
        newOrder.setPrintUser(0L);
        newOrder.setPrintTime("");
        newOrder.setCheckUser(0L);
        newOrder.setCheckTime("");
         df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        newOrder.setSignDate(df.format(new Date()));
        newOrder.setSignUser(0L);
        //生成订单号、公益护照编号
        newOrder.setNum(PassportApplyOrder.createNum());
        newOrder.setOldNum(temp.getOldNum());


        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findOne(id);
        passportApplyOrder.setOrderStatus(PassportApplyOrder.ORDER_STAUTS_CLOSE);
        passportApplyOrder.setBackStatus(PassportApplyOrder.BACK_STATUS_CHECK);
        //this.passportApplyOrderService.save(passportApplyOrder);
        this.passportApplyOrderService.saveAndUpdate(newOrder,passportApplyOrder);

        //调用证书打印接口
        if(printCertificate() == false)
        {
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage("打印机故障");
            return new ResponseEntity(result, HttpStatus.OK);
        }
        //更新订单的打印人、打印时间
        newOrder.setPrintTime(DateUtil.getToday());
        newOrder.setPrintUser(getCurrentUserId());
        newOrder.setStatus(PassportApplyOrder.STAUTS_CHECK);
        this.passportApplyOrderService.save(newOrder);

        result.setCode(JsonResult.CODE_SUCCESS);
        result.setMessage("复核成功");
        return new ResponseEntity(result, HttpStatus.OK);
    }

    @RequestMapping(value = "/out", method = RequestMethod.POST)
    public ResponseEntity<?> backToMake(@RequestParam("id") Long id,
                                        @RequestParam("name") String name,
                                        @RequestParam("sex") String sex,
                                        @RequestParam("cardType") String cardType,
                                        @RequestParam("cardNO") String cardNO,
                                        @RequestParam("birthday") String birthday,
                                        HttpServletRequest request,
                                        RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();

        PassportApplyOrderPatch patch = new PassportApplyOrderPatch();
        patch.setCreateTime(Clock.DEFAULT.getCurrentDate());
        patch.setName(name);
        patch.setCardNO(cardNO);
        patch.setCardType(cardType);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        patch.setBaseAddressId(baseAddress.getId());
        patch.setBirthday(birthday);
        patch.setCreateUser(getCurrentUserId());
        patch.setSex(sex);
        patch.setPassportApplyOrderId(id);

        passportApplyOrderService.lock(id,patch);
        result.setCode(JsonResult.CODE_SUCCESS);
        result.setMessage("已退回制证部门");
        return new ResponseEntity(result, HttpStatus.OK);
    }

    @RequestMapping(value = "/waiteSearch", method = RequestMethod.GET)
    public ModelAndView waiteSearch(@RequestParam("num") String num,@RequestParam("cardNO") String cardNO,HttpServletRequest request,RedirectAttributes attributes)
    {
        String view = "passport/waite_make";

//        switch (status)
//        {
//            case PassportApplyOrder.STAUTS_WAITE:
//                view = "passport/waite_make";
//                break;
//            case PassportApplyOrder.STAUTS_SEND_WAITE:
//                view = "passport/send_waite";
//                break;
//            case PassportApplyOrder.STAUTS_ACTIVATED:
//                view = "passport/waiteactivate";
//                break;
//            case PassportApplyOrder.STAUTS_ABOLISH:
//                view = "passport/abolish";
//                break;
//        }


        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null != baseAddress)
        {
            Page<PassportApplyOrder> data = null;
            if(StringUtils.isNotBlank(cardNO))
                data = this.passportApplyOrderService.findByCardNO(baseAddress.getId(),cardNO,PassportApplyOrder.STAUTS_WAITE,1);
            if(StringUtils.isNotBlank(num))
                data = this.passportApplyOrderService.findByNum(baseAddress.getId(),PassportApplyOrder.STAUTS_WAITE,num,1);

            modelAndView.addObject("data", data);
        }

        return modelAndView;
    }

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        modelAndView = new ModelAndView(view,modelMap);
        return modelAndView;
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }

    /**
     * 取出Shiro中的当前用户Id.
     */
    private Long getCurrentUserId()
    {
        ShiroDbRealm.ShiroUser user = (ShiroDbRealm.ShiroUser) SecurityUtils.getSubject().getPrincipal();
        return user.id;
    }
}
