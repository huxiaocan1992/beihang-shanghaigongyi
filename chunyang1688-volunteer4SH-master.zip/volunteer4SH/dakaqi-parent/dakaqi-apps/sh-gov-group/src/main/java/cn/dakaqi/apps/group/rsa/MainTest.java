package cn.dakaqi.apps.group.rsa;

import com.alibaba.fastjson.JSONObject;

public class MainTest {

	private final static String timestampTag = "timestamp";

	private final static String trueNameTag = "trueName";

	private final static String idNoTag = "idNo";

	private final static String mobileNoTag = "mobileNo";

	private final static String cardNoTag = "cardNo";

	private final static String customerIdTag = "customerId";

	private final static String openBankNameTag = "openBankName";

	private final static String returnUrlTag = "returnUrl";

	private static final String COMPLETION_NAVIGATING_BUTTON_NAME = "completionNavigatingButtonName";

	private static final String COMPLETION_NAVIGATING_URL = "completionNavigatingUrl";

	private static final String DISCONTINUE_URL = "discontinueUrl";

	public static void main(String[] args) {
		try {
			//测试
			String public_key = "30819f300d06092a864886f70d010101050003818d0030818902818100d1029ae8333951c030d3d7468868d86902ffeb5f95a2addd5d3aa05d4443b641bb2db050b20a9aafee454c929106e9ff5a22060a8bca9cff2c6e6d66c2dc68c28536c349875e4edbc5ad79d00d7bf3708f3052abd75ac333f642710699aa7e37243883ae14362015c0c6fb2aaac1b4e1791cdaa95bee353abc0b971e5fe346330203010001";
			String private_key = "30820277020100300d06092a864886f70d0101010500048202613082025d02010002818100d1029ae8333951c030d3d7468868d86902ffeb5f95a2addd5d3aa05d4443b641bb2db050b20a9aafee454c929106e9ff5a22060a8bca9cff2c6e6d66c2dc68c28536c349875e4edbc5ad79d00d7bf3708f3052abd75ac333f642710699aa7e37243883ae14362015c0c6fb2aaac1b4e1791cdaa95bee353abc0b971e5fe34633020301000102818100810a88b53f9aedfc28a941ca0c421f0a868d96b646de4f55d24f75dedf5ca6d3e24a8d06e54562c7a7e62526805fb26cb32b3a6b9c6f158afdd597b9d028e08bc99354ada5d1a9175c822d50c41da1bdc1b9f17eefff3520d5073592733b5f3762b936103dec26a75b7c3c2d5c90ce99d4b65cb5a9fda3195ecf7eecb17d29d1024100fc963431bcffbe1543c403393e41c055ccbb94dfcb61b0efe4fa730d2a1731f5998698bb9f4cb0505a53f3bcb901653c15b7453b2aa37071602422f06cdb8e17024100d3d5a72446d6471fa18cac76956f488e81f9521836a7484c2d7946683a5440e9d35ffaa76b618b14ca20535ae88349710e698f8898c11cfd7b13e554398016450240215e6e92cb9735b3757a65baa040eb79ea4c35c4c307aaea6663b7e35b5629217b20cef8aa78e52a1864d2e471c47f6d4aa9259a456dc623144271e3355e640d024009b904b2e58d70364373f1767fe55baf2ec802bc99c593cbeb4a65b0e2fc7afe4075674bc7e1f2404206b9ccb25f543f9c29bc2cc8d6143e8e279b9f02049f01024100ec536031fa8c0e8b0c2f8859e987baa1d20f56e84e5db01ee299249264dc4391af530b7f0435493add02fc25ee74d4d91085856b2dba6231e614db0ff323e5c0";
			String aes_key = "17e4f4e492f67bd3d845a0aecaf2089f";



			//生产
//			String private_key = "30820275020100300d06092a864886f70d01010105000482025f3082025b02010002818100a81b05fb018efd099166407a8c77647961ede66d5eb89f66270adee1bf59a13d9d3807cefc4848b2d4de63bdb84a64ea9bad40c65589b4e4eead4eacc1da298fa629e53330c62ec7b6fba566287bbc0700e7bfecd0b30c6634855bb6359c110e6c76755bd67918ceaf9e63d00478c3be1ada44aeefb455faaaf3b87adab94fcd020301000102818007241ebceaf4080bc00177fbbcbbd5a8d26028c9bc9c5b291bbf7a785c889230ebdcd578157f7c971c33d648d8eb501e273ed4e19800a18e981504a29219926a561b1621702ca42101e9524243b055e671833bd3a9f2b2e5577d7a88ce6af2e90338e4a07f15aa288ab691350874b0b62ad469df0fc9fc348faf501c987a2801024100dd6cff9cbac09f56be78abe7ccf4f4442d581a8df470f2dd43fd5ff63a4c7f3a9437385ffcebeb5319233e5cb31444bf5a0e292a66b72f5c48dd81a9135832d1024100c25aab0e8661dab126a46e211ef72f98f30a016d0ac0eb2fb56bd7dc9572c203d5211756ba16a068036fc05679b1a14e9c839550270db3fe64ac4d43bf66f43d02405f30929ac0363ac9c1cc82aa7e13f846aeefa74acb811b07404956cdb5b65923c7c00d7e466eed95a5c2def65f0e2197d99128e54f8f04cf398bf047cd4727610240799386159bf2727f06912d63029fd5e27385fac65f47b6d72d41bcd27b9a41cb6bf33b4a41360e39828cd16046d7daf3f5ec49e6cdc740a50e0cca786aaed8710240677734b311b69a2c47b7a777016d0475765bce5529babeea3d53e5ba01e2dacecadc6f98b39b5923a08871b88d26c196fb8b61207d1d26ea32c6051aea3f0d77";
//			String public_key = "30819f300d06092a864886f70d010101050003818d0030818902818100a81b05fb018efd099166407a8c77647961ede66d5eb89f66270adee1bf59a13d9d3807cefc4848b2d4de63bdb84a64ea9bad40c65589b4e4eead4eacc1da298fa629e53330c62ec7b6fba566287bbc0700e7bfecd0b30c6634855bb6359c110e6c76755bd67918ceaf9e63d00478c3be1ada44aeefb455faaaf3b87adab94fcd0203010001";
//			String aes_key = "29aec3c3f0866c11ac75296766574b1f";


			// 参数封装
			JSONObject object = new JSONObject();
			object.put(trueNameTag, "直通一一一");
			object.put(idNoTag, "330219195604227020");
			object.put(mobileNoTag, "13010001001");
			object.put(cardNoTag, "6225887858124072");
			object.put(timestampTag, String.valueOf(System.currentTimeMillis()));
			object.put(customerIdTag, "61302564984");
			//object.put(returnUrlTag, "https://www.baidu.com/");
			// 中止开户流程返回地址、开户完成导航按钮名字和地址长度校验
			object.put(DISCONTINUE_URL, "https://www.baidu.com/");
			object.put(COMPLETION_NAVIGATING_BUTTON_NAME, "开户完成导航按钮名字");
			object.put(COMPLETION_NAVIGATING_URL, "https://www.baidu.com/");
			String source = object.toString();
			System.out.println("原文： " + source);

			// AES加密
			String ciphertext = AesTest.encrypt(source, aes_key);
			System.out.println("ciphertext:" + ciphertext);

			// 加签
			String sign = RSASignature.sign(ciphertext, private_key);
			System.out.println("sign:" + sign);

			// 验签
			boolean flag = RSASignature.verify(ciphertext, sign, public_key);
			System.out.println("验签结果 : " + flag);
			// AES解密
			String decryptData = AesTest.decrypt(ciphertext, aes_key);
			System.out.println("解密原文: ");
			System.out.println(decryptData);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
