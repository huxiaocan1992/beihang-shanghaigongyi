package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.GroupRecruit;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.GroupRecruitService;
import cn.dakaqi.services.GroupService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.Clock;
import cn.dakaqi.utils.CodeMap;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.mangofactory.swagger.annotations.ApiIgnore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Map;

/**
 * Created by chunyang on 2016/5/9.
 */
@Controller
@RequestMapping(value = "/groupRecruit")
@ApiIgnore
public class GroupRecruitController extends BaseController
{
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    GroupService groupService;
    @Autowired
    GroupRecruitService groupRecruitService;

    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group) request.getSession().getAttribute("curGroup"));
    }
    @Override
    protected ModelAndView initModelAndView(String groupCode, String view, HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode, request);
        return new ModelAndView(view, modelMap);
    }

    @Override
    protected void clearModelAndView(String groupCode, HttpServletRequest request)
    {

    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView index(@RequestParam(value = "page", defaultValue = "1") int pageNumber,
                              @RequestParam(value = "page.size", defaultValue = PAGE_SIZE) int pageSize,
                              @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
                              @RequestParam(value = "status", defaultValue = "2") int status, HttpServletRequest request)
    {
        String view = "groupRecruit/index";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        Page<GroupRecruit> data = groupRecruitService.findByGroupCode(group.getGroupCode(),pageNumber);
        modelAndView.addObject("data", data);
        return modelAndView;
    }

    @RequestMapping(value = "/searchByTitle",method = RequestMethod.GET)
    public ModelAndView searchByTitle(@RequestParam(value = "key") String key, HttpServletRequest request)
    {
        String view = "groupRecruit/index";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        Page<GroupRecruit> data = groupRecruitService.findByTitle(group.getGroupCode(),key);
        modelAndView.addObject("data", data);
        return modelAndView;
    }
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView add(HttpServletRequest request)
    {
        String view = "groupRecruit/create";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        modelAndView.addObject("recruitImgs", CodeMap.getGroupRecruitImg());
        modelAndView.addObject("groupRecruit",new GroupRecruit());
        return modelAndView;
    }

    @RequestMapping(value = "/edit/{groupRecruitId}", method = RequestMethod.GET)
    public ModelAndView edit(@PathVariable("groupRecruitId") long groupRecruitId,HttpServletRequest request)
    {
        String view = "groupRecruit/create";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        modelAndView.addObject("groupRecruit",groupRecruitService.findOne(groupRecruitId));
        modelAndView.addObject("recruitImgs", CodeMap.getGroupRecruitImg());
        return modelAndView;
    }
    @RequestMapping(value = "/detail/{groupRecruitId}", method = RequestMethod.GET)
    public ModelAndView detail(@PathVariable("groupRecruitId") long groupRecruitId,HttpServletRequest request)
    {
        String view = "groupRecruit/detail";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        modelAndView.addObject("groupRecruit",groupRecruitService.findOne(groupRecruitId));
        return modelAndView;
    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ResponseEntity<?> save(@RequestParam("id") Long id,
                             @RequestParam(value = "title",required = true) String  title,
                             @RequestParam(value = "stopDate",required = true) String stopDate,
                             @RequestParam(value = "needs",required = true) int needs,
                             @RequestParam(value = "linkman",required = true) String linkman,
                             @RequestParam(value = "phone",required = true) String phone,
                             @RequestParam(value = "job",required = true) String job,
                             @RequestParam(value = "skill",required = true) String skill,
                             @RequestParam(value = "serviceField",required = true) String serviceField,
                             @RequestParam(value = "img",required = true) String img,
                             @RequestParam(value = "demo",required = true) String demo,
                             @RequestParam(value = "questions",required = true) String questions,
                             HttpServletRequest request)
    {
        JsonResult jsonResult = null;
        try
        {
            jsonResult = new JsonResult();
            String message = "保存成功";
            Group group = getCurGroup(request);
            Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            GroupRecruit groupRecruit = new GroupRecruit();
            if (id != null)
            {
                    groupRecruit = groupRecruitService.findOne(id);
                    groupRecruit.setVolunteer(volunteer);
                    groupRecruit.setGroup(group);
                    groupRecruit.setTitle(title);
                    groupRecruit.setStopApplyTime(stopDate + " 00:00:00");
                    groupRecruit.setNeeds(needs);
                    groupRecruit.setLinkman(linkman);
                    groupRecruit.setPhone(phone);
                    groupRecruit.setJob(job);
                    groupRecruit.setSkill(skill);
                    groupRecruit.setServiceField(serviceField);
                    groupRecruit.setImg(img);
                    groupRecruit.setDemo(demo);
                    groupRecruit.setQuestion(questions);
                    this.groupRecruitService.update(groupRecruit);
            }
            else
            {
                    groupRecruit.setVolunteer(volunteer);
                    groupRecruit.setGroup(group);
                    groupRecruit.setTitle(title);
                    groupRecruit.setStopApplyTime(stopDate + " 00:00:00");
                    groupRecruit.setNeeds(needs);
                    groupRecruit.setLinkman(linkman);
                    groupRecruit.setPhone(phone);
                    groupRecruit.setJob(job);
                    groupRecruit.setSkill(skill);
                    groupRecruit.setServiceField(serviceField);
                    groupRecruit.setImg(img);
                    groupRecruit.setDemo(demo);
                    groupRecruit.setQuestion(questions);
                    groupRecruit.setCreateTime(Clock.DEFAULT.getCurrentDate());
                    groupRecruit.setBrowses(0);
                    groupRecruit.setTop(DKQConstant.TOP_NO);
                    groupRecruit.setApplys(0);
                    groupRecruit.setStatus(DKQConstant.PROCEED_START);
                    this.groupRecruitService.save(groupRecruit);
            }


            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage(message);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage("服务器异常");
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/cancel/{groupRecruitId}", method = RequestMethod.POST)
    public ResponseEntity<?> save(@PathVariable("groupRecruitId") long groupRecruitId,
                                  HttpServletRequest request)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            GroupRecruit groupRecruit = this.groupRecruitService.findOne(groupRecruitId);
            if(null != groupRecruit)
            {
                groupRecruit.setDelStatus(DKQConstant.DEL_YES);
                this.groupRecruitService.update(groupRecruit);
            }
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("取消成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage("服务器异常");
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @RequestMapping(value = "/question", method = RequestMethod.GET)
    public ModelAndView addQuestion(@RequestParam("id") Long id,
                                    @RequestParam(value = "title",required = true) String title,
                                    @RequestParam(value = "stopDate",required = true) String stopDate,
                                    @RequestParam(value = "needs",required = true) int needs,
                                    @RequestParam(value = "linkman",required = true) String linkman,
                                    @RequestParam(value = "phone",required = true) String phone,
                                    @RequestParam(value = "job",required = true) String job,
                                    @RequestParam(value = "skill",required = true) String skill,
                                    @RequestParam(value = "serviceField",required = true) String serviceField,
                                    @RequestParam(value = "img",required = true) String img,
                                    @RequestParam(value = "demo",required = true) String demo,
                                    @RequestParam(value = "question",required = true) String question,
                                    HttpServletRequest request)
    {
        String view = "groupRecruit/addquestion";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view, request);
        modelAndView.addObject("id",id);
        modelAndView.addObject("title",title);
        modelAndView.addObject("stopDate",stopDate);
        modelAndView.addObject("needs",needs);
        modelAndView.addObject("linkman",linkman);
        modelAndView.addObject("phone",phone);
        modelAndView.addObject("job",job);
        modelAndView.addObject("skill",skill);
        modelAndView.addObject("serviceField",serviceField);
        modelAndView.addObject("img",img);
        modelAndView.addObject("demo",demo);
        modelAndView.addObject("question",question);
        return modelAndView;
    }

    @ModelAttribute
    public void getGroup(@RequestParam(value = "id", required = false) Long id, Map<String, Object> map)
    {
        if (id != null)
        {
            GroupRecruit groupRecruit = groupRecruitService.findOne(id);
            map.put("groupRecruit", groupRecruit);
        }
    }
}
