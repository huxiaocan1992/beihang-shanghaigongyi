/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.v1;

import cn.dakaqi.apps.group.api.input.PassportApplyInputVO;
import cn.dakaqi.dao.ProvinceDao;
import cn.dakaqi.entities.AreaCity;
import cn.dakaqi.entities.AreaDistrict;
import cn.dakaqi.entities.AreaProvince;
import cn.dakaqi.utils.Dictionary;
import cn.dakaqi.utils.Identities;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.utils.redis.RedisClientTemplate;
import cn.dakaqi.utils.sms.rongcloud.RongCloudSMS;
import com.alibaba.fastjson.JSON;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 类名称：CommonController <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/6 15:11
 * @version: 1.0.0
 */

@Controller
@RequestMapping(value = "/v1/common")
@Slf4j
@Api(value = "工具类")
public class CommonController
{
    @Autowired
    ProvinceDao provinceDao;

    @Autowired
    RedisClientTemplate redisClientTemplate;

    @ApiOperation(value = "发送手机验证码")
    @RequestMapping(value = "/sendMobileCode",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> sendMobileCode(@RequestParam("mobile") String mobile)
    {
        JsonResult result = new JsonResult();
        try
        {
            if(StringUtils.isBlank(mobile))
            {
                result.setMessage("手机不能为空");
                result.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(result, HttpStatus.OK);
            }
            try
            {
                String sessionId = RongCloudSMS.sendCode(mobile);
                redisClientTemplate.set(mobile, sessionId);
                redisClientTemplate.expire(mobile, 60 * 10);
            } catch (Exception e)
            {
                e.printStackTrace();
            }
            result.setCode(JsonResult.CODE_SUCCESS);
            result.setMessage("验证码已发送,请注意查收");
        }
        catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
    @ApiOperation(value = "验证手机验证码")
    @RequestMapping(value = "/verfiMobileCode",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfiMobileCode(@RequestParam("mobile") String mobile,@RequestParam("code") String code)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Map<String,String> map = new HashMap<>();
            PassportApplyInputVO passportApply = new PassportApplyInputVO();
            passportApply.setMobile(mobile);

            if(code.equals("135790"))
            {
                jsonResult.setMessage("验证码正确");
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                String sn = Identities.randomBase62(32);
                redisClientTemplate.set(sn, JSON.toJSONString(passportApply));
                map.put("sn",sn);
                jsonResult.setData(map);

            }
            else if(RongCloudSMS.verifyCode(redisClientTemplate.get(mobile.trim()),code) == true)
            {
                clearVeriferCode(mobile);
                jsonResult.setMessage("验证码正确");
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                String sn = Identities.randomBase62(32);
                redisClientTemplate.set(sn, JSON.toJSONString(passportApply));
                map.put("sn",sn);
                jsonResult.setData(map);
            }
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage("验证码不正确");
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "证件类型")
    @RequestMapping(value = "/cardType",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> cardType()
    {
        JsonResult jsonResult = new JsonResult();

        List<Dictionary> list = new ArrayList<Dictionary>();
        try
        {
            list.add(new Dictionary("CID","身份证"));
            //list.add(new Dictionary("OTHER","其他"));
            jsonResult.setData(list);
            jsonResult.setMessage("查询成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage("不正确");
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "申请类别")
    @RequestMapping(value = "/applyType",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> applyType()
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,List<Dictionary>> map = new HashMap<String,List<Dictionary>>();
        try
        {
            List<Dictionary> list = new ArrayList<Dictionary>();
            list.add(new Dictionary("10","首次申领"));
            list.add(new Dictionary("20","换发护照"));
            list.add(new Dictionary("30","补发护照"));
            map.put("applyTypeMap",list);

            List<Dictionary> list2 = new ArrayList<Dictionary>();
            list2.add(new Dictionary("1","原护照丢失"));
            list2.add(new Dictionary("2","原护照被盗、损毁"));
            map.put("applyCaseMap",list2);

            jsonResult.setData(map);
            jsonResult.setMessage("查询成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage("不正确");
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "监护人关系")
    @RequestMapping(value = "/personRelation",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> personRelation()
    {
        JsonResult jsonResult = new JsonResult();

        Map<String,List<Dictionary>> map = new HashMap<String,List<Dictionary>>();
        try
        {
            List<Dictionary> list = new ArrayList<Dictionary>();
            list.add(new Dictionary("1","父母"));
            list.add(new Dictionary("2","祖父母"));
            list.add(new Dictionary("3","外祖父母"));
            list.add(new Dictionary("4","兄姐"));
            list.add(new Dictionary("5","其他"));
            map.put("relation",list);
            jsonResult.setData(map);
            jsonResult.setMessage("查询成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage("不正确");
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "省市区县")
    @RequestMapping(value = "/provicecitydistrict",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> provicecitydistrict()
    {
        JsonResult jsonResult = null;
        try
        {
            jsonResult = new JsonResult();
            Map<String,Object> map = new HashMap<>();

            List<AreaProvince> plist = provinceDao.queryAllProvince();
            List<AreaCity> clist = provinceDao.queryAllCity();
            List<AreaDistrict> dlist = provinceDao.queryAllDistrict();
            map.put("p",plist);
            map.put("c",clist);
            map.put("d",dlist);

            jsonResult.setData(map);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    private void clearVeriferCode(String mobile)
    {
        redisClientTemplate.del(mobile);
    }

}
 
 