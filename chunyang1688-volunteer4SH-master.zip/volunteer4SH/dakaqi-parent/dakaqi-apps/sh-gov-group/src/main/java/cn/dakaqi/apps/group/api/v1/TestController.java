/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.v1;

import cn.dakaqi.services.PinganNumberService;
import cn.dakaqi.services.PinganOpenService;
import cn.dakaqi.services.user.VolunteerInsuranceService;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * 类名称：TestController <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/5 14:22
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/v1/test")
@Slf4j
@ApiIgnore
public class TestController
{
    @Autowired
    VolunteerInsuranceService volunteerInsuranceService;
    @Autowired
    PinganOpenService pinganOpenService;
    @Autowired
    PinganNumberService pinganNumberService;

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> get(@PathVariable("id") Long id)
    {
        log.info("查询编号为(" + id + ")的用户信息");
        JsonResult jsonResult = new JsonResult();
        try {

            Map<String, Object> resultMap = new HashMap<String, Object>();
            resultMap.put("userName", "梦幻币春洋");
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e) {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}

