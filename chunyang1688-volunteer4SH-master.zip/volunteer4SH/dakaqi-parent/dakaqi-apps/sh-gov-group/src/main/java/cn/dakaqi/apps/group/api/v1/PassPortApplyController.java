/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.v1;

import cn.dakaqi.apps.group.admin.utils.Tools;
import cn.dakaqi.apps.group.api.input.PassportApplyInputVO;
import cn.dakaqi.apps.group.api.input.TradListVO;
import cn.dakaqi.apps.group.api.response.PassportActivateVO;
import cn.dakaqi.apps.group.http.HttpsClientUtil;
import cn.dakaqi.apps.group.rsa.AesTest;
import cn.dakaqi.apps.group.util.IdcardInfoExtractor;
import cn.dakaqi.entities.*;
import cn.dakaqi.entities.user.VolunteerInsurance;
import cn.dakaqi.services.*;
import cn.dakaqi.services.user.VolunteerInsuranceService;
import cn.dakaqi.utils.Clock;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.utils.http.HttpsUtil;
import cn.dakaqi.utils.redis.RedisClientTemplate;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springside.modules.web.MediaTypes;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 类名称：PassPortLogin <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/6 15:51
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/v1/passport")
@Slf4j
@Api(value = "公益护照")
public class PassPortApplyController
{
     final String PINGAN_AES_KEY = "29aec3c3f0866c11ac75296766574b1f";

    @Autowired
    GroupService groupService;
    @Autowired
    BaseAddressService baseAddressService;
    @Autowired
    RedisClientTemplate redisClientTemplate;
    @Autowired
    PassportApplyService passportApplyService;
    @Autowired
    PassportApplyOrderService passportApplyOrderService;
    @Autowired
    VolunteerInsuranceService volunteerInsuranceService;
    @Autowired
    PinganOpenService pinganOpenService;
    @Autowired
    PinganNumberService pinganNumberService;


    @ApiOperation(value = "公益护照登录")
    @RequestMapping(value = "/pplogin",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> pplogin(@RequestParam("passport") String passport, @RequestParam("pwd") String pwd)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            log.info("公益护照登录---1--->" + passport + "," + pwd);
            PassportApplyOrder passportApplyOrder = passportApplyOrderService.findByPassportNO(passport);
            log.info("公益护照登录---2--->" + passport + "," + pwd + passportApplyOrder);
            if(null == passportApplyOrder)
            {
                jsonResult.setMessage("护照不存在");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity(jsonResult, HttpStatus.OK);
            }
            if(passportApplyOrder.getCardNO().lastIndexOf(pwd) >0)
            {
                jsonResult.setMessage("登录成功");
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                PassportActivateVO activateVO = new PassportActivateVO();

                BaseAddress baseAddress = baseAddressService.findOne(passportApplyOrder.getBassAddressId());
                Group group = this.groupService.findOne(baseAddress.getGroupId());
                activateVO.setGroupCode(group.getGroupCode());
                activateVO.setIdNo(passportApplyOrder.getCardNO());
                activateVO.setMobile(passportApplyOrder.getMobile());
                activateVO.setPassportNo(passportApplyOrder.getPassportNO());
                activateVO.setRealName(passportApplyOrder.getName());
                activateVO.setStatus(passportApplyOrder.getStatus());
                jsonResult.setData(activateVO);
                if(passportApplyOrder.getStatus() == 40)
                {
                    jsonResult.setMessage("护照已激活,不可以重复激活");
                    jsonResult.setCode(JsonResult.CODE_FAIL);
                }
            }
            else
            {
                jsonResult.setMessage("密码不正确");
                jsonResult.setCode(JsonResult.CODE_FAIL);
            }
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @ApiOperation(value = "激活成功后,支付中心回调")
    @RequestMapping(value = "/pabCall", method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> pabCall(@RequestParam("resultJson") String resultJson)
    {
        log.info("pab 返回的信息------>"+ resultJson);

        JsonResult jsonResult = new JsonResult();
        try {
            if(StringUtils.isNotBlank(resultJson))
            {
                resultJson = AesTest.decrypt(resultJson,PINGAN_AES_KEY);
                log.info("decrypt------->" + resultJson);
                JSONObject jsonObject = JSON.parseObject(resultJson);
                if(null != jsonObject)
                {

                    JSONObject bankJson = jsonObject.getJSONObject("obj").getJSONObject("bankAccount");
                    if(null != bankJson)
                    {
                        String bankacnt = bankJson.getString("bankAcnt");
                        String idno = bankJson.getString("idNo");
                        String mobile = bankJson.getString("mobile");
                        String realname = bankJson.getString("realName");
                        String tradetime = bankJson.getString("tradeTime");
                        log.info(bankacnt+ "," + idno + "," + mobile + "," + realname);
                        PinganOpen pinganOpen = new PinganOpen();
                        pinganOpen.setMobile(mobile);
                        String sn = pinganNumberService.createNO("A");
                        pinganOpen.setActivateSn(sn);
                        pinganOpen.setSn(sn);
                        pinganOpen.setActivateTime(Clock.DEFAULT.getCurrentDate());
                        pinganOpen.setCardNum(bankacnt);
                        pinganOpen.setCustomer("SHWG");
                        pinganOpen.setIdCard(idno);
                        pinganOpen.setName(realname);
                        pinganOpen.setPlatform("A");
                        pinganOpen.setCreateTime(Clock.DEFAULT.getCurrentDate());
                        pinganOpen.setMemberCode("T-"+idno);
                        log.info(pinganOpen.toString());
                        this.pinganOpenService.save(pinganOpen);

                        //更新护照激活状态
                        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findAllCardNO(idno);
                        if(null != passportApplyOrder)
                        {
                            log.info(passportApplyOrder.toString());
                            passportApplyOrder.setStatus(PassportApplyOrder.STAUTS_ACTIVATED);
                            this.passportApplyOrderService.update(passportApplyOrder);
                            log.info(passportApplyOrder.toString());
                        }
                    }
                    JSONObject insuranceJson = jsonObject.getJSONObject("obj").getJSONObject("insurance");
                    if(null != insuranceJson)
                    {
                        String createtime = insuranceJson.getString("createTime");
                        String insuranceno = insuranceJson.getString("insuranceNo");
                        String periodEnd = insuranceJson.getString("periodEnd");
                        String periodStart = insuranceJson.getString("periodStart");
                        String serviceProvider = insuranceJson.getString("serviceProvider");
                        String status = insuranceJson.getString("status");
                        String transactionBatch = insuranceJson.getString("transactionBatch");
                        String volunteercode = insuranceJson.getString("volunteerCode");
                        VolunteerInsurance volunteerInsurance = new VolunteerInsurance();
                        volunteerInsurance.setPeriodEnd(periodEnd);
                        volunteerInsurance.setPeriodStart(periodStart);
                        volunteerInsurance.setCreateTime(Clock.DEFAULT.getCurrentDate());
                        volunteerInsurance.setInsuranceNo(insuranceno);
                        volunteerInsurance.setStatus(1);
                        volunteerInsurance.setServiceProvider(serviceProvider);
                        volunteerInsurance.setVolunteerCode(volunteercode);
                        this.volunteerInsuranceService.save(volunteerInsurance);
                        log.info(volunteerInsurance.toString());
                    }
                }
            }
        } catch (ServiceRuntimeException e) {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "公益护照申请")
    @RequestMapping(value = "/apply",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> apply(@RequestBody PassportApplyInputVO passportApplyInputVO)
    {
        JsonResult jsonResult = new JsonResult();
        log.info(passportApplyInputVO.toString());
        int step = passportApplyInputVO.getStep();
        String  sn = passportApplyInputVO.getSn();

        try
        {
            switch (step)
            {
                case 1:


                    PassportApply targetApply1 = JSON.toJavaObject(JSON.parseObject(redisClientTemplate.get(sn)),PassportApply.class);

                    targetApply1.setName(passportApplyInputVO.getName());
                    targetApply1.setCardNO(passportApplyInputVO.getCardNO());
                    targetApply1.setCardType(passportApplyInputVO.getCardType());
                    targetApply1.setApplyType(passportApplyInputVO.getApplyType());
                    targetApply1.setApplyCase(passportApplyInputVO.getApplyCase());
                    targetApply1.setSex(Tools.getGenderFromCardNO(passportApplyInputVO.getCardNO()));
                    targetApply1.setBirthday(Tools.getBirthFromCardNO(passportApplyInputVO.getCardNO()));
                    redisClientTemplate.set(sn, JSON.toJSONString(targetApply1));
                    //检查当前用户是否已申请过护照
                    if(targetApply1.getApplyType() == 10)
                    {
                        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findAllCardNO(targetApply1.getCardNO());
                        if(null != passportApplyOrder && passportApplyOrder.getStatus() != PassportApplyOrder.STAUTS_LOGOUT)
                        {
                            jsonResult.setCode(JsonResult.CODE_FAIL);
                            jsonResult.setMessage("您已申请过,不可以重叠申请");
                            return new ResponseEntity(jsonResult, HttpStatus.OK);
                        }
                    }
                    else if(targetApply1.getApplyType() > 10)
                    {
                        PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findAllCardNO(targetApply1.getCardNO());
                        if(null == passportApplyOrder)
                        {
                            jsonResult.setCode(JsonResult.CODE_FAIL);
                            jsonResult.setMessage("您还没有护照");
                            return new ResponseEntity(jsonResult, HttpStatus.OK);
                        }
                    }
                    jsonResult.setData(sn);
                    break;
                case 2:
                    PassportApply targetApply2 = JSON.toJavaObject(JSON.parseObject(redisClientTemplate.get(sn)),PassportApply.class);
                    targetApply2.setGuardianName(passportApplyInputVO.getGuardianName());
                    targetApply2.setGuardianRelation(passportApplyInputVO.getGuardianRelation());
                    targetApply2.setGuardianCardType(passportApplyInputVO.getGuardianCardType());
                    targetApply2.setGuardianCardNo(passportApplyInputVO.getGuardianCardNo());
                    targetApply2.setGuardianSex(passportApplyInputVO.getGuardianSex());
                    targetApply2.setGuardianPhone(passportApplyInputVO.getGuardianPhone());

                    targetApply2.setGuardianUnitCode(passportApplyInputVO.getGuardianUnitCode());
                    targetApply2.setGuardianUnit(passportApplyInputVO.getGuardianUnit());

                    redisClientTemplate.set(sn, JSON.toJSONString(targetApply2));
                    jsonResult.setData(sn);
                    break;
                case 3:
                    PassportApply targetApply3 = JSON.toJavaObject(JSON.parseObject(redisClientTemplate.get(sn)),PassportApply.class);
                    targetApply3.setAppointmenDate(passportApplyInputVO.getAppointmenDate());
                    targetApply3.setAppointmentTime(passportApplyInputVO.getAppointmentTime());
                    targetApply3.setCreateTime(Clock.DEFAULT.getCurrentDate());
                    targetApply3.setBassAddressId(passportApplyInputVO.getBassAddressId());
                    this.passportApplyService.save(targetApply3);

                    clearVeriferCode(sn);
                    PassportApplyOrder passportApplyOrder = passportApplyOrderService.findByCardNO(targetApply3.getBassAddressId(),PassportApplyOrder.STAUTS_WAITE,targetApply3.getCardNO());
                    log.info(passportApplyOrder.toString());
                    Map<String,String> map = new HashMap<String,String>();
                    map.put("bassAddressId",String.valueOf(passportApplyOrder.getBassAddressId()));
                    map.put("cardNO",passportApplyOrder.getCardNO());
                    map.put("orderNum",passportApplyOrder.getNum());
                    map.put("realName",passportApplyOrder.getName());
                    jsonResult.setData(map);
                    //将信息回传至平台
                    TradListVO vo = new TradListVO();
                    vo.setOrderCode(passportApplyInputVO.getOrderCode());
                    vo.setChannel(passportApplyInputVO.getChannelCode());
                    vo.setBusiness(passportApplyInputVO.getBusinessCode());
                    vo.setPassportCode(passportApplyOrder.getPassportNO());
                    vo.setPhone(passportApplyOrder.getMobile());
                    vo.setName(passportApplyOrder.getName());
                    vo.setCardType(passportApplyOrder.getCardType());
                    vo.setCardNo(passportApplyOrder.getCardNO());
                    vo.setFinishDate(new Date());

                    String jsonData = JSON.toJSONString(vo);
                    System.out.println(jsonData);
                    String callBackUrl = "https://pab.cvssp.cn/tradList/addTrad?jsonData=" + jsonData;
                    System.out.println(callBackUrl);
                    HttpsUtil.post(callBackUrl,"");
                    break;
            }

        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @ApiOperation(value = "公益护照申请并且直接激活")
    @RequestMapping(value = "/applyAndActivate",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> applyAndActivate(@RequestBody PassportApplyInputVO passportApplyInputVO)
    {
        JsonResult jsonResult = new JsonResult();
        log.info(passportApplyInputVO.toString());
        try
        {
//            //检查当前用户是否已申请过护照
//            PassportApplyOrder passportApplyOrder = this.passportApplyOrderService.findAllCardNO(passportApplyInputVO.getCardNO());
//            if(passportApplyInputVO.getApplyType() == 10 && null != passportApplyOrder && passportApplyOrder.getStatus() == PassportApplyOrder.STAUTS_WAITE)
//            {
//
//                Map<String,String> map = new HashMap<String,String>();
//                map.put("bassAddressId",String.valueOf(passportApplyOrder.getBassAddressId()));
//                map.put("cardNO",passportApplyOrder.getCardNO());
//                map.put("orderNum",passportApplyOrder.getNum());
//                map.put("realName",passportApplyOrder.getName());
//                jsonResult.setData(map);
//                return new ResponseEntity(jsonResult, HttpStatus.OK);
//            }
//            else
//            {
//                if(passportApplyInputVO.getApplyType() > 10 && null == passportApplyOrder)
//                {
//                    jsonResult.setCode(JsonResult.CODE_FAIL);
//                    jsonResult.setMessage("您还没有护照");
//                    return new ResponseEntity(jsonResult, HttpStatus.OK);
//                }
//                if(null != passportApplyOrder && passportApplyOrder.getStatus() != PassportApplyOrder.STAUTS_LOGOUT)
//                {
//                    jsonResult.setCode(JsonResult.CODE_FAIL);
//                    jsonResult.setMessage("您已申请过,不可以重叠申请");
//                    return new ResponseEntity(jsonResult, HttpStatus.OK);
//                }
//            }
//            if(passportApplyInputVO.getApplyType() > 10 && null != passportApplyOrder && passportApplyOrder.getStatus() != PassportApplyOrder.STAUTS_LOGOUT)
//            {
//                if(null == passportApplyOrder)
//                {
//                    jsonResult.setCode(JsonResult.CODE_FAIL);
//                    jsonResult.setMessage("您还没有护照");
//                    return new ResponseEntity(jsonResult, HttpStatus.OK);
//                }
//            }

            PassportApply passportApply = new PassportApply();
            passportApply.setMobile(passportApplyInputVO.getMobile());
            passportApply.setName(passportApplyInputVO.getName());
            passportApply.setCardNO(passportApplyInputVO.getCardNO());
            passportApply.setCardType(passportApplyInputVO.getCardType());
            passportApply.setApplyType(passportApplyInputVO.getApplyType());
            passportApply.setApplyCase(passportApplyInputVO.getApplyCase());
            passportApply.setSex(Tools.getGenderFromCardNO(passportApplyInputVO.getCardNO()));
            passportApply.setBirthday(Tools.getBirthFromCardNO(passportApplyInputVO.getCardNO()));
            passportApply.setBassAddressId(passportApplyInputVO.getBassAddressId());
            passportApply.setAppointmentTime("00:00-00:00");
            passportApply.setAppointmenDate("0000-00-00");

            passportApply.setGuardianName(passportApplyInputVO.getGuardianName());
            passportApply.setGuardianSex(passportApplyInputVO.getGuardianSex());
            passportApply.setGuardianCardNo(passportApplyInputVO.getGuardianCardNo());
            passportApply.setGuardianCardType(passportApplyInputVO.getGuardianCardType());
            passportApply.setGuardianRelation(passportApplyInputVO.getGuardianRelation());
            passportApply.setGuardianPhone(passportApplyInputVO.getGuardianPhone());

            this.passportApplyService.save(passportApply);

            PassportApplyOrder passportApplyOrder = passportApplyOrderService.findByCardNO(passportApply.getBassAddressId(),PassportApplyOrder.STAUTS_WAITE,passportApply.getCardNO());
            log.info(passportApplyOrder.toString());
            Map<String,String> map = new HashMap<String,String>();
            map.put("bassAddressId",String.valueOf(passportApplyOrder.getBassAddressId()));
            map.put("cardNO",passportApplyOrder.getCardNO());
            map.put("orderNum",passportApplyOrder.getNum());
            map.put("realName",passportApplyOrder.getName());
            jsonResult.setData(map);



            //将信息回传至平台
            String callBackUrl = "";
            IdcardInfoExtractor idcardInfoExtractor = new IdcardInfoExtractor(passportApplyInputVO.getCardNO());
            int age = idcardInfoExtractor.getAge();
            Map<String,String> paraMap = new HashMap<>();
            if(age<7)
            {
                callBackUrl = "https://pab.cvssp.cn/pingan/updateActivateRecord7";
                paraMap.put("idNo",passportApplyOrder.getCardNO());
                paraMap.put("passportNo",passportApplyOrder.getPassportNO());
                paraMap.put("realName",passportApplyOrder.getName());
                paraMap.put("mobile",passportApplyOrder.getGuardianPhone());
            }
            else
            {
                paraMap.put("passportNo",passportApplyOrder.getPassportNO());

                if(age<18)
                {
                    paraMap.put("idNo", passportApplyOrder.getCardNO());
                    paraMap.put("guardianCardNo", passportApplyOrder.getGuardianCardNo());
                    paraMap.put("realName",passportApplyOrder.getName());
                    callBackUrl = "https://pab.cvssp.cn/pingan/updateActivateRecord18";
                }
                else {
                    paraMap.put("idNo", passportApplyOrder.getCardNO());
                    callBackUrl = "https://pab.cvssp.cn/pingan/updateActivateRecord";
                }
            }

            log.info("applyAndActivate callBackUrl---1--->"+callBackUrl);
            log.info("applyAndActivate callBackUrl---2--->"+paraMap.toString());
            HttpsClientUtil.doPost(callBackUrl,paraMap);



        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @ApiOperation(value = "公益护照申请并且直接激活,小18岁")
    @RequestMapping(value = "/applyAndActivate418",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> applyAndActivate418(@RequestBody PassportApplyInputVO passportApplyInputVO)
    {
        JsonResult jsonResult = new JsonResult();
        log.info(passportApplyInputVO.toString());
        try
        {
            PassportApply passportApply = new PassportApply();
            passportApply.setMobile(passportApplyInputVO.getMobile());
            passportApply.setName(passportApplyInputVO.getName());
            passportApply.setCardNO(passportApplyInputVO.getCardNO());
            passportApply.setCardType(passportApplyInputVO.getCardType());
            passportApply.setApplyType(passportApplyInputVO.getApplyType());
            passportApply.setApplyCase(passportApplyInputVO.getApplyCase());
            passportApply.setSex(Tools.getGenderFromCardNO(passportApplyInputVO.getCardNO()));
            passportApply.setBirthday(Tools.getBirthFromCardNO(passportApplyInputVO.getCardNO()));
            passportApply.setBassAddressId(passportApplyInputVO.getBassAddressId());
            passportApply.setAppointmentTime("00:00-00:00");
            passportApply.setAppointmenDate("0000-00-00");
            this.passportApplyService.save(passportApply);

            PassportApplyOrder passportApplyOrder = passportApplyOrderService.findByCardNO(passportApply.getBassAddressId(),PassportApplyOrder.STAUTS_WAITE,passportApply.getCardNO());
            log.info(passportApplyOrder.toString());
            Map<String,String> map = new HashMap<String,String>();
            map.put("bassAddressId",String.valueOf(passportApplyOrder.getBassAddressId()));
            map.put("cardNO",passportApplyOrder.getCardNO());
            map.put("orderNum",passportApplyOrder.getNum());
            map.put("realName",passportApplyOrder.getName());
            jsonResult.setData(map);

            //将信息回传至平台
            String callBackUrl = "https://pab.cvssp.cn/pingan/updateActivateRecord?idNo=" + passportApplyOrder.getGuardianCardNo()
                    + "&passportNo=" + passportApplyOrder.getPassportNO();
            System.out.println(callBackUrl);
            HttpsUtil.post(callBackUrl,"");


        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    @ApiOperation(value = "公益护照预约订单详情")
    @RequestMapping(value = "/orderDetail",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> orderDetail(@RequestParam("orderNum") String orderNum,@RequestParam("realName") String realName)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> map = new HashMap<String,Object>();
        PassportApplyOrder passportApplyOrder = passportApplyOrderService.findByRealnameAndNum(realName,orderNum);
        map.put("order",passportApplyOrder);
        jsonResult.setData(map);
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    private void clearVeriferCode(String key)
    {
        redisClientTemplate.del(key);
    }
}
 
 