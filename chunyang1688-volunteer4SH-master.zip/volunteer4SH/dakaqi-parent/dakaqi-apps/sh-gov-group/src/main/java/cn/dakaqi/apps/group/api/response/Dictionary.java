/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.response;

import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 类名称：Dictionary <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/7 15:10
 * @version: 1.0.0
 */
@Data
@ToString
@Slf4j
public class Dictionary implements Serializable
{
    String code;
    String name;

    public Dictionary()
    {
    }

    public Dictionary(String code, String name)
    {
        this.code = code;
        this.name = name;
    }
}
 
 