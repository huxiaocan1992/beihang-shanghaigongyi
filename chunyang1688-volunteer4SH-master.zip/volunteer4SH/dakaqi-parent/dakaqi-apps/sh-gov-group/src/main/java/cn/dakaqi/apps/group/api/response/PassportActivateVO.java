/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.response;

import com.wordnik.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 类名称：PassportActivateVO <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/9 13:52
 * @version: 1.0.0
 */
@ToString
@Data
@Slf4j
@ApiModel
public class PassportActivateVO implements Serializable
{
    private String passportNo;
    private String mobile;
    private String idNo;
    private String groupCode;
    private String channelCode;
    private String businessCode;
    private String realName;
    private int status;
}
 
 