package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.apps.group.admin.shiro.ShiroDbRealm;
import cn.dakaqi.entities.BaseAddress;
import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.PassportAppointmentDate;
import cn.dakaqi.services.BaseAddressService;
import cn.dakaqi.services.PassportAppointmentDateService;
import cn.dakaqi.utils.JsonResult;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: BaseAddressController <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/9/27 11:33
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/appointmentDate")
@Slf4j
@ApiIgnore
public class AppointmentDateController extends BaseController
{
    @Autowired
    BaseAddressService baseAddressService;
    @Autowired
    PassportAppointmentDateService passportAppointmentDateService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ModelAndView list(@RequestParam(value = "page", defaultValue = "1") int pageNumber,
                             @RequestParam(value = "page.size", defaultValue = PAGE_SIZE) int pageSize,
                             @RequestParam(value = "sortType", defaultValue = "auto") String sortType,
                             HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "appointmentDate/index";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        Page<PassportAppointmentDate> data = passportAppointmentDateService.findAll(baseAddress.getId(),pageNumber);
        modelAndView.addObject("data",data);
        return modelAndView;
    }
    @RequestMapping(value = "/toadd", method = RequestMethod.GET)
    public ModelAndView toadd(HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        String view = "appointmentDate/singleForm";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        return modelAndView;
    }
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ResponseEntity<?> save(@RequestParam("day") String day,@RequestParam("time") String time,@RequestParam("num") int num,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        JsonResult result = new JsonResult();
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        passportAppointmentDateService.save(baseAddress.getId(),day,time,num);
        result.setCode(JsonResult.CODE_SUCCESS);
        result.setMessage("提交成功");
        return new ResponseEntity(result, HttpStatus.OK);
    }
    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        modelAndView = new ModelAndView(view,modelMap);
        return modelAndView;
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }

    /**
     * 取出Shiro中的当前用户Id.
     */
    private Long getCurrentUserId()
    {
        ShiroDbRealm.ShiroUser user = (ShiroDbRealm.ShiroUser) SecurityUtils.getSubject().getPrincipal();
        return user.id;
    }
}
