/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.input;

import com.wordnik.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.Date;

/**
 * 类名称：PassportApplyInputVO <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/8 17:22
 * @version: 1.0.0
 */
@ToString
@Data
@Slf4j
@ApiModel
public class PassportApplyInputVO implements Serializable
{
    private int step;//提交步骤
    private String sn;//暂时放在内存中的唯一标识
    private String channelCode;
    private String businessCode;
    private String orderCode;//平台分配的订单号
    private String name;//姓名
    private String sex;//性别
    private String cardType;//证件类型
    private String cardNO;//证件号
    private String mobile;//手机号
    private long bassAddressId;//基地编号
    private String note;//预约留言
    private String appointmenDate;//预约时间
    private String appointmentTime;//预约时间
    private String head;//照片
    private Date createTime;//申请时间

    private String birthday;//出生生日
    private int applyType;//申请类型 10 首次 20 换发 30 补发
    private String applyCase;//在换发、补发的情况下，需要选择原因
    private String contactName;//联系人姓名
    private String contactPhone;//联系人电话
    private String contactAddress;//联系人地址

    //监护人
    private String guardianName;//监护人姓名
    private String guardianSex;//监护人性别
    private String guardianRelation;//监护人关系
    private String guardianPhone;//监护人电话
    private String guardianCardType;//监护人证件类型
    private String guardianCardNo;//监护人证件号
    private String guardianUnit;//监护单位名称
    private String guardianUnitCode;//监护单位编号
}
 
 