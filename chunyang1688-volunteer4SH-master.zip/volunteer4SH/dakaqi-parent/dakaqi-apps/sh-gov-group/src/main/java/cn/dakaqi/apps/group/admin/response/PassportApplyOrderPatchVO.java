package cn.dakaqi.apps.group.admin.response;

import cn.dakaqi.entities.PassportApplyOrder;
import cn.dakaqi.entities.PassportApplyOrderPatch;
import lombok.Data;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: PassportApplyOrderPatchVO <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/10/25 17:22
 * @version: 1.0.0
 */
@Data
public class PassportApplyOrderPatchVO implements Serializable
{

    private PassportApplyOrderPatch patch;
    private PassportApplyOrder order;
    private static final long serialVersionUID = 1732207246550900312L;
    public static PassportApplyOrderPatchVO buildVO(PassportApplyOrder order,PassportApplyOrderPatch patch)
    {
        PassportApplyOrderPatchVO vo = new PassportApplyOrderPatchVO();
        vo.setPatch(patch);
        vo.setOrder(order);
        return vo;
    }
}
