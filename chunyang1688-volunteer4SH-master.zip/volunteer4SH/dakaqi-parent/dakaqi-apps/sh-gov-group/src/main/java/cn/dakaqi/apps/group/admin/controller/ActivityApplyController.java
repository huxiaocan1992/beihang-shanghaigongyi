package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.apps.group.admin.utils.PageCache;
import cn.dakaqi.entities.ActivityApply;
import cn.dakaqi.entities.Group;
import cn.dakaqi.services.ActivityApplyService;
import cn.dakaqi.utils.DKQConstant;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by chunyang on 2016/5/9.
 */
@Controller
@RequestMapping(value = "/activityapply")
@Slf4j
@ApiIgnore
public class ActivityApplyController extends BaseController
{
    @Autowired
    PageCache pageCache;
    @Autowired
    ActivityApplyService activityApplyService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        modelAndView = new ModelAndView(view,modelMap);
        return modelAndView;
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }
    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView list(@RequestParam("activityCode") String activityCode,@RequestParam(value = "pageNumber",defaultValue = "1") int pageNumber,HttpServletRequest request)
    {
        String view = "activityapply/index";
        Group group = getCurGroup(request);
        String key = group.getGroupCode()+"/"+view;
        if(pageCache.exists(key))
        {
            modelAndView = pageCache.getModelAndView(key);
        }
        else
        {
            modelAndView = initModelAndView(group.getGroupCode(), view,request);
            //查询当前社团的所有活动
            Page<ActivityApply> data = this.activityApplyService.queryByActivity(activityCode, DKQConstant.APPLY_STATUS_OK,pageNumber);
            modelAndView.addObject("data",data);
            pageCache.setModelAndView(key,modelAndView);
        }
        return modelAndView;
    }
    @RequestMapping(value = "/waiteVerifer",method = RequestMethod.GET)
    public ModelAndView waiteVerifer(@RequestParam("activityCode") String activityCode,@RequestParam(value = "pageNumber",defaultValue = "1") int pageNumber,HttpServletRequest request)
    {
        String view = "activityapply/waiteVerifer";
        Group group = getCurGroup(request);
        String key = group.getGroupCode()+"/"+view;
        if(pageCache.exists(key))
        {
            modelAndView = pageCache.getModelAndView(key);
        }
        else
        {
            modelAndView = initModelAndView(group.getGroupCode(), view,request);
            //查询当前社团的所有活动
            Page<ActivityApply> data = this.activityApplyService.queryByActivity(activityCode, DKQConstant.APPLY_STATUS,pageNumber);
            modelAndView.addObject("data",data);
            pageCache.setModelAndView(key,modelAndView);
        }
        return modelAndView;
    }

}
