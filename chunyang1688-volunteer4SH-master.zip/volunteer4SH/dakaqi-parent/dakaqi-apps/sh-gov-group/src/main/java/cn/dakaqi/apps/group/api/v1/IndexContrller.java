/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.v1;

/**
 * 类名称：IndexContrller <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/6 15:02
 * @version: 1.0.0
 */

import cn.dakaqi.apps.group.api.response.IndexVO;
import cn.dakaqi.utils.JsonResult;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/v1/index")
@Slf4j
@Api(value = "首页")
public class IndexContrller
{
    @ApiOperation(value = "首页数据")
    @RequestMapping(method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> index()
    {
        JsonResult jsonResult = new JsonResult();
        IndexVO indexVO = new IndexVO();
        indexVO.setAdsImg("http://img.dakaqi.cn/055bfdb8e-ccc5-48ee-b185-4dd03da6b701.jpg");
        indexVO.setAdsUrl("http://www.163.com");
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("indexVO", indexVO);
        jsonResult.setData(resultMap);
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}
 
 