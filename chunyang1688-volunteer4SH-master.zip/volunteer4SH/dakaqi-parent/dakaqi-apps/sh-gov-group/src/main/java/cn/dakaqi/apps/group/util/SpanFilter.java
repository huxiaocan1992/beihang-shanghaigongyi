/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.util;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 类名称：SpanFilter <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/12 9:27
 * @version: 1.0.0
 */

@SuppressWarnings("unused")
@Component
public class SpanFilter implements Filter
{
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain filter) throws IOException, ServletException
    {
        HttpServletResponse response = (HttpServletResponse) res;
        HttpServletRequest request = (HttpServletRequest) req;
        response.setHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
        filter.doFilter(req, res);
    }

    @Override
    public void destroy() {
        System.out.println("~~~~~~destroy~~~~~~~~~");
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        System.out.println("~~~~~~~init~~~~~~~~~");
    }

}
 