package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: BaseAddressAppointDateVO <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/10/26 15:20
 * @version: 1.0.0
 */
@Data
public class BaseAddressAppointDateVO implements Serializable
{
    private static final long serialVersionUID = 1838915319215824872L;
    private String day;
    private List<String> times;

    public BaseAddressAppointDateVO()
    {
    }

    public BaseAddressAppointDateVO(String day, List<String> times)
    {
        this.day = day;
        this.times = times;
    }
}
