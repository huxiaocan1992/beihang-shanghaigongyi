/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.admin.utils;

/**
 * 类名称：Tools <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/2 11:06
 * @version: 1.0.0
 */

public class Tools
{

    public static String getBirthFromCardNO(String icard)
    {
        int len = icard.length();
        StringBuilder ymd = new StringBuilder();
        switch (len)
        {
            case 15:

                ymd.append("19").append(icard.substring(6, 12));
                break;
            case 18:
                ymd.append(icard.substring(6, 14));
                break;
            default:
                return "2010-01-01";
        }
        return ymd.substring(0, 4) + "-" + ymd.substring(4, 6) + "-" + ymd.substring(6, 8);
    }

    public static String getGenderFromCardNO(String icard)
    {
        int len = icard.length();
        String sex = "男";
        switch (len)
        {
            case 15:
                //String birth1 = icard.substring(6, 12);
                sex = icard.substring(14, 15);
                if (Integer.parseInt(sex) % 2 == 0)
                {
                    sex = "女";
                } else
                {
                    sex = "男";

                }
                break;
            case 18:
                //String birth2 = icard.substring(6, 14);
                sex = icard.substring(16, 17);
                if (Integer.parseInt(sex) % 2 == 0)
                {
                    sex = "女";
                } else
                {
                    sex = "男";

                }
                break;
        }
        return sex;
    }
}
 
 