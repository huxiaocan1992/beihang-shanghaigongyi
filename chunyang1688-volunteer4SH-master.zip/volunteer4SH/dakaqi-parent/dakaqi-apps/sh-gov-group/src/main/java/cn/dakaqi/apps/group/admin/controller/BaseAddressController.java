package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.apps.group.admin.shiro.ShiroDbRealm;
import cn.dakaqi.entities.ApproveAddress;
import cn.dakaqi.entities.BaseAddress;
import cn.dakaqi.entities.Group;
import cn.dakaqi.services.ApproveAddressService;
import cn.dakaqi.services.BaseAddressService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.DateUtil;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: BaseAddressController <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/9/27 11:33
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/baseaddress")
@Slf4j
@ApiIgnore
public class BaseAddressController extends BaseController
{
    @Autowired
    BaseAddressService baseAddressService;
    @Autowired
    ApproveAddressService approveAddressService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        modelAndView = new ModelAndView(view,modelMap);
        return modelAndView;
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }
    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView detail(HttpServletRequest request)
    {
        String view = "baseaddress/singleForm";
        Group group = getCurGroup(request);
        modelAndView = initModelAndView(group.getGroupCode(), view,request);
        BaseAddress baseAddress = this.baseAddressService.findByUserId(getCurrentUserId());
        if(null == baseAddress)
            baseAddress = new BaseAddress();
        else
        {
            String info = "",remark1 = "",remark2 = "";
            switch (baseAddress.getVerfierStatus())
            {
                case 0:
                    info = "不知道";
                    break;
                case 1:
                    info= "审核中";
                    break;
                case 2:
                case -1:
                    if(baseAddress.getVerfierStatus() == -1)
                        info = "被退回";
                    else
                        info = "已通过";

                    ApproveAddress approveAddress = this.approveAddressService.findByBaseAddressId(baseAddress.getId());
                    if(null != approveAddress)
                    {
                        remark1 = approveAddress.getRemark();
                        remark2 = approveAddress.getRemarkSecond();
                    }
                    break;
            }
            modelAndView.addObject("info", info);
            modelAndView.addObject("remark1", remark1);
            modelAndView.addObject("remark2", remark2);
        }
        modelAndView.addObject("baseAddress", baseAddress);

        return modelAndView;
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public RedirectView create(@Valid BaseAddress baseAddress,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        Group group = getCurGroup(request);
        baseAddress.setCreateTime(DateUtil.getToday());
        baseAddress.setDelStatus(DKQConstant.DEL_NO);
        baseAddress.setVerfierStatus(1);
        baseAddress.setUserId(this.getCurrentUserId());
        if(null != group)
        baseAddress.setGroupId(group.getId());
        this.baseAddressService.saveBaseAddress(baseAddress);
        String url = request.getContextPath()+"/baseaddress";
        redirectAttributes.addFlashAttribute("message", "提交成功,等待审核");
        return new RedirectView(url);

    }

    /**
     * 取出Shiro中的当前用户Id.
     */
    private Long getCurrentUserId()
    {
        ShiroDbRealm.ShiroUser user = (ShiroDbRealm.ShiroUser) SecurityUtils.getSubject().getPrincipal();
        return user.id;
    }
}
