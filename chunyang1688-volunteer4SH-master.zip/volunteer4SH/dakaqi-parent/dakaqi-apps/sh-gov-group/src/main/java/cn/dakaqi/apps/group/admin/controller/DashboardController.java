package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.GroupService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.BaseDAO;
import cn.dakaqi.utils.DKQConstant;
import com.mangofactory.swagger.annotations.ApiIgnore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by chunyang on 2016/5/9.
 */
@Controller
@RequestMapping(value = "/dashboard")
@ApiIgnore
public class DashboardController extends BaseController
{
    @Autowired
    BaseDAO baseDAO;
    @Autowired
    VolunteerService volunteerService;

    @Autowired
    GroupService groupService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        Group group = (Group)modelMap.get("group");
        //检查用户是否完善过个人资料
        Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
        if(null != volunteer && volunteer.getIsFinished() == DKQConstant.USER_IS_FINISH_NO)
        {
            view = "settings/certification";
            ModelAndView modelAndView = new ModelAndView(view, modelMap);
            modelAndView.addObject("volunteer", volunteer);
            modelAndView.addObject("message", "请完善个人信息");
            return modelAndView;
        }
        //Group group = (Group)request.getSession().getAttribute("curGroup");
        if(null == group)
        {
            String empty = "dashboard/empty";
            return  new ModelAndView(empty,modelMap);
        }
        return new ModelAndView(view,modelMap);
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView index(@RequestParam(value = "groupCode",defaultValue = "") String groupCode,HttpServletRequest request)
    {
        Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
        if(null != volunteer && volunteer.getIsFinished() == DKQConstant.USER_IS_FINISH_NO)
        {
            ModelMap modelMap = super.initData(groupCode,request);
            String view = "settings/certification";
            ModelAndView modelAndView = new ModelAndView(view, modelMap);
            modelAndView.addObject("volunteer", volunteer);
            modelAndView.addObject("message", "请完善个人信息");
            return modelAndView;
        }
        else
        {
            String view = "dashboard/index";
            modelAndView = initModelAndView(groupCode, view,request);
//            if(StringUtils.isNotBlank(groupCode))
//            {
//                group = this.groupService.findByGroupCode(groupCode);
//
//                request.getSession().setAttribute("curGroup",group);
//            }
        }

        return modelAndView;
    }
}
