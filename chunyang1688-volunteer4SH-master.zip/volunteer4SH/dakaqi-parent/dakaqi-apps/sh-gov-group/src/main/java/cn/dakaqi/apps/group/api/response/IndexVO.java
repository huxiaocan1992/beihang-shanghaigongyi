/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.response;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * 类名称：IndexVO <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/6 15:03
 * @version: 1.0.0
 */

@Data
@ToString
@Slf4j
@ApiModel
public class IndexVO implements Serializable
{
    @ApiModelProperty(value = "广告图片")
    private String adsImg;
    @ApiModelProperty(value = "广告图片跳转地址")
    private String adsUrl;
}
 
 