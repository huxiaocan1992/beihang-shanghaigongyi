package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.qiniu.QNiuToken;
import com.mangofactory.swagger.annotations.ApiIgnore;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/18.
 * 七牛TOKEN获取
 */
@RestController
@RequestMapping(value = "/api/common")
@ApiIgnore
public class QiNiuRestController
{
    @RequestMapping(value = "/qiniu/token",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> token()
    {
        JsonResult result = new JsonResult();
        try
        {
            String token = QNiuToken.token("dakaqi");
            result.setCode(JsonResult.CODE_SUCCESS);
            result.setMessage("获取成功");
            Map<String,Object> resultMap = new HashMap<String,Object>();
            resultMap.put("token",token);
            result.setData(resultMap);
        } catch (Exception e)
        {
            result.setCode(JsonResult.CODE_FAIL);
            result.setMessage(e.getMessage());
            result.setData("");
        }
        return new ResponseEntity<Object>(result, HttpStatus.OK);
    }
}
