package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.apps.group.admin.utils.PageCache;
import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.entities.Group;
import cn.dakaqi.services.ActivitySignService;
import com.mangofactory.swagger.annotations.ApiIgnore;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by chunyang on 2016/5/9.
 */
@Controller
@RequestMapping(value = "/activitysign")
@Slf4j
@ApiIgnore
public class ActivitySignController extends BaseController
{
    @Autowired
    PageCache pageCache;
    @Autowired
    ActivitySignService activitySignService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        modelAndView = new ModelAndView(view,modelMap);
        return modelAndView;
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }
    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView list(@RequestParam("activityCode") String activityCode,@RequestParam(value = "pageNumber",defaultValue = "1") int pageNumber,HttpServletRequest request)
    {
        String view = "activitysign/index";
        Group group = getCurGroup(request);
        String key = group.getGroupCode()+"/"+view;
        if(pageCache.exists(key))
        {
            modelAndView = pageCache.getModelAndView(key);
        }
        else
        {
            modelAndView = initModelAndView(group.getGroupCode(), view,request);
            //查询当前社团的所有活动
            Page<ActivitySign> data = this.activitySignService.queryByActivity(activityCode,pageNumber);
            modelAndView.addObject("data",data);
            pageCache.setModelAndView(key,modelAndView);
        }
        return modelAndView;
    }
}
