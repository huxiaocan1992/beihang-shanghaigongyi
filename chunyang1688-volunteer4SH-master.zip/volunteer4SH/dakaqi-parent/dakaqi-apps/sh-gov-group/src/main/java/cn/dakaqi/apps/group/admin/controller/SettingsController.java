package cn.dakaqi.apps.group.admin.controller;

import cn.dakaqi.entities.Group;
import cn.dakaqi.entities.user.Volunteer;
import cn.dakaqi.services.user.UserService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.IdCardUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.mangofactory.swagger.annotations.ApiIgnore;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;
import org.springside.modules.web.MediaTypes;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Map;

/**
 * Created by chunyang on 2016/5/12.
 */
@RestController
@RequestMapping(value = "/settings")
@ApiIgnore
public class SettingsController extends BaseController
{
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    UserService userService;

    @Override
    protected ModelAndView initModelAndView(String groupCode,String view,HttpServletRequest request)
    {
        ModelMap modelMap = super.initData(groupCode,request);
        return new ModelAndView(view,modelMap);
    }
    @Override
    protected void clearModelAndView(String groupCode,HttpServletRequest request)
    {

    }
    private Group getCurGroup(HttpServletRequest request)
    {
        return ((Group)request.getSession().getAttribute("curGroup"));
    }
    @RequestMapping(value = "/changePwd",method = RequestMethod.GET)
    public ModelAndView toUpdatePage(HttpServletRequest request)
    {
        String view = "settings/change_password";
        Group group = getCurGroup(request);
        String groupCode = group==null?"":group.getGroupCode();
        modelAndView = initModelAndView(groupCode, view,request);
        return modelAndView;
    }
    @RequestMapping(value = "/changeMobile",method = RequestMethod.GET)
    public ModelAndView changeMobile(HttpServletRequest request)
    {
        String view = "settings/change_mobile";
        Group group = getCurGroup(request);
        String groupCode = group==null?"":group.getGroupCode();
        modelAndView = initModelAndView(groupCode, view,request);
        return modelAndView;
    }
    @RequestMapping(value = "/certification",method = RequestMethod.GET)
    public ModelAndView updateVolunteerInfo(HttpServletRequest request)
    {
        String view = "settings/certification";
        Group group = getCurGroup(request);
        String groupCode = group==null?"":group.getGroupCode();
        modelAndView = initModelAndView(groupCode, view,request);
        Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
        modelAndView.addObject("volunteer",volunteer);
        return modelAndView;
    }
    @RequestMapping(value = "/certification",method = RequestMethod.POST)
    public RedirectView certification(Volunteer volunteer,HttpServletRequest request,RedirectAttributes redirectAttributes)
    {
        if(StringUtils.isNotBlank(volunteer.getSkill()))
            volunteer.setSkill(volunteer.getSkill().replace(",",";"));
        if(StringUtils.isNotBlank(volunteer.getServiceField()))
            volunteer.setServiceField(volunteer.getServiceField().replace(",", ";"));
        volunteer.setResidenceAddress(volunteer.getProvince() + "-" + volunteer.getCity() + "-" + volunteer.getDistrict());
        volunteer.setIsFinished(DKQConstant.USER_IS_FINISH_YES);


        try
        {
            boolean checkIdValidate= IdCardUtil.IDCardValidate(volunteer.getCardNO());
            if(!checkIdValidate){
                String url = request.getContextPath()+"/settings/certification";
                redirectAttributes.addFlashAttribute("message", "身份证号不合法");
                return new RedirectView(url);
            }

        } catch (ParseException e)
        {
            e.printStackTrace();
            String url = request.getContextPath()+"/settings/certification";
            redirectAttributes.addFlashAttribute("message", e.getMessage());
            return new RedirectView(url);
        }

        this.volunteerService.updateVolunteer(volunteer);
        request.getSession().setAttribute("volunteer",volunteer);

        //
        String url = request.getContextPath()+"/settings/certification";
        redirectAttributes.addFlashAttribute("message", "提交成功");
        return new RedirectView(url);
    }
    @ModelAttribute
    public void getGroup(@RequestParam(value = "id", required = false,defaultValue = "0") long id, Map<String, Object> map)
    {
        if (id>0)
        {
            Volunteer volunteer = volunteerService.findOne(id);
            map.put("volunteer", volunteer);
        }
    }
    @ResponseBody
    @RequestMapping(value = "/updatePwd",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> updatePwd(@RequestParam("oldP") String oldP,@RequestParam("newP") String newP,HttpServletRequest request)
    {
        JsonResult jsonResult = new JsonResult();
        String  message;
        try
        {
            if(StringUtils.isBlank(oldP) || StringUtils.isBlank(newP))
            {
                message =  "密码不能为空";
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage(message);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            Volunteer volunteer = (Volunteer)request.getSession().getAttribute("volunteer");
            this.userService.updatePsswd(volunteer.getUserId(), oldP, newP);
            message =  "密码修改成功";
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            message =  e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            message =  e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        jsonResult.setMessage(message);
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    @ResponseBody
    @RequestMapping(value = "/changeMobile",method = RequestMethod.POST,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> changeMobile(@RequestParam("oldM") String oldM,@RequestParam("newM") String newM,@RequestParam("code") String code)
    {
        JsonResult jsonResult = new JsonResult();
        String  message;
        try
        {
            this.userService.updateMobile(oldM,newM,code);
            message =  "更换成功";
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            message =  e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            message =  e.getMessage();
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        jsonResult.setMessage(message);
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

}
