/**
 * Copyright:Copyright(c) 2016
 * Company:上海悠活网络科技有限公司
 */
package cn.dakaqi.apps.group.api.v1;

import cn.dakaqi.apps.group.admin.response.BaseAddressAppointDateVO;
import cn.dakaqi.entities.BaseAddress;
import cn.dakaqi.entities.PassportAppointmentDate;
import cn.dakaqi.services.BaseAddressService;
import cn.dakaqi.services.PassportAppointmentDateService;
import cn.dakaqi.utils.DateUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springside.modules.web.MediaTypes;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 类名称：BaseAddressController <br>
 * 类描述：<br>
 *
 * @author: chunyang.Zhang
 * @since: 2016/12/6 17:07
 * @version: 1.0.0
 */
@Controller
@RequestMapping(value = "/v1/address4base")
@Slf4j
@Api(value = "公益基地")
public class Address4BaseController
{
    @Autowired
    BaseAddressService baseAddressService;
    @Autowired
    PassportAppointmentDateService passportAppointmentDateService;

    @ApiOperation(value = "查询指定区县的基地")
    @RequestMapping(value = "/findByAddress",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findByAddress(@RequestParam("district") String district)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            List<BaseAddress> list = baseAddressService.findByAddressLike(district);
            if(null == list || list.size() == 0)
            {
                jsonResult.setMessage("暂无基地");
                jsonResult.setCode(JsonResult.CODE_FAIL);
            }
            else
            {
                jsonResult.setMessage("成功");
                jsonResult.setData(list);
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
            }
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setMessage(e.getMessage());
            jsonResult.setCode(JsonResult.CODE_FAIL);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @ApiOperation(value = "查询指定基地的可预约时间段")
    @RequestMapping(value = "/findAddressAppointTime",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findAddressAppointTime(@RequestParam("baseAddressId") Long baseAddressId)
    {
        JsonResult result = new JsonResult();
        try
        {
            try
            {
                List<BaseAddressAppointDateVO> vos = new ArrayList<BaseAddressAppointDateVO>();
                String startDay = "",endDay = "";
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String curDay = sdf.format(new Date());
                startDay = DateUtil.getAfterDay(curDay,5);
                endDay = DateUtil.getAfterDay(curDay,11);

                result.setCode(JsonResult.CODE_SUCCESS);
                List<PassportAppointmentDate> temp = this.passportAppointmentDateService.findAfterByBaseaddressId(baseAddressId,startDay,endDay);
                if(null != temp && temp.size()>0)
                {
                    Map<String,LinkedList<String>> map = new TreeMap<String,LinkedList<String>>();
                    for(PassportAppointmentDate pad:temp)
                    {
                        if(pad.getDay().compareTo(endDay) > 0 )
                            break;
                        if(map.isEmpty() && map.size() == 0)
                        {
                            LinkedList<String> times = new LinkedList<String>();
                            times.add(pad.getTimes().trim());
                            map.put(pad.getDay().trim(),times);
                        }
                        else
                        {
                            LinkedList<String> times = map.get(pad.getDay());
                            if(null == times)
                            {
                                times = new LinkedList<String>();
                                times.add(pad.getTimes().trim());
                                map.put(pad.getDay().trim(),times);
                            }
                            else
                            {
                                times.add(pad.getTimes().trim());
                            }
                        }
                    }
                    for(Map.Entry entry:map.entrySet())
                    {
                        vos.add(new BaseAddressAppointDateVO((String)entry.getKey(),(List<String>)entry.getValue()));
                    }
                    result.setData(vos);
                    return new ResponseEntity(result,HttpStatus.OK);
                }
                else
                {
                    result.setCode(JsonResult.CODE_FAIL);
                    result.setMessage("暂无可预约时间");
                    result.setData(new HashMap<>());
                    return new ResponseEntity(result,HttpStatus.OK);
                }
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            result.setMessage(e.getMessage());
            result.setCode(JsonResult.CODE_FAIL);
            return new ResponseEntity(result,HttpStatus.OK);
        }
        return new ResponseEntity(result,HttpStatus.OK);
    }
}
 
 