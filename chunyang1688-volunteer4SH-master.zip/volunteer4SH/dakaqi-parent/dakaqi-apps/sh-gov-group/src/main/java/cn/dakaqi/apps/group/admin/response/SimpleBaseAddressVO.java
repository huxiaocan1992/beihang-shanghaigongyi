package cn.dakaqi.apps.group.admin.response;

import lombok.Data;

import java.io.Serializable;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: SimpleBaseAddressVO <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/10/26 14:22
 * @version: 1.0.0
 */
@Data
public class SimpleBaseAddressVO implements Serializable
{

    private static final long serialVersionUID = -6319814091773279715L;
    private long id;
    private String name;

    public SimpleBaseAddressVO()
    {
    }

    public SimpleBaseAddressVO(long id, String name)
    {
        this.id = id;
        this.name = name;
    }
}
