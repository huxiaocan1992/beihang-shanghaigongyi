package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.GroupRecruit;
import cn.dakaqi.entities.GroupRecruitVolunteer;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.vo.response.GroupRecruitVO;
import cn.dakaqi.vo.response.GroupRecruitVolunteerVO;
import cn.dakaqi.vo.response.DKQPage;
import cn.dakaqi.services.GroupRecruitService;
import cn.dakaqi.services.GroupRecruitVolunteerService;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.ErrorCodeMsg;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/24.
 */
@RestController
@RequestMapping(value = "/api/v1/groupRecruit")
@Slf4j
@Api(value = "社团招募API")
public class GroupRecruitRestController
{
    @Autowired
    private GroupRecruitService groupRecruitService;
    @Autowired
    private GroupRecruitVolunteerService groupRecruitVolunteerService;

    /**
     * 发布招募
     * @param param
     * @return
     */
    @RequestMapping(value = "/create",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            this.groupRecruitService.create(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("发布成功");
        }
        catch (ServiceRuntimeException e)
        {
                e.printStackTrace();
                jsonResult.setCode(e.getCode());
                jsonResult.setMessage(e.getMessage());
                return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询招募详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findOne(@PathVariable("id") Long id)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Map<String,Object> resultMap = new HashMap<String,Object>();
            GroupRecruit groupRecruit = this.groupRecruitService.findOne(id);
            resultMap.put("groupRecruit", GroupRecruitVO.buildVO(groupRecruit, ConfigUtil.getClientId()));
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 退出招募
     * @param param
     * @return
     */
    @RequestMapping(value = "/exit",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> exit(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            this.groupRecruitVolunteerService.exit(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("退出成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 是否已报名参加招募
     * @param groupRecruitId
     * @param memberCode
     * @return
     */
    @RequestMapping(value = "/isApply/{memberCode}/{groupRecruitId}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> isApply(@PathVariable("groupRecruitId") Long groupRecruitId,@PathVariable("memberCode") String memberCode)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String, Object>();
        try
        {
            if(null == memberCode || "null".equals(memberCode) || StringUtils.isBlank(memberCode))
            {
                resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
                jsonResult.setData(resultMap);
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                return new ResponseEntity(jsonResult, HttpStatus.OK);
            }
            GroupRecruitVolunteer data = this.groupRecruitVolunteerService.isApply(groupRecruitId,memberCode);

            if(null != data)
            {
                if(data.getStatus() != DKQConstant.APPLY_STATUS_EXIT)
                    resultMap.put("isApply",data.getStatus());
                else
                    resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);

                resultMap.put("refuseCase",data.getRefuseCase());
            }
            else
            {
                resultMap.put("isApply", DKQConstant.APPLY_UN_APPLY_STATUS);
            }
            jsonResult.setData(resultMap);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }

    /**
     * 报名参加招募
     * @param param
     * @return
     */
    @RequestMapping(value = "/apply",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> apply(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            this.groupRecruitVolunteerService.create(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("等待管理员审核");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(e.getCode());
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定招募的成员（根据审核状态）
     * @param groupRecruitId
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/volunteers/{groupRecruitId}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> volunteers(@PathVariable("groupRecruitId") Long groupRecruitId,@PathVariable("status") Integer status,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<GroupRecruitVolunteer> data = this.groupRecruitVolunteerService.findByGroupRecruit(groupRecruitId, status, pageNumber);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            Map<String,Object> resultMap = new HashMap<String,Object>();

            List<GroupRecruitVolunteerVO> vos = new ArrayList<GroupRecruitVolunteerVO>();
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(GroupRecruitVolunteer aa:data.getContent())
                    vos.add(GroupRecruitVolunteerVO.buildVO(aa));
            }

            resultMap.put("list", vos);
            resultMap.put("page", new DKQPage(data));
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查询指定社团招募成员（根据审核状态）
     * @param groupCode
     * @param status
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/groupCode/{groupCode}/{status}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> volunteersByGroup(@PathVariable("groupCode") String groupCode,@PathVariable("status") Integer status,@PathVariable("pageNumber") Integer pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //
            List<GroupRecruitVolunteer> data = this.groupRecruitVolunteerService.findVerfierByGroup(groupCode, status, pageNumber);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            Map<String,Object> resultMap = new HashMap<String,Object>();

            List<GroupRecruitVolunteerVO> vos = new ArrayList<GroupRecruitVolunteerVO>();
            if(null != data && data.size()>0)
            {
                for(GroupRecruitVolunteer aa:data)
                    vos.add(GroupRecruitVolunteerVO.buildVO(aa));
            }

            resultMap.put("list", vos);
            jsonResult.setData(resultMap);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     *回答招募问题
     * @param groupRecruitVolunteerId
     * @return
     */
    @RequestMapping(value = "/answer/{groupRecruitVolunteerId}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> answer(@PathVariable("groupRecruitVolunteerId") Long groupRecruitVolunteerId)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            GroupRecruitVolunteer data = this.groupRecruitVolunteerService.findOne(groupRecruitVolunteerId);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("查询成功");
            jsonResult.setData(GroupRecruitVolunteerVO.buildVO(data));
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 审核报名人员
     * @param param
     * @return
     */
    @RequestMapping(value = "/verfier",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> verfier(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setCode(JsonResult.CODE_FAIL);
                jsonResult.setMessage("数据不能为空");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            this.groupRecruitVolunteerService.updateVerfierStatus(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("审核成功");
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

}
