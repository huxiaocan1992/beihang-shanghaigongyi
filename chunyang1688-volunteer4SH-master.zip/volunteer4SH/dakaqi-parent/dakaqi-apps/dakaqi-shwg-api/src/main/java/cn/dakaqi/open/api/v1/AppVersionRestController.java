package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.AppVersion;
import cn.dakaqi.services.AppVersionService;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.Clock;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import com.wordnik.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: AppVersionRestController <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/3 15:13
 * @version: 1.0.0
 */
@RestController
@RequestMapping(value = "/api/v1/version")
@Slf4j
@Api(value = "APP版本API")
public class AppVersionRestController
{
    @Autowired
    AppVersionService appVersionService;
    @Autowired
    ConfigUtil configUtil;

    @RequestMapping(value = "/{code}",method = RequestMethod.GET, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> get(@PathVariable("code") Integer code)
    {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        JsonResult jsonResult = new JsonResult();
        try
        {
            AppVersion appVersion = appVersionService.findLastVersion(code,ConfigUtil.getClientId());
            if(null != appVersion)
            {
                jsonResult.setData(appVersion);
            }
            else
            {
                jsonResult.setData(new HashMap<>());
            }

        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
    @RequestMapping(value = "/create",method = RequestMethod.POST, produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestParam("url") String url,@RequestParam("content") String content,@RequestParam("client") String client,
                                    @RequestParam("code") Integer code)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            AppVersion appVersion = new AppVersion();
            appVersion.setUrl(url);
            appVersion.setCode(code);
            appVersion.setClient(client);
            appVersion.setRemark(content);
            appVersion.setCreateTime(Clock.DEFAULT.getCurrentDate());
            appVersion.setType(10);
            appVersion.setStatus(20);
            appVersionService.saveVersion(appVersion);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        } catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
        }
        return new ResponseEntity(jsonResult, HttpStatus.OK);
    }
}
