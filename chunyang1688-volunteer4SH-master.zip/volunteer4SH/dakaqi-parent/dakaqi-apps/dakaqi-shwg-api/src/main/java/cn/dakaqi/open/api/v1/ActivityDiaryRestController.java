package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivityDiary;
import cn.dakaqi.services.ActivityDiaryService;
import cn.dakaqi.services.ActivityService;
import cn.dakaqi.services.GroupService;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.*;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by chunyang on 2016/4/18.
 */
@RestController
@RequestMapping(value = "/api/v1/activityDiary")
@Api(value = "活动日记API")
public class ActivityDiaryRestController
{
    @Autowired
    ActivityService activityService;
    @Autowired
    ActivityDiaryService activityDiaryService;
    @Autowired
    GroupService groupService;
    @Autowired
    ConfigUtil configUtil;

    /**
     * 发布活动总结
     * @return
     */
    @ApiOperation(value = "发布新日记")
    @RequestMapping(value = "/create",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            //String param = JSON.toJSONString(diary);
            this.activityDiaryService.save(param);
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
            jsonResult.setMessage("发布成功");
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
    }

    /**
     * 查询指定会员的所有活动总结
     * @param memberCode
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/memberCode/{memberCode}/{type}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    @ApiOperation(value = "查询指定会员的所有日记")
    public ResponseEntity<?> findByMemberCode(@PathVariable("memberCode") String memberCode,@PathVariable("type") int type,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            Page<ActivityDiary> data = this.activityDiaryService.findByMemberCode(memberCode,type,pageNumber);
            if(null == data || data.getContent() == null || data.getContent().size() == 0)
            {
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("暂时总结");
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }


            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {
                Map<String,Object> resultMap = new HashMap<String,Object>();
                List<ActivityDiaryVO> vos = new ArrayList<ActivityDiaryVO>();

                for(ActivityDiary aa:data.getContent())
                    vos.add(ActivityDiaryVO.buildVO(aa));

                resultMap.put("list", vos);
                resultMap.put("page", new DKQPage(data));
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("查询成功");
                jsonResult.setData(resultMap);

            }
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
    }

    /**
     * 查看指定活动的所有活动总结
     * @param activityCode
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/activityCode/{activityCode}/{type}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findByActivityCode(@PathVariable("activityCode") String activityCode,@PathVariable("type") int type,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        try
        {
            Page<ActivityDiary> data = this.activityDiaryService.findByActivityCode(activityCode,type, pageNumber);
            if(null == data || data.getContent() == null || data.getContent().size() == 0)
            {
                Activity activity = this.activityService.findByActivityCode(activityCode);
                ActivityVO activityVO = ActivityVO.buildVO(activity,null,ConfigUtil.getClientId());
                //查询当前活动的好 中 差数据
                resultMap.put("activityVO",activityVO);
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("查询成功");
                jsonResult.setData(resultMap);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            else
            {
                //当前活动的信息
                ActivityVO activityVO = ActivityVO.buildVO(data.getContent().get(0).getActivity(),null,ConfigUtil.getClientId());


                List<ActivityDiaryVO> vos = new ArrayList<ActivityDiaryVO>();

                for(ActivityDiary aa:data.getContent())
                    vos.add(ActivityDiaryVO.buildVO(aa));

                //查询当前活动的好 中 差数据
                resultMap.put("activityVO",activityVO);
                resultMap.put("list", vos);
                resultMap.put("page", new DKQPage(data));
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("查询成功");
                jsonResult.setData(resultMap);

            }

            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
    }

    /**
     * 查看指定社团的所有活动总结
     * @param groupCode
     * @param pageNumber
     * @return
     */
    @RequestMapping(value = "/groupCode/{groupCode}/{type}/{pageNumber}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> findByGroupCode(@PathVariable("groupCode") String groupCode,@PathVariable("type") int type,@PathVariable("pageNumber") int pageNumber)
    {
        JsonResult jsonResult = new JsonResult();
        Map<String,Object> resultMap = new HashMap<String,Object>();
        try
        {
            Page<ActivityDiary> data = this.activityDiaryService.findByGroupCode(groupCode,type,pageNumber);
            if(null == data || data.getContent() == null || data.getContent().size() == 0)
            {
                //查询当前活动的好 中 差数据
                resultMap.put("group", GroupVO.buildVO(this.groupService.findByGroupCode(groupCode),ConfigUtil.getClientId()));
                resultMap.put("list", new ArrayList<GroupDiaryVO>());
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("查询成功");
                jsonResult.setData(resultMap);

                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }

            if(null != data && data.getContent() != null && data.getContent().size()>0)
            {

                List<GroupDiaryVO> vos = new ArrayList<GroupDiaryVO>();

                for(ActivityDiary aa:data.getContent())
                    vos.add(GroupDiaryVO.buildVO(aa));

                //查询当前活动的好 中 差数据
                resultMap.put("group", GroupVO.buildVO(data.getContent().get(0).getGroup(),ConfigUtil.getClientId()));
                resultMap.put("list", vos);
                resultMap.put("page", new DKQPage(data));
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
                jsonResult.setMessage("查询成功");
                jsonResult.setData(resultMap);
            }
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
        }
    }
}
