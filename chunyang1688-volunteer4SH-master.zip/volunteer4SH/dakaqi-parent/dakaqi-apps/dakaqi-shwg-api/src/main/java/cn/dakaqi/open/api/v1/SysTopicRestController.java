package cn.dakaqi.open.api.v1;

import cn.dakaqi.entities.SysTopic;
import cn.dakaqi.services.SysTopicService;
import cn.dakaqi.services.user.VolunteerService;
import cn.dakaqi.util.ConfigUtil;
import cn.dakaqi.utils.JsonResult;
import cn.dakaqi.utils.exception.ServiceRuntimeException;
import cn.dakaqi.vo.response.SysTopicVO;
import com.wordnik.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springside.modules.web.MediaTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by chunyang on 2016/4/21.
 */
@RestController
@RequestMapping(value = "/api/v1/sysTopic")
@Api(value = "话题API")
public class SysTopicRestController
{
    @Autowired
    SysTopicService sysTopicService;
    @Autowired
    VolunteerService volunteerService;
    @Autowired
    ConfigUtil configUtil;

    /**
     * 发布新话题
     * @param param
     * @return
     */
    @RequestMapping(value = "/create",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> create(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setMessage("数据不能为空");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.sysTopicService.create(param);
            jsonResult.setMessage("话题发布成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 将指定的话题置顶/取消
     * @param param
     * @return
     */
    @RequestMapping(value = "/top",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> top(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setMessage("数据不能为空");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.sysTopicService.top(param);
            jsonResult.setMessage("话题发布成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     *将指定话题设置显示/不显示
     * @param param
     * @return
     */
    @RequestMapping(value = "/display",method = RequestMethod.POST,consumes = MediaTypes.JSON,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> display(@RequestBody String param)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(param))
            {
                jsonResult.setMessage("数据不能为空");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            this.sysTopicService.display(param);
            jsonResult.setMessage("话题发布成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定话题详情
     * @param code
     * @return
     */
    @RequestMapping(value = "/code/{code}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> code(@PathVariable("code") String code)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isBlank(code))
            {
                jsonResult.setMessage("数据不能为空");
                jsonResult.setCode(JsonResult.CODE_FAIL);
                return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
            }
            SysTopic sysTopic = this.sysTopicService.browse(code);
            if(null == sysTopic)
            {
                jsonResult.setData(new HashMap<>());
            }
            else
            {
                jsonResult.setData(SysTopicVO.buildVO(sysTopic,ConfigUtil.getClientId()));
            }
            jsonResult.setMessage("查询成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);

        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * 查看指定话题详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/id/{id}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> id(@PathVariable("id") Long id)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            SysTopic sysTopic = this.sysTopicService.browse(id);
            if(null == sysTopic)
            {
                jsonResult.setData(new HashMap<>());
            }
            else
            {
                jsonResult.setData(SysTopicVO.buildVO(sysTopic,ConfigUtil.getClientId()));
            }
            jsonResult.setMessage("查询成功");
            jsonResult.setCode(JsonResult.CODE_SUCCESS);
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }
        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }

    /**
     * @param memberCode
     * @return
     */
    @RequestMapping(value = "/memberCode/{memberCode}",method = RequestMethod.GET,produces = MediaTypes.JSON_UTF_8)
    public ResponseEntity<?> memberCode(@PathVariable("memberCode") String memberCode)
    {
        JsonResult jsonResult = new JsonResult();
        try
        {
            if(StringUtils.isNotBlank(memberCode))
            {
                //根据条件，找出当前用户所喜好的标签
                String tags = "";
                List<SysTopic> data = this.sysTopicService.findByTag(null,tags,1);
                if(null != data)
                {
                    List<SysTopicVO> vos = new ArrayList<SysTopicVO>();
                    for(SysTopic sysTopic:data)
                    {
                        vos.add(SysTopicVO.buildVO(sysTopic, ConfigUtil.getClientId()));
                    }
                    jsonResult.setData(vos);
                }
                else
                {
                    jsonResult.setData(new HashMap<>());
                }
                jsonResult.setMessage("查询成功");
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
            }
            else
            {
                Page<SysTopic> data = this.sysTopicService.findByTop(null,1);
                if(null != data && data.getContent().size()>0)
                {
                    List<SysTopic> list = data.getContent();
                    List<SysTopicVO> vos = new ArrayList<SysTopicVO>();
                    for(SysTopic sysTopic:list)
                    {
                        vos.add(SysTopicVO.buildVO(sysTopic, ConfigUtil.getClientId()));
                    }
                    jsonResult.setData(vos);
                }
                else
                {
                    jsonResult.setData(new HashMap<>());
                }

                jsonResult.setMessage("查询成功");
                jsonResult.setCode(JsonResult.CODE_SUCCESS);
            }
        } catch (ServiceRuntimeException e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            jsonResult.setCode(JsonResult.CODE_FAIL);
            jsonResult.setMessage(e.getMessage());
            return new ResponseEntity(jsonResult,HttpStatus.OK);
        }

        return new ResponseEntity<Object>(jsonResult, HttpStatus.OK);
    }
}
