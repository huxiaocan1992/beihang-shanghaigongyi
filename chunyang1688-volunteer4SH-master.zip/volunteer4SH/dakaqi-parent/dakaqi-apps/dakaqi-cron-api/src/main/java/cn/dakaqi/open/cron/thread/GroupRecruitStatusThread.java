package cn.dakaqi.open.cron.thread;


import cn.dakaqi.services.GroupRecruitService;

/**
 * Created by chunyang on 2016/4/28.
 */
public class GroupRecruitStatusThread implements Runnable
{
    GroupRecruitService groupRecruitService;

    public GroupRecruitStatusThread(GroupRecruitService groupRecruitService)
    {
        this.groupRecruitService = groupRecruitService;
    }

    @Override
    public void run()
    {
        groupRecruitService.updateStatus();
    }
}
