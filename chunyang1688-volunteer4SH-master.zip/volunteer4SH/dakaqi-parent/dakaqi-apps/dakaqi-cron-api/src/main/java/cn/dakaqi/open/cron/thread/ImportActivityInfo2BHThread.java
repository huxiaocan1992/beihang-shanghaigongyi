package cn.dakaqi.open.cron.thread;

import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.qnzyz.BHActivityService;
import cn.dakaqi.utils.BaseDAO;
import cn.dakaqi.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * 将结束后的活动所有打卡记录提交至北航系统
 */
@Slf4j
public class ImportActivityInfo2BHThread implements Runnable
{
    BaseDAO baseDAO;
    BHActivityService bhActivityService;

    String activityCode = "",sql = "";
    List<ActivitySign> signs = null;

    public ImportActivityInfo2BHThread(String activityCode, BaseDAO baseDAO, BHActivityService bhActivityService, List<ActivitySign> signs)
    {
        this.baseDAO = baseDAO;
        this.bhActivityService = bhActivityService;
        this.activityCode = activityCode;
        this.signs = signs;
    }

    @Override
    public void run()
    {
        try
        {
            if(null == this.signs || this.signs.size() ==0 || this.activityCode.startsWith("A"))
                return;

            log.info("----------------将活动编号为【"+activityCode+"】的所有打卡记录提交至北航系统开始-------------------");

            for(ActivitySign sign:signs)
            {
                if(sign.getRecordId()>0L)
                    continue;
                if(sign.getTimes() == 0)
                    continue;
                long signId = sign.getId();
                String volunteerCode = sign.getVolunteer().getVolunteerCode();
                if(StringUtils.isBlank(volunteerCode) || volunteerCode.startsWith("V"))
                    continue;

                //导入打卡记录
                importSign(activityCode,volunteerCode,String.valueOf(sign.getTimes()), signId);
                //导入活动的签到记录
                importQianDao(activityCode,volunteerCode, DateUtil.DefaultTimeFormatter.format(sign.getCreateTime()), String.valueOf(sign.getLng()), String.valueOf(sign.getLat()));
                //导入活动的报名记录
                importActivityApply(activityCode, volunteerCode, DateUtil.DefaultTimeFormatter.format(sign.getActivity().getCreateTime()));
            }
            log.info("----------------将活动编号为【"+activityCode+"】的所有打卡记录提交至北航系统结束-------------------");
        } catch (Exception e)
        {
            e.printStackTrace();
            log.error(e.getMessage());
        }
    }

    /**
     * 导入活动报名记录
     * @param activityCode
     * @param volunteerCode
     * @param createTime
     * @throws Exception
     */
    private void importActivityApply(String activityCode,String volunteerCode,String createTime)
    {
        try
        {
            int regId = bhActivityService.reg(activityCode, volunteerCode, "1", createTime);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    /**
     * 导入签到记录
     * @param activityCode
     * @param volunteerCode
     * @param createTime
     * @param lng
     * @param lat
     * @throws Exception
     */
    private void importQianDao(String activityCode,String volunteerCode,String createTime,String lng,String lat)
    {
        try
        {
            int signId = bhActivityService.sign(activityCode,volunteerCode,"1",createTime,lng,lat);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 导入打卡记录
     * @param activityCode
     * @param volunteerCode
     * @param time
     * @param signId
     * @throws Exception
     */
    private void importSign(String activityCode,String volunteerCode,String time,long signId)
    {
        try
        {
            //导入活动的打卡记录
            int  recordId = this.bhActivityService.record(activityCode,volunteerCode,time,"0");
            sql = "update U_ACTIVITY_SIGN set RECORD_ID = "  +recordId + " where id = " + signId;
            log.info(sql);
            this.baseDAO.updateNativeSql(sql);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
