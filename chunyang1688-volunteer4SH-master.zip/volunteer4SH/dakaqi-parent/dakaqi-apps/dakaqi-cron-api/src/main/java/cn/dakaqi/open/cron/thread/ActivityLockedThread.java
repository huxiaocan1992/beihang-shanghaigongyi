package cn.dakaqi.open.cron.thread;

import cn.dakaqi.entities.Activity;
import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.qnzyz.BHActivityService;
import cn.dakaqi.services.ActivityService;
import cn.dakaqi.services.ActivitySignService;
import cn.dakaqi.utils.BaseDAO;
import cn.dakaqi.utils.DKQConstant;
import cn.dakaqi.utils.DateUtil;
import cn.dakaqi.utils.rongYun.PushActivityMesssage;
import org.springframework.data.domain.Page;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by chunyang on 2016/4/28.
 */
public class ActivityLockedThread implements Runnable
{
    ActivitySignService activitySignService;
    ActivityService activityService;
    BaseDAO baseDAO;
    BHActivityService bhActivityService;


    public ActivityLockedThread(ActivityService activityService,BaseDAO baseDAO, BHActivityService bhActivityService,ActivitySignService activitySignService)
    {
        this.activityService = activityService;
        this.baseDAO = baseDAO;
        this.bhActivityService = bhActivityService;
        this.activitySignService = activitySignService;
    }

    @Override
    public void run()
    {
        locked();
    }

    public void locked()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Page<Activity> data = activityService.findEndAndUnLockedByActStatus(1);
        try
        {
            if(null != data && null != data.getContent() && data.getContent().size()>0)
            {
                for(Activity act:data.getContent())
                {
                    Calendar calendar = Calendar.getInstance();
                    String endtday = act.getEndTime();
                    String nowday = sdf.format(calendar.getTime());
                    //long days = DateUtil.countDay(endtday, nowday, sdf);
                    int minutes = DateUtil.countMinutes(endtday, nowday);
                    if(minutes >= 4*60)
                    {
                        act.setLocked(DKQConstant.ACTIVITY_LOCK);
                        act.setActStatus(DKQConstant.ACT_STATUS_LOCKED);
                        act.setOrderNum(DKQConstant.ACT_ORDER_LOCKED);
                        activityService.update(act);

                        List<ActivitySign> signs = activitySignService.queryAllByActivity(act.getActivityCode());
                        ImportActivityInfo2BHThread importActivityInfo2BHThread  = new ImportActivityInfo2BHThread(act.getActivityCode(), baseDAO, bhActivityService, signs);
                        Thread thread2 = new Thread(importActivityInfo2BHThread);
                        thread2.start();

                        List<String> volunteers = new ArrayList<String>();
                        if(act.getCreateUser().getId() == act.getMonitor().getId())
                        {
                            volunteers.add(act.getCreateUser().getMemberCode());
                        }
                        else
                        {
                            volunteers.add(act.getCreateUser().getMemberCode());
                            volunteers.add(act.getMonitor().getMemberCode());
                        }
                        PushActivityMesssage.getInstance().locked(act.getName(), volunteers);
                    }
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
//    public void locked() throws ServiceRuntimeException
//    {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
//        Page<Activity> data = activityService.findEndAndUnLocked(1);
//        try
//        {
//            if(null != data && null != data.getContent() && data.getContent().size()>0)
//            {
//                for(Activity act:data.getContent())
//                {
//
//                    Calendar calendar = Calendar.getInstance();
//                    String endtday = act.getEndTime();
//                    String nowday = sdf.format(calendar.getTime());
//                    //long days = DateUtil.countDay(endtday, nowday, sdf);
//                    int minutes = DateUtil.countMinutes(endtday, nowday);
//                    if(minutes >= 4*60)
//                    {
//                        act.setLocked(DKQConstant.USER_LOCK);
//                        activityService.update(act);
//
//                        List<String> volunteers = new ArrayList<String>();
//                        if(act.getCreateUser().getId() == act.getMonitor().getId())
//                        {
//                            volunteers.add(act.getCreateUser().getMemberCode());
//                        }
//                        else
//                        {
//                            volunteers.add(act.getCreateUser().getMemberCode());
//                            volunteers.add(act.getMonitor().getMemberCode());
//
//                        }
//                        PushActivityMesssage.getInstance().locked(act.getName(), volunteers);
//                    }
//                }
//            }
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//    }
}
