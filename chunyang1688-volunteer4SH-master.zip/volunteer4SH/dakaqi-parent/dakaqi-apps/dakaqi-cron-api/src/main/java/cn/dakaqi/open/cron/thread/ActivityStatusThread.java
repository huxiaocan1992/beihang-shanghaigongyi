package cn.dakaqi.open.cron.thread;


import cn.dakaqi.services.ActivityService;

/**
 * Created by chunyang on 2016/4/28.
 */
public class ActivityStatusThread implements Runnable
{
    ActivityService activityService;

    public ActivityStatusThread(ActivityService activityService)
    {
        this.activityService = activityService;
    }

    @Override
    public void run()
    {
        activityService.updateActStatus();
    }
}
