package cn.dakaqi.open.cron.thread;


import cn.dakaqi.services.IndexDataService;

/**
 * Created by chunyang on 2016/4/28.
 */
public class IndexDataStopStatusThread implements Runnable
{
    IndexDataService indexDataService;

    public IndexDataStopStatusThread(IndexDataService indexDataService)
    {
        this.indexDataService = indexDataService;
    }

    @Override
    public void run()
    {
        indexDataService.updateStatus();
    }
}
