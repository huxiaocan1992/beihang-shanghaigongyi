package cn.dakaqi.open.cron;

import cn.dakaqi.entities.ActivitySign;
import cn.dakaqi.open.cron.thread.*;
import cn.dakaqi.qnzyz.BHActivityService;
import cn.dakaqi.services.*;
import cn.dakaqi.utils.BaseDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by chunyang on 2016/4/21.
 */
public class ActivityJob
{
    private static Logger logger = LoggerFactory.getLogger(ActivityJob.class);
    @Autowired
    BHActivityService bhActivityService;
    @Autowired
    BaseDAO baseDAO;
    @Autowired
    ActivitySignService activitySignService;
    @Autowired
    ActivityService activityService;
    @Autowired
    ActivityRecruitService activityRecruitService;
    @Autowired
    GroupRecruitService groupRecruitService;
    @Autowired
    IndexDataService indexDataService;
    @Autowired
    GroupMonthDataService groupMonthDataService;


    //更新活动的进行状态
    public void updateStatus()
    {
        logger.info("---------------更新活动的进行状态--------start----------------");
        ActivityStatusThread activityStatusThread = new ActivityStatusThread(activityService);
        Thread thread = new Thread(activityStatusThread);
        thread.start();
//        List<ActivitySign> signs = activitySignService.queryAllUnSubmit();
//        ImportActivitySign2BHThread importActivitySign2BHThread = new ImportActivitySign2BHThread(baseDAO, bhActivityService,signs);
//        Thread thread2 = new Thread(importActivitySign2BHThread);
//        thread2.start();

        logger.info("---------------更新活动的进行状态--------end----------------");
    }
    //活动结束后的4小时后进行封存，并将数据提交至北航
    public void locked()
    {
        logger.info("---------------活动结束后的4小时后进行封存，并将数据提交至北航--------start----------------");
        ActivityLockedThread activityLockedThread = new ActivityLockedThread(activityService,baseDAO, bhActivityService,activitySignService);
        Thread thread = new Thread(activityLockedThread);
        thread.start();
        logger.info("---------------活动结束后的4小时后进行封存，并将数据提交至北航--------end----------------");
    }

    //更新社团招募状态
    public void updateGroupRecruitStatus()
    {
        logger.info("---------------更新社团招募状态--------start----------------");
        GroupRecruitStatusThread activityStatusThread = new GroupRecruitStatusThread(groupRecruitService);
        Thread thread = new Thread(activityStatusThread);
        thread.start();
        logger.info("---------------更新社团招募状态--------end----------------");
    }
    //更新首页容器中的数据状态
    public void updateIndexDataStatus()
    {
        logger.info("---------------更新首页容器中的数据状态--------start----------------");
        IndexDataStopStatusThread indexDataStopStatusThread = new IndexDataStopStatusThread(indexDataService);
        Thread thread2 = new Thread(indexDataStopStatusThread);
        thread2.start();
        logger.info("---------------更新首页容器中的数据状态--------end----------------");
    }
    //活动开始前5、结束后5分钟，提示去签到签出
    public void signInOrOut()
    {
        logger.info("---------------活动开始前5、结束后5分钟，提示去签到签出--------start----------------");
        ActivitySignInfoThread signThread = new ActivitySignInfoThread(activityService);
        Thread thread = new Thread(signThread);
        thread.start();
        logger.info("---------------活动开始前5、结束后5分钟，提示去签到签出--------end----------------");
    }




    /**
     * 每月1日统计社团上一月的新增活动量、人员量、公益时间
     */
    public void statistics()
    {
        logger.info("---------------每月1日统计社团上一月的新增活动量、人员量、公益时间--------start-------------");
        GroupMonthDataThread dataThread = new GroupMonthDataThread(groupMonthDataService);
        Thread thread = new Thread(dataThread);
        thread.start();
        logger.info("---------------每月1日统计社团上一月的新增活动量、人员量、公益时间--------end----------------");
    }
}
