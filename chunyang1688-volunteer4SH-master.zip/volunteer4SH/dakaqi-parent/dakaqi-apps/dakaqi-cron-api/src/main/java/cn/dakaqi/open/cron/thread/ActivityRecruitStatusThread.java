package cn.dakaqi.open.cron.thread;

import cn.dakaqi.services.ActivityRecruitService;

/**
 * Created by chunyang on 2016/4/28.
 */
public class ActivityRecruitStatusThread implements Runnable
{
    ActivityRecruitService activityRecruitService;

    public ActivityRecruitStatusThread(ActivityRecruitService activityRecruitService)
    {
        this.activityRecruitService = activityRecruitService;
    }

    @Override
    public void run()
    {
        activityRecruitService.updateStatus();
    }
}
