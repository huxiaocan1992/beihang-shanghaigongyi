package cn.dakaqi.open.cron.thread;


import cn.dakaqi.services.ActivityService;

/**
 * 活动开始前的30分钟、活动结束后的30分钟进行活动签到、签退提示
 * Created by chunyang on 2016/4/28.
 */
public class ActivitySignInfoThread implements Runnable
{
    ActivityService activityService;

    public ActivitySignInfoThread(ActivityService activityService)
    {
        this.activityService = activityService;
    }

    @Override
    public void run()
    {
        activityService.signInfo();
    }
}
