package cn.dakaqi.open.cron.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright: Copyright (c)2016
 * Company: 志愿者打卡器(www.dakaqi.cn)
 * 类名称: ClientAndKey <br>
 * 类描述: <br>
 *
 * @author: ChunYang.Zhang
 * @since: 2016/8/5 13:21
 * @version: 1.0.0
 */
public class ClientAndKey
{
    static Map<String,String> keys = null;
    static {
        if(null == keys)
        {
            keys = new HashMap<String,String >();
            keys.put("100009", "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0FhAal1diWCkErdynsiCaw9yKuNTs7OQwoP4rYivCNXe2bgATYRrSXNih3V+UzCdIcKZr/YI2zXOdNHwxJmORmqd+vDcDm7PeFlqWHX4tiMAEiHfvJ6r3rXW2oYhNeajvX/TqPmGF/sKsIrmFitbQfzMVjQ8RiCwDIkqRed6seQIDAQAB");
            keys.put("1003", "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCDD9BJZt2vKcpv8VLYzBY3GNvcHKPI721gfOax41TUu1WTmEZoYuYMkhLypeWeQLQktXsdCbEb9drugnMelwYTpJd4X8Dzu1g5Cr9cri5PTgrqX7RgyghKlbOmdCrKeOUV/qTp9QfOdJ1v2tY79Im0bkMR/rir0zmD7mcBwRHW8wIDAQAB");
            keys.put("100189", "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjgZktm9br7rozXnvyzfucAqDcbfK/q8LEelokAzcFXgITAhIvaWXVHiLLPW2WDO1tW8+cFJs4f/BC6lPojTRy4TCbVZEzKEObUiPz6SoRKXrkG7ZiDu4RTGZfJOY3KYluNYxXOINUrwUoZItHNgWXVDOgXo8hPAQaXlOOMv/WUQIDAQAB");
        }
    }
}
